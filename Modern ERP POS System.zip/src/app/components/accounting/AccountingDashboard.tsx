import React, { useState } from 'react';
import { 
  Plus, 
  ArrowLeftRight, 
  Landmark, 
  Wallet, 
  CreditCard, 
  Paperclip,
  MoreVertical,
  Search,
  Filter,
  Download,
  Eye,
  Pencil,
  FileText,
  Snowflake,
  Trash
} from 'lucide-react';
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Switch } from "../ui/switch";
import { Badge } from "../ui/badge";
import { cn } from "../ui/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "../ui/dropdown-menu";
import { toast } from "sonner";
import { FundsTransferModal } from './FundsTransferModal';
import { AddAccountDrawer } from './AddAccountDrawer';

// Mock Data for Accounts
const accounts = [
  { id: 1, name: 'Meezan Bank Corp', type: 'Bank', balance: 1250000, color: 'from-green-900/80 to-green-950', border: 'border-green-800/50', icon: Landmark, number: 'PK65MEZN001234567890', provider: 'Visa', status: true, opening: 500000 },
  { id: 2, name: 'Shop Cash Drawer', type: 'Cash', balance: 45000, color: 'from-gray-800 to-gray-900', border: 'border-gray-700/50', icon: Wallet, number: 'Drawer #1', provider: null, status: true, opening: 10000 },
  { id: 3, name: 'JazzCash Wallet', type: 'Mobile Wallet', balance: 12500, color: 'from-red-900/80 to-red-950', border: 'border-red-800/50', icon: CreditCard, number: '0300-1234567', provider: 'Mastercard', status: true, opening: 5000 },
  { id: 4, name: 'HBL Operational', type: 'Bank', balance: 85000, color: 'from-teal-900/80 to-teal-950', border: 'border-teal-800/50', icon: Landmark, number: 'PK88HABB009876543210', provider: 'Visa', status: false, opening: 100000 },
];

// Mock Data for Transactions
const transactions = [
  { id: 1, date: 'Today, 10:23 AM', desc: 'Transfer to JazzCash', attach: true, type: 'debit', amount: 500.00, bal: 124500 },
  { id: 2, date: 'Yesterday, 4:15 PM', desc: 'Client Payment - Inv #102', attach: false, type: 'credit', amount: 12500.00, bal: 125000 },
  { id: 3, date: '26 Dec, 11:00 AM', desc: 'Utility Bill Payment', attach: true, type: 'debit', amount: 4500.00, bal: 112500 },
  { id: 4, date: '25 Dec, 09:30 AM', desc: 'Shop Cash Deposit', attach: true, type: 'credit', amount: 25000.00, bal: 117000 },
  { id: 5, date: '24 Dec, 02:45 PM', desc: 'Supplier Payment (Fabrics)', attach: false, type: 'debit', amount: 15000.00, bal: 92000 },
];

export const AccountingDashboard = () => {
  const [activeTab, setActiveTab] = useState<'transactions' | 'accounts'>('transactions');
  const [isTransferOpen, setIsTransferOpen] = useState(false);
  const [isAddAccountOpen, setIsAddAccountOpen] = useState(false);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      
      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 border-b border-gray-800 pb-4">
        <div className="space-y-4 w-full md:w-auto">
          <div>
            <h2 className="text-3xl font-bold text-white tracking-tight">Accounting</h2>
            <p className="text-gray-400 mt-1">Manage treasury, bank accounts, and funds.</p>
          </div>
          
          {/* Tabs */}
          <div className="flex items-center gap-6 mt-6">
            <button
              onClick={() => setActiveTab('transactions')}
              className={cn(
                "pb-2 text-sm font-medium transition-all relative",
                activeTab === 'transactions' 
                  ? "text-blue-400" 
                  : "text-gray-400 hover:text-gray-300"
              )}
            >
              Transactions
              {activeTab === 'transactions' && (
                <span className="absolute bottom-0 left-0 w-full h-0.5 bg-blue-500 rounded-full" />
              )}
            </button>
            <button
              onClick={() => setActiveTab('accounts')}
              className={cn(
                "pb-2 text-sm font-medium transition-all relative",
                activeTab === 'accounts' 
                  ? "text-blue-400" 
                  : "text-gray-400 hover:text-gray-300"
              )}
            >
              Accounts List
              {activeTab === 'accounts' && (
                <span className="absolute bottom-0 left-0 w-full h-0.5 bg-blue-500 rounded-full" />
              )}
            </button>
          </div>
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto justify-end">
           {activeTab === 'accounts' && (
             <Button 
               onClick={() => setIsAddAccountOpen(true)}
               variant="outline" 
               className="border-gray-700 text-gray-300 hover:text-white hover:bg-gray-800"
             >
               <Plus size={18} className="mr-2" /> Add Account
             </Button>
           )}
           <Button 
             onClick={() => setIsTransferOpen(true)}
             className="bg-blue-600 hover:bg-blue-500 text-white gap-2 shadow-lg shadow-blue-600/20"
           >
             <ArrowLeftRight size={18} />
             Fund Transfer
           </Button>
        </div>
      </div>

      {/* Content Area */}
      {activeTab === 'transactions' ? (
        <div className="space-y-8 animate-in slide-in-from-bottom-2 duration-300">
          {/* 1. Accounts Grid (Debit Cards) - Only visible in Transactions Tab */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {accounts.map((account) => (
              <div 
                key={account.id}
                className={cn(
                  "relative aspect-[1.586] rounded-xl p-5 flex flex-col justify-between shadow-2xl overflow-hidden group transition-all hover:scale-[1.02] border",
                  "bg-gradient-to-br",
                  account.color,
                  account.border
                )}
              >
                {/* Glossy Overlay */}
                <div className="absolute inset-0 bg-gradient-to-tr from-white/5 to-transparent opacity-50 pointer-events-none" />
                <div className="absolute -right-12 -top-12 w-32 h-32 bg-white/5 rounded-full blur-2xl pointer-events-none" />

                {/* Card Header */}
                <div className="flex justify-between items-start relative z-10">
                   <div className="flex items-center gap-2">
                      <account.icon size={16} className="text-white/70" />
                      <span className="text-[10px] uppercase tracking-wider font-bold text-white/60">{account.type}</span>
                   </div>
                   {account.provider && (
                     <span className="font-bold italic text-white/40 text-lg">{account.provider}</span>
                   )}
                </div>

                {/* Middle: Chip & Number */}
                <div className="relative z-10 pl-1">
                   <div className="w-8 h-6 rounded bg-yellow-200/20 border border-yellow-200/40 mb-3 flex items-center justify-center">
                      <div className="w-4 h-3 border border-yellow-200/30 rounded-[2px]" />
                   </div>
                   <p className="font-mono text-white/80 text-sm tracking-widest shadow-black drop-shadow-md">
                      {account.number.includes('****') ? account.number : `**** ${account.number.slice(-4)}`}
                   </p>
                </div>

                {/* Bottom: Name & Balance */}
                <div className="relative z-10 flex justify-between items-end">
                   <div>
                      <p className="text-[9px] uppercase text-white/50 mb-0.5">Account Name</p>
                      <h3 className="text-white text-xs font-bold tracking-wide truncate max-w-[120px]">{account.name}</h3>
                   </div>
                   <div className="text-right">
                      <h2 className="text-xl font-bold text-white tracking-tight drop-shadow-md">
                        ${account.balance.toLocaleString()}
                      </h2>
                   </div>
                </div>
              </div>
            ))}
          </div>

          {/* 2. Transaction History Table */}
          <div className="bg-gray-900/50 border border-gray-800 rounded-xl overflow-hidden">
            {/* Table Header / Toolbar */}
            <div className="p-5 border-b border-gray-800 flex flex-col sm:flex-row justify-between items-center gap-4">
               <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  Transaction History
                  <span className="bg-gray-800 text-gray-400 text-xs px-2 py-0.5 rounded-full">Recent 5</span>
               </h3>
               <div className="flex items-center gap-2 w-full sm:w-auto">
                  <div className="relative flex-1 sm:w-64">
                     <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                     <Input 
                       placeholder="Search transactions..." 
                       className="bg-gray-950 border-gray-800 text-sm pl-9 h-9" 
                     />
                  </div>
                  <Button variant="outline" size="icon" className="h-9 w-9 border-gray-800 bg-gray-950 text-gray-400 hover:text-white">
                     <Filter size={14} />
                  </Button>
                  <Button variant="outline" size="icon" className="h-9 w-9 border-gray-800 bg-gray-950 text-gray-400 hover:text-white">
                     <Download size={14} />
                  </Button>
               </div>
            </div>

            {/* The Table */}
            <div className="overflow-x-auto">
               <table className="w-full text-sm text-left">
                  <thead className="text-xs text-gray-500 uppercase bg-gray-950/50 border-b border-gray-800">
                     <tr>
                        <th className="px-6 py-3 font-medium">Date / Time</th>
                        <th className="px-6 py-3 font-medium">Description</th>
                        <th className="px-6 py-3 font-medium text-center">Attachment</th>
                        <th className="px-6 py-3 font-medium text-right">Amount</th>
                        <th className="px-6 py-3 font-medium text-right">Balance</th>
                        <th className="px-6 py-3 font-medium text-center">Action</th>
                     </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-800">
                     {transactions.map((tx) => (
                        <tr key={tx.id} className="group hover:bg-gray-800/30 transition-colors">
                           <td className="px-6 py-4 font-medium text-gray-300">
                              {tx.date}
                           </td>
                           <td className="px-6 py-4">
                              <span className="text-white font-medium block">{tx.desc}</span>
                              <span className="text-xs text-gray-500">{tx.type === 'debit' ? 'Outgoing' : 'Incoming'} Transfer</span>
                           </td>
                           <td className="px-6 py-4 text-center">
                              {tx.attach ? (
                                 <button className="inline-flex items-center justify-center h-8 w-8 rounded-full bg-blue-900/20 text-blue-400 hover:bg-blue-900/40 transition-colors">
                                    <Paperclip size={14} />
                                 </button>
                              ) : (
                                 <span className="text-gray-700">-</span>
                              )}
                           </td>
                           <td className={cn(
                              "px-6 py-4 text-right font-bold",
                              tx.type === 'credit' ? "text-green-500" : "text-red-500"
                           )}>
                              {tx.type === 'credit' ? '+' : '-'}${tx.amount.toLocaleString()}
                           </td>
                           <td className="px-6 py-4 text-right text-gray-400 font-mono">
                              ${tx.bal.toLocaleString()}
                           </td>
                           <td className="px-6 py-4 text-center">
                              <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-500 hover:text-white opacity-0 group-hover:opacity-100 transition-opacity">
                                 <MoreVertical size={14} />
                              </Button>
                           </td>
                        </tr>
                     ))}
                  </tbody>
               </table>
            </div>
            
            {/* Pagination Footer */}
            <div className="p-4 border-t border-gray-800 bg-gray-950/30 flex justify-center">
               <Button variant="link" className="text-blue-400 text-xs">View All Transactions</Button>
            </div>
          </div>
        </div>
      ) : (
        /* Accounts List View */
        <div className="bg-gray-900/50 border border-gray-800 rounded-xl overflow-hidden animate-in slide-in-from-bottom-2 duration-300">
          <div className="overflow-x-auto">
             <table className="w-full text-sm text-left">
                <thead className="text-xs text-gray-500 uppercase bg-gray-950/50 border-b border-gray-800">
                   <tr>
                      <th className="px-6 py-3 font-medium">Account Name</th>
                      <th className="px-6 py-3 font-medium">Type</th>
                      <th className="px-6 py-3 font-medium">Account Number</th>
                      <th className="px-6 py-3 font-medium text-right">Opening Balance</th>
                      <th className="px-6 py-3 font-medium text-right">Current Balance</th>
                      <th className="px-6 py-3 font-medium text-center">Status</th>
                      <th className="px-6 py-3 font-medium text-center">Actions</th>
                   </tr>
                </thead>
                <tbody className="divide-y divide-gray-800">
                   {accounts.map((acc) => (
                      <tr key={acc.id} className="group hover:bg-gray-800/30 transition-colors">
                         <td className="px-6 py-4 font-bold text-white">
                            {acc.name}
                         </td>
                         <td className="px-6 py-4">
                            <Badge variant="outline" className="bg-gray-800 text-gray-300 border-gray-700 flex w-fit items-center gap-1.5">
                               <acc.icon size={12} className={cn(
                                 acc.type === 'Bank' && "text-blue-400",
                                 acc.type === 'Cash' && "text-green-400",
                                 acc.type === 'Mobile Wallet' && "text-purple-400"
                               )} />
                               {acc.type}
                            </Badge>
                         </td>
                         <td className="px-6 py-4 text-gray-500 font-mono text-xs">
                            {acc.number}
                         </td>
                         <td className="px-6 py-4 text-right text-gray-400">
                            ${acc.opening?.toLocaleString() || '0'}
                         </td>
                         <td className="px-6 py-4 text-right font-bold text-green-500 text-base">
                            Rs {acc.balance.toLocaleString()}
                         </td>
                         <td className="px-6 py-4 text-center">
                             <div className="flex justify-center">
                                <Switch checked={acc.status} />
                             </div>
                         </td>
                         <td className="px-6 py-4 text-center">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-500 hover:text-white data-[state=open]:bg-gray-800">
                                  <MoreVertical size={16} />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" className="w-[160px] bg-[#1F2937] border-gray-700 text-white">
                                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                <DropdownMenuSeparator className="bg-gray-700" />
                                <DropdownMenuItem className="cursor-pointer hover:bg-gray-700 focus:bg-gray-700">
                                  <Pencil className="mr-2 h-4 w-4 text-blue-400" />
                                  <span>Edit</span>
                                </DropdownMenuItem>
                                <DropdownMenuItem 
                                  className="cursor-pointer hover:bg-gray-700 focus:bg-gray-700"
                                  onClick={() => setActiveTab('transactions')}
                                >
                                  <FileText className="mr-2 h-4 w-4 text-green-400" />
                                  <span>Statement</span>
                                </DropdownMenuItem>
                                <DropdownMenuItem className="cursor-pointer hover:bg-gray-700 focus:bg-gray-700">
                                  <Snowflake className="mr-2 h-4 w-4 text-blue-200" />
                                  <span>{acc.status ? 'Freeze' : 'Unfreeze'}</span>
                                </DropdownMenuItem>
                                <DropdownMenuSeparator className="bg-gray-700" />
                                <DropdownMenuItem 
                                  className="cursor-pointer hover:bg-red-900/20 focus:bg-red-900/20 text-red-400 hover:text-red-300"
                                  onClick={() => toast.error("Delete action triggered")}
                                >
                                  <Trash className="mr-2 h-4 w-4" />
                                  <span>Delete</span>
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                         </td>
                      </tr>
                   ))}
                </tbody>
             </table>
          </div>
        </div>
      )}

      {/* Modals & Drawers */}
      <FundsTransferModal isOpen={isTransferOpen} onClose={() => setIsTransferOpen(false)} />
      <AddAccountDrawer isOpen={isAddAccountOpen} onClose={() => setIsAddAccountOpen(false)} />

    </div>
  );
};
