import React from 'react';
import { Search, Bell, Menu, Sun, Moon, MapPin, Plus } from 'lucide-react';
import { useNavigation } from '../../context/NavigationContext';
import { useTheme } from 'next-themes';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "../ui/dropdown-menu";
import { Button } from "../ui/button";

export const TopHeader = () => {
  const { toggleSidebar, openDrawer } = useNavigation();
  const { theme, setTheme } = useTheme();
  const [branch, setBranch] = React.useState("Main Branch (HQ)");

  return (
    <header className="h-16 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 flex items-center justify-between px-4 md:px-6 sticky top-0 z-10 text-gray-900 dark:text-white transition-colors">
      <div className="flex items-center gap-4 flex-1">
        <button 
          onClick={toggleSidebar}
          className="md:hidden p-2 text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white"
        >
          <Menu size={24} />
        </button>
        
        {/* Branch Selector */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="hidden md:flex items-center gap-2 border-gray-200 dark:border-gray-700 bg-transparent text-gray-700 dark:text-gray-200">
              <MapPin size={16} className="text-blue-500" />
              <span>{branch}</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56 bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800">
            <DropdownMenuItem onClick={() => setBranch("Main Branch (HQ)")}>Main Branch (HQ)</DropdownMenuItem>
            <DropdownMenuItem onClick={() => setBranch("Downtown Outlet")}>Downtown Outlet</DropdownMenuItem>
            <DropdownMenuItem onClick={() => setBranch("Mall Kiosk")}>Mall Kiosk</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <div className="relative max-w-md w-full hidden lg:block ml-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-500" size={16} />
          <input 
            type="text" 
            placeholder="Search products, orders, customers..." 
            className="w-full bg-gray-100 dark:bg-gray-800 border-none rounded-lg pl-10 pr-4 py-2 text-sm text-gray-900 dark:text-gray-200 placeholder:text-gray-400 dark:placeholder:text-gray-500 focus:ring-2 focus:ring-blue-500 outline-none transition-colors"
          />
        </div>
      </div>

      <div className="flex items-center gap-3">
        {/* Global Create Actions */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button size="sm" className="bg-blue-600 hover:bg-blue-500 text-white gap-2 hidden sm:flex">
              <Plus size={16} />
              <span className="hidden sm:inline">Create New</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800">
            <DropdownMenuItem onClick={() => openDrawer('addSale')}>
              New Sale
            </DropdownMenuItem>
             <DropdownMenuItem onClick={() => openDrawer('addPurchase')}>
              New Purchase
            </DropdownMenuItem>
             <div className="h-px bg-gray-200 dark:bg-gray-800 my-1" />
            <DropdownMenuItem onClick={() => openDrawer('addProduct')}>
              Add Product
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => openDrawer('addUser')}>
              Add User
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <button 
          onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
          className="p-2 text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
        >
          {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
        </button>

        <button className="relative p-2 text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors">
          <Bell size={20} />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border border-white dark:border-gray-900"></span>
        </button>
        
        <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-purple-500 to-blue-500 md:hidden" />
      </div>
    </header>
  );
};
