import React, { useState } from 'react';
import { 
  Search, 
  ShoppingCart, 
  Trash2, 
  Plus, 
  Minus, 
  CreditCard, 
  Banknote, 
  X, 
  ArrowLeft,
  User,
  Receipt,
  Zap,
  Coffee,
  UtensilsCrossed,
  Cookie,
  Wine
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useNavigation } from '../../context/NavigationContext';
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Badge } from "../ui/badge";
import { cn } from "../ui/utils";

const categories = [
  { id: "All", label: "All Items", icon: Zap },
  { id: "Coffee", label: "Coffee", icon: Coffee },
  { id: "Bakery", label: "Bakery", icon: Cookie },
  { id: "Food", label: "Food", icon: UtensilsCrossed },
  { id: "Drinks", label: "Drinks", icon: Wine },
];

const products = [
  { id: 1, name: 'Espresso', retailPrice: 3.50, wholesalePrice: 2.80, category: 'Coffee', color: 'from-orange-600/20 to-orange-900/20', stock: 45 },
  { id: 2, name: 'Cappuccino', retailPrice: 4.50, wholesalePrice: 3.60, category: 'Coffee', color: 'from-amber-600/20 to-amber-900/20', stock: 32 },
  { id: 3, name: 'Latte', retailPrice: 4.75, wholesalePrice: 3.80, category: 'Coffee', color: 'from-yellow-600/20 to-yellow-900/20', stock: 28 },
  { id: 4, name: 'Mocha', retailPrice: 5.00, wholesalePrice: 4.00, category: 'Coffee', color: 'from-yellow-700/20 to-orange-900/20', stock: 18 },
  { id: 5, name: 'Americano', retailPrice: 3.00, wholesalePrice: 2.40, category: 'Coffee', color: 'from-stone-600/20 to-stone-900/20', stock: 50 },
  { id: 6, name: 'Croissant', retailPrice: 3.25, wholesalePrice: 2.50, category: 'Bakery', color: 'from-yellow-500/20 to-yellow-700/20', stock: 22 },
  { id: 7, name: 'Muffin', retailPrice: 2.75, wholesalePrice: 2.20, category: 'Bakery', color: 'from-pink-600/20 to-pink-900/20', stock: 15 },
  { id: 8, name: 'Bagel', retailPrice: 2.50, wholesalePrice: 2.00, category: 'Bakery', color: 'from-orange-500/20 to-orange-700/20', stock: 30 },
  { id: 9, name: 'Sandwich', retailPrice: 8.50, wholesalePrice: 6.80, category: 'Food', color: 'from-green-600/20 to-green-900/20', stock: 12 },
  { id: 10, name: 'Salad', retailPrice: 9.00, wholesalePrice: 7.20, category: 'Food', color: 'from-emerald-600/20 to-emerald-900/20', stock: 8 },
  { id: 11, name: 'Iced Tea', retailPrice: 3.00, wholesalePrice: 2.40, category: 'Drinks', color: 'from-teal-600/20 to-teal-900/20', stock: 40 },
  { id: 12, name: 'Smoothie', retailPrice: 6.50, wholesalePrice: 5.20, category: 'Drinks', color: 'from-purple-600/20 to-purple-900/20', stock: 25 },
];

interface CartItem {
  id: number;
  name: string;
  retailPrice: number;
  wholesalePrice: number;
  qty: number;
}

export const POS = () => {
  const { setCurrentView } = useNavigation();
  const [cart, setCart] = useState<CartItem[]>([]);
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState("All");
  const [isWholesale, setIsWholesale] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [discount, setDiscount] = useState(0);
  const [isStudioSale, setIsStudioSale] = useState(false);

  const addToCart = (product: any) => {
    setCart(prev => {
      const existing = prev.find(p => p.id === product.id);
      if (existing) {
        return prev.map(p => p.id === product.id ? { ...p, qty: p.qty + 1 } : p);
      }
      return [...prev, { ...product, qty: 1 }];
    });
  };

  const updateQty = (id: number, delta: number) => {
    setCart(prev => prev.map(p => {
      if (p.id === id) {
        const newQty = Math.max(0, p.qty + delta);
        return { ...p, qty: newQty };
      }
      return p;
    }).filter(p => p.qty > 0));
  };

  const removeItem = (id: number) => {
    setCart(prev => prev.filter(p => p.id !== id));
  };

  const clearCart = () => {
    setCart([]);
    setCustomerName('');
    setDiscount(0);
  };

  const getPrice = (item: any) => isWholesale ? item.wholesalePrice : item.retailPrice;

  const subtotal = cart.reduce((sum, item) => sum + (getPrice(item) * item.qty), 0);
  const discountAmount = (subtotal * discount) / 100;
  const afterDiscount = subtotal - discountAmount;
  const tax = afterDiscount * 0.10;
  const total = afterDiscount + tax;
  const cartCount = cart.reduce((sum, item) => sum + item.qty, 0);

  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = activeCategory === "All" || p.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#111827] text-white">
      {/* Left Section: Products */}
      <div className="flex-1 flex flex-col min-w-0">
        
        {/* Modern Header */}
        <div className="h-20 border-b border-gray-800 bg-gradient-to-r from-gray-900 to-gray-900/95 backdrop-blur-sm shrink-0">
          <div className="h-full px-6 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => setCurrentView('dashboard')} 
                className="text-gray-400 hover:text-white hover:bg-gray-800 rounded-xl"
              >
                <ArrowLeft size={20} />
              </Button>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">
                  POS Terminal
                </h1>
                <p className="text-xs text-gray-500">Point of Sale System</p>
              </div>
            </div>

            {/* Search Bar */}
            <div className="flex-1 max-w-md mx-8">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                <Input
                  type="text"
                  placeholder="Search products by name..."
                  className="w-full bg-gray-800/50 border-gray-700 rounded-xl pl-11 pr-4 h-11 text-white placeholder:text-gray-500 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
            </div>

            {/* Stats Badge */}
            <div className="flex items-center gap-3">
              <div className="px-4 py-2 bg-gray-800/50 rounded-xl border border-gray-700">
                <div className="flex items-center gap-2">
                  <Receipt size={16} className="text-blue-400" />
                  <span className="text-sm text-gray-400">Today:</span>
                  <span className="font-bold text-white">42</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Category Pills */}
        <div className="px-6 py-4 border-b border-gray-800 bg-gray-900/30 shrink-0">
          <div className="flex items-center gap-3 overflow-x-auto scrollbar-hide">
            {categories.map((cat) => {
              const Icon = cat.icon;
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={cn(
                    "flex items-center gap-2 px-5 py-2.5 rounded-xl font-medium transition-all whitespace-nowrap border-2",
                    isActive 
                      ? "bg-blue-600 text-white border-blue-500 shadow-lg shadow-blue-900/30" 
                      : "bg-gray-800/50 text-gray-400 hover:text-white border-gray-700 hover:border-gray-600 hover:bg-gray-800"
                  )}
                >
                  <Icon size={18} />
                  <span>{cat.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Products Grid */}
        <div className="flex-1 overflow-y-auto p-6 bg-[#111827]">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 gap-4 pb-8">
            <AnimatePresence>
              {filteredProducts.map((product) => (
                <motion.button
                  key={product.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  whileHover={{ scale: 1.02, y: -4 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => addToCart(product)}
                  className={cn(
                    "relative aspect-square p-5 rounded-2xl flex flex-col justify-between items-start text-left transition-all border-2 border-gray-700/50 bg-gradient-to-br hover:border-blue-500/50 shadow-lg hover:shadow-xl group overflow-hidden",
                    product.color || 'from-gray-800 to-gray-900'
                  )}
                >
                  {/* Stock Badge */}
                  <Badge 
                    variant="secondary" 
                    className="absolute top-3 right-3 bg-black/40 text-white text-[10px] px-2 py-0.5 border-0 backdrop-blur-sm"
                  >
                    {product.stock} left
                  </Badge>

                  {/* Product Name */}
                  <div className="z-10">
                    <h3 className="font-bold text-white text-lg leading-tight mb-1 group-hover:text-blue-300 transition-colors">
                      {product.name}
                    </h3>
                    <p className="text-xs text-gray-400">{product.category}</p>
                  </div>

                  {/* Price Section */}
                  <div className="z-10 w-full">
                    <div className="flex items-end justify-between">
                      <div>
                        <span className="text-2xl font-bold text-white">
                          ${(isWholesale ? product.wholesalePrice : product.retailPrice).toFixed(2)}
                        </span>
                        {isWholesale && (
                          <Badge className="ml-2 bg-green-500/20 text-green-400 border-green-500/30 text-[10px] px-1.5 py-0">
                            W
                          </Badge>
                        )}
                      </div>
                      <div className="bg-blue-600 text-white p-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity">
                        <Plus size={16} />
                      </div>
                    </div>
                  </div>

                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent pointer-events-none" />
                </motion.button>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* Right Section: Cart */}
      <div className="w-[460px] flex flex-col bg-gray-900 border-l border-gray-800 shadow-2xl shrink-0 h-full">
        
        {/* Cart Header */}
        <div className="h-20 border-b border-gray-800 px-6 flex items-center justify-between bg-gradient-to-b from-gray-900 to-gray-900/95 shrink-0">
          <div className="flex items-center gap-3">
            <div className="relative">
              <ShoppingCart className="text-blue-400" size={24} />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-blue-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </div>
            <div>
              <h2 className="font-bold text-lg text-white">Current Order</h2>
              <p className="text-xs text-gray-500">{cart.length} item(s)</p>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={clearCart} 
            disabled={cart.length === 0}
            className="text-red-400 hover:text-red-300 hover:bg-red-900/20 rounded-xl disabled:opacity-30"
          >
            <Trash2 size={18} />
          </Button>
        </div>

        {/* Customer Input Only (Removed Pricing/Discount) */}
        <div className="px-6 py-4 border-b border-gray-800 bg-gray-800/30 shrink-0 space-y-3">
          <div className="relative">
            <User className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={16} />
            <Input
              placeholder="Customer name (optional)"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              className="pl-10 bg-gray-950 border-gray-700 h-10 text-sm"
            />
          </div>
          
          {/* Studio Sale Checkbox */}
          <label className="flex items-center gap-3 cursor-pointer p-3 rounded-lg hover:bg-gray-800/50 transition-colors">
            <input
              type="checkbox"
              checked={isStudioSale}
              onChange={(e) => setIsStudioSale(e.target.checked)}
              className="w-5 h-5 rounded border-gray-700 bg-gray-950 checked:bg-purple-600 checked:border-purple-600 focus:ring-2 focus:ring-purple-500 focus:ring-offset-0"
            />
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-white">Studio Sale</span>
                <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30 text-xs">
                  Production
                </Badge>
              </div>
              <div className="text-xs text-gray-500 mt-0.5">
                Route to studio workflow for fabric processing
              </div>
            </div>
          </label>
        </div>

        {/* Cart Items (Scroll Fix) */}
        <div className="flex-1 overflow-y-auto p-6 scrollbar-thin scrollbar-thumb-gray-800 scrollbar-track-transparent">
          <div className="space-y-3">
            {cart.length === 0 ? (
              <div className="h-64 flex flex-col items-center justify-center text-gray-600 gap-4">
                <div className="w-20 h-20 rounded-full bg-gray-800/50 flex items-center justify-center">
                  <ShoppingCart size={32} className="text-gray-700" />
                </div>
                <div className="text-center">
                  <p className="font-medium text-gray-500">Cart is empty</p>
                  <p className="text-xs text-gray-600 mt-1">Add items to get started</p>
                </div>
              </div>
            ) : (
              <AnimatePresence>
                {cart.map((item, index) => (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ delay: index * 0.05 }}
                    className="bg-gray-800/50 p-4 rounded-xl border border-gray-700 hover:border-gray-600 transition-all group"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <h4 className="font-semibold text-white mb-1">{item.name}</h4>
                        <p className="text-sm text-gray-400">
                          ${getPrice(item).toFixed(2)} × {item.qty}
                        </p>
                      </div>
                      <div className="flex items-start gap-2">
                        <span className="text-lg font-bold text-blue-400">
                          ${(getPrice(item) * item.qty).toFixed(2)}
                        </span>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeItem(item.id)}
                          className="text-red-400 hover:text-red-300 hover:bg-red-900/20 h-8 w-8 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X size={14} />
                        </Button>
                      </div>
                    </div>

                    {/* Quantity Controls */}
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => updateQty(item.id, -1)}
                        className="h-9 w-9 rounded-lg bg-gray-900 border-gray-700 hover:bg-gray-800 hover:border-gray-600 text-gray-300"
                      >
                        <Minus size={14} />
                      </Button>
                      <div className="flex-1 text-center">
                        <span className="font-bold text-white text-lg">{item.qty}</span>
                      </div>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => updateQty(item.id, 1)}
                        className="h-9 w-9 rounded-lg bg-blue-600 border-blue-500 hover:bg-blue-500 text-white"
                      >
                        <Plus size={14} />
                      </Button>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            )}
          </div>
        </div>

        {/* Totals & Checkout */}
        <div className="p-6 bg-gray-950 border-t border-gray-800 space-y-4 shrink-0 shadow-[0_-10px_40px_rgba(0,0,0,0.5)] z-10">
          {/* Calculation Breakdown */}
          <div className="space-y-2 text-sm">
            <div className="flex justify-between text-gray-400">
              <span>Subtotal</span>
              <span className="font-medium">${subtotal.toFixed(2)}</span>
            </div>
            
            {discount > 0 && (
              <div className="flex justify-between text-green-400">
                <span>Discount ({discount}%)</span>
                <span className="font-medium">-${discountAmount.toFixed(2)}</span>
              </div>
            )}
            
            <div className="flex justify-between text-gray-400">
              <span>Tax (10%)</span>
              <span className="font-medium">${tax.toFixed(2)}</span>
            </div>
            
            <div className="flex justify-between text-white text-xl font-bold pt-3 border-t border-gray-800">
              <span>Total</span>
              <span className="bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">
                ${total.toFixed(2)}
              </span>
            </div>
          </div>

          {/* Payment Buttons */}
          <div className="grid grid-cols-2 gap-3">
            <button 
              disabled={cart.length === 0}
              className="bg-gradient-to-br from-green-600 to-green-700 hover:from-green-500 hover:to-green-600 disabled:from-gray-800 disabled:to-gray-800 disabled:text-gray-600 text-white py-4 rounded-xl font-bold flex flex-col items-center justify-center gap-2 transition-all active:scale-95 shadow-lg shadow-green-900/30 disabled:shadow-none border-2 border-green-500/20 disabled:border-gray-700"
            >
              <Banknote size={22} />
              <span>Cash Payment</span>
            </button>
            <button 
              disabled={cart.length === 0}
              className="bg-gradient-to-br from-blue-600 to-blue-700 hover:from-blue-500 hover:to-blue-600 disabled:from-gray-800 disabled:to-gray-800 disabled:text-gray-600 text-white py-4 rounded-xl font-bold flex flex-col items-center justify-center gap-2 transition-all active:scale-95 shadow-lg shadow-blue-900/30 disabled:shadow-none border-2 border-blue-500/20 disabled:border-gray-700"
            >
              <CreditCard size={22} />
              <span>Card Payment</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};