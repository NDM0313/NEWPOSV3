import React, { useState, useRef, useEffect } from 'react';
import { 
  X, 
  Search, 
  Plus, 
  Trash2, 
  Calendar as CalendarIcon, 
  Save, 
  CreditCard, 
  Banknote,
  FileText,
  User,
  Package,
  ArrowRight,
  Check, 
  ChevronsUpDown,
  Box,
  Layers,
  Ruler,
  Wallet,
  ArrowDownCircle,
  AlertCircle,
  ShoppingBag,
  DollarSign,
  Truck,
  Percent,
  UserCheck,
  Printer,
  Paperclip,
  Palette,
  Scissors,
  Sparkles,
  Building2,
  Lock
} from 'lucide-react';
import { format } from "date-fns";
import { cn } from "../ui/utils";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Separator } from "../ui/separator";
import { Badge } from "../ui/badge";
import { CalendarDatePicker } from "../ui/CalendarDatePicker";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../ui/table";
import {
    Command,
    CommandEmpty,
    CommandGroup,
    CommandInput,
    CommandItem,
    CommandList,
  } from "../ui/command";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "../ui/dropdown-menu";
import {
    Popover,
    PopoverContent,
    PopoverTrigger,
} from "../ui/popover";
import { PackingEntryModal, PackingDetails } from '../transactions/PackingEntryModal';
import { toast } from "sonner";
import { BranchSelector, currentUser } from '@/app/components/layout/BranchSelector';

// Mock Data
const customers = [
  { id: 1, name: "Walk-in Customer" },
  { id: 2, name: "Ahmed Khan" },
  { id: 3, name: "Fatima Ali" },
  { id: 4, name: "Bilal Textiles Ltd" },
];

const salesmen = [
  { id: 1, name: "No Salesman" },
  { id: 2, name: "Ali Hassan" },
  { id: 3, name: "Muhammad Bilal" },
  { id: 4, name: "Sara Khan" },
];

const productsMock = [
    { id: 1, name: "Premium Cotton Fabric", sku: "FAB-001", price: 850, stock: 50, hasVariations: false, needsPacking: true },
    { id: 2, name: "Lawn Print Floral", sku: "LWN-045", price: 1250, stock: 120, hasVariations: false, needsPacking: true },
    { id: 3, name: "Silk Dupatta", sku: "SLK-022", price: 1800, stock: 35, hasVariations: true, needsPacking: false },
    { id: 4, name: "Unstitched 3-Pc Suit", sku: "SUIT-103", price: 4500, stock: 18, hasVariations: true, needsPacking: false },
    { id: 5, name: "Chiffon Fabric", sku: "CHF-078", price: 950, stock: 65, hasVariations: false, needsPacking: true },
];

interface SaleItem {
    id: number;
    productId: number;
    name: string;
    sku: string;
    price: number;
    qty: number;
    // Standard Variation Fields
    size?: string;
    color?: string;
    // Standard Packing Fields (Wholesale)
    thaans?: number;
    meters?: number;
    packingDetails?: PackingDetails;
}

interface PartialPayment {
    id: string;
    method: 'cash' | 'bank' | 'other';
    amount: number;
    reference?: string;
    notes?: string;
}

interface ExtraExpense {
    id: string;
    type: 'stitching' | 'lining' | 'dying' | 'cargo' | 'other';
    amount: number;
    notes?: string;
}

export const SaleForm = ({ onClose }: { onClose: () => void }) => {
    // Header State
    const [customerId, setCustomerId] = useState("");
    const [customerSearchOpen, setCustomerSearchOpen] = useState(false);
    const [saleDate, setSaleDate] = useState<Date>(new Date());
    const [refNumber, setRefNumber] = useState("");
    const [invoiceNumber, setInvoiceNumber] = useState("");
    
    // Branch State - Locked for regular users, open for admin
    const [branchId, setBranchId] = useState<string>(currentUser.assignedBranchId.toString());
    
    // Items List State
    const [items, setItems] = useState<SaleItem[]>([]);
    
    // --- New Entry Row State (The "Stage") ---
    const [productSearchOpen, setProductSearchOpen] = useState(false);
    const [productSearchTerm, setProductSearchTerm] = useState("");
    const [pendingProduct, setPendingProduct] = useState<any | null>(null);
    const [pendingQty, setPendingQty] = useState<number>(1);
    const [pendingPrice, setPendingPrice] = useState<number>(0);
    // Standard Variation States
    const [pendingSize, setPendingSize] = useState<string>("");
    const [pendingColor, setPendingColor] = useState<string>("");
    // Standard Packing States
    const [pendingThaans, setPendingThaans] = useState<number>(0);
    const [pendingMeters, setPendingMeters] = useState<number>(0);
    
    // Focus Refs
    const searchInputRef = useRef<HTMLInputElement>(null);
    const qtyInputRef = useRef<HTMLInputElement>(null);
    const priceInputRef = useRef<HTMLInputElement>(null);
    const addBtnRef = useRef<HTMLButtonElement>(null);

    // Payment State
    const [partialPayments, setPartialPayments] = useState<PartialPayment[]>([]);
    
    // Payment Form State
    const [newPaymentMethod, setNewPaymentMethod] = useState<'cash' | 'bank' | 'other'>('cash');
    const [newPaymentAmount, setNewPaymentAmount] = useState<number>(0);
    const [newPaymentReference, setNewPaymentReference] = useState<string>("");

    // Extra Expenses State
    const [extraExpenses, setExtraExpenses] = useState<ExtraExpense[]>([]);
    const [newExpenseType, setNewExpenseType] = useState<'stitching' | 'lining' | 'dying' | 'cargo' | 'other'>('stitching');
    const [newExpenseAmount, setNewExpenseAmount] = useState<number>(0);
    const [newExpenseNotes, setNewExpenseNotes] = useState<string>("");

    // Discount State
    const [discountType, setDiscountType] = useState<'percentage' | 'fixed'>('percentage');
    const [discountValue, setDiscountValue] = useState<number>(0);

    // Salesman State (moved to header)
    const [salesmanId, setSalesmanId] = useState<string>("1"); // Default to "No Salesman"
    const [commissionType, setCommissionType] = useState<'percentage' | 'fixed'>('percentage');
    const [commissionValue, setCommissionValue] = useState<number>(0);

    // Shipping State (Optional - enabled via checkbox)
    const [shippingEnabled, setShippingEnabled] = useState<boolean>(false);
    const [shippingAddress, setShippingAddress] = useState<string>("");
    const [shippingCharges, setShippingCharges] = useState<number>(0);

    // Studio Sale State
    const [isStudioSale, setIsStudioSale] = useState<boolean>(false);
    const [studioNotes, setStudioNotes] = useState<string>("");

    // Status State (Draft, Quotation, Final, etc.)
    const [saleStatus, setSaleStatus] = useState<'draft' | 'quotation' | 'order' | 'final'>('draft');
    const [studioDeadline, setStudioDeadline] = useState<Date | undefined>(undefined);

    // Packing Modal State
    const [packingModalOpen, setPackingModalOpen] = useState(false);
    const [activePackingItemId, setActivePackingItemId] = useState<number | null>(null);
    const [activeProductName, setActiveProductName] = useState("");
    const [activePackingData, setActivePackingData] = useState<PackingDetails | undefined>(undefined);

    // Calculations
    const subtotal = items.reduce((sum, item) => sum + (item.price * item.qty), 0);
    const expensesTotal = extraExpenses.reduce((sum, exp) => sum + exp.amount, 0);
    
    // Calculate discount amount
    const discountAmount = discountType === 'percentage' 
        ? (subtotal * discountValue) / 100 
        : discountValue;
    
    // Calculate shipping (only if enabled)
    const finalShippingCharges = shippingEnabled ? shippingCharges : 0;
    
    // Calculate total after discount and expenses
    const afterDiscountTotal = subtotal - discountAmount + expensesTotal;
    const totalAmount = afterDiscountTotal + finalShippingCharges;
    
    // Calculate salesman commission
    const commissionAmount = commissionType === 'percentage'
        ? (subtotal * commissionValue) / 100
        : commissionValue;
    
    // Automatic Payment Status Detection
    const totalPaid = partialPayments.reduce((sum, p) => sum + p.amount, 0);
    const balanceDue = totalAmount - totalPaid;
    
    // Auto-detect payment status
    const paymentStatus = totalPaid === 0 ? 'credit' : totalPaid >= totalAmount ? 'paid' : 'partial';

    const getSalesmanName = () => salesmen.find(s => s.id.toString() === salesmanId)?.name || "No Salesman";

    // Status helper functions
    const getStatusColor = () => {
        switch(saleStatus) {
            case 'draft': return 'text-gray-500 bg-gray-900/50 border-gray-700';
            case 'quotation': return 'text-yellow-500 bg-yellow-900/20 border-yellow-600/50';
            case 'order': return 'text-blue-500 bg-blue-900/20 border-blue-600/50';
            case 'final': return 'text-green-500 bg-green-900/20 border-green-600/50';
            default: return 'text-gray-500 bg-gray-900/50 border-gray-700';
        }
    };

    const getStatusIcon = () => {
        switch(saleStatus) {
            case 'draft': return <FileText size={14} />;
            case 'quotation': return <FileText size={14} />;
            case 'order': return <ShoppingBag size={14} />;
            case 'final': return <Check size={14} />;
            default: return <FileText size={14} />;
        }
    };

    // --- Workflow Handlers ---

    // 1. Select Product -> Move to Qty
    const handleSelectProduct = (product: any) => {
        setPendingProduct(product);
        setPendingPrice(product.price);
        setPendingQty(1);
        setProductSearchTerm(product.name);
        setProductSearchOpen(false);
        
        // Focus Qty Input after a short delay to allow UI update
        setTimeout(() => {
            qtyInputRef.current?.focus();
            qtyInputRef.current?.select();
        }, 50);
    };

    // 2. Clear Pending Row (Reset to Search)
    const resetEntryRow = () => {
        setPendingProduct(null);
        setProductSearchTerm("");
        setPendingQty(1);
        setPendingPrice(0);
        setPendingSize("");
        setPendingColor("");
        setPendingThaans(0);
        setPendingMeters(0);
        
        // Focus Search Input
        setTimeout(() => {
            searchInputRef.current?.focus();
        }, 50);
    };

    // 3. Add to List -> Loop back to Search
    const commitPendingItem = () => {
        if (!pendingProduct) {
            toast.error("Please select a product first");
            searchInputRef.current?.focus();
            return;
        }
        if (pendingQty <= 0) {
            toast.error("Quantity must be greater than 0");
            qtyInputRef.current?.focus();
            return;
        }

        const newItem: SaleItem = {
            id: Date.now(),
            productId: pendingProduct.id,
            name: pendingProduct.name,
            sku: pendingProduct.sku,
            price: pendingPrice,
            qty: pendingQty,
            // Add variation if provided
            size: pendingSize || undefined,
            color: pendingColor || undefined,
            // Add packing if provided
            thaans: pendingThaans > 0 ? pendingThaans : undefined,
            meters: pendingMeters > 0 ? pendingMeters : undefined,
        };

        setItems(prev => {
            return [newItem, ...prev]; 
        });

        toast.success("Item added");
        resetEntryRow();
    };

    // Keyboard Navigation in Entry Row
    const handleQtyKeyDown = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            priceInputRef.current?.focus();
            priceInputRef.current?.select();
        }
    };

    const handlePriceKeyDown = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            commitPendingItem();
        }
    };

    // Items List Handlers
    const updateItem = (id: number, field: keyof SaleItem, value: number) => {
        setItems(prev => prev.map(item => item.id === id ? { ...item, [field]: value } : item));
    };

    const removeItem = (id: number) => {
        setItems(prev => prev.filter(item => item.id !== id));
    };

    // Packing Handlers
    const openPackingModal = (item: SaleItem) => {
        setActivePackingItemId(item.id);
        setActiveProductName(item.name);
        setActivePackingData(item.packingDetails);
        setPackingModalOpen(true);
    };

    const handleSavePacking = (details: PackingDetails) => {
        if (activePackingItemId !== null) {
            setItems(prev => prev.map(item => {
                if (item.id === activePackingItemId) {
                    return { 
                        ...item, 
                        packingDetails: details,
                        qty: details.total_meters // Auto-update quantity based on meters
                    };
                }
                return item;
            }));
        }
        setPackingModalOpen(false);
    };

    // Payment Handlers
    const addPartialPayment = () => {
        if (newPaymentAmount <= 0) return;
        
        setPartialPayments(prev => [...prev, {
            id: Date.now().toString(),
            method: newPaymentMethod,
            amount: newPaymentAmount,
            reference: newPaymentReference
        }]);
        setNewPaymentAmount(0); // Reset input
        setNewPaymentReference("");
    };

    const removePartialPayment = (id: string) => {
        setPartialPayments(prev => prev.filter(p => p.id !== id));
    };

    // Extra Expenses Handlers
    const addExtraExpense = () => {
        if (newExpenseAmount <= 0) return;
        
        setExtraExpenses(prev => [...prev, {
            id: Date.now().toString(),
            type: newExpenseType,
            amount: newExpenseAmount,
            notes: newExpenseNotes
        }]);
        setNewExpenseAmount(0); // Reset input
        setNewExpenseNotes("");
        toast.success("Expense added");
    };

    const removeExtraExpense = (id: string) => {
        setExtraExpenses(prev => prev.filter(exp => exp.id !== id));
    };

    const getCustomerName = () => customers.find(c => c.id.toString() === customerId)?.name || "Select Customer";

    return (
        <div className="flex flex-col h-full bg-[#111827] text-white overflow-hidden">
            {/* 1. Top Header */}
            <div className="h-16 shrink-0 bg-[#0B1019] border-b border-gray-800 flex items-center justify-between px-6 z-20">
                <div className="flex items-center gap-4">
                    <Button variant="ghost" size="icon" onClick={onClose} className="text-gray-400 hover:text-white">
                        <X size={20} />
                    </Button>
                    <div>
                        <h2 className="text-lg font-bold text-white">New Sale Invoice</h2>
                        <div className="flex items-center gap-2 text-xs text-gray-400">
                            <span>Standard Entry</span>
                            <span className="w-1 h-1 rounded-full bg-gray-600" />
                            <span>{items.length} Items</span>
                        </div>
                    </div>
                </div>
                <div className="flex items-center gap-3">
                    {/* Global Branch Selector */}
                    <BranchSelector branchId={branchId} setBranchId={setBranchId} variant="header" />
                </div>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-6">
                
                {/* 2. Customer & Info Section (Compact - 7 Columns Single Row) */}
                <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-5">
                    <div className="grid grid-cols-1 md:grid-cols-7 gap-3">
                            <div className="space-y-1.5">
                                <Label className="text-blue-400 font-medium text-xs uppercase tracking-wide">Customer</Label>
                                <Popover open={customerSearchOpen} onOpenChange={setCustomerSearchOpen}>
                                    <PopoverTrigger asChild>
                                        <Button variant="outline" role="combobox" className="w-full justify-between bg-gray-950 border-gray-700 text-white hover:bg-gray-900 h-10">
                                            <div className="flex items-center gap-2 truncate">
                                                <User size={14} className="text-gray-400 shrink-0" />
                                                <span className="truncate text-sm">{getCustomerName()}</span>
                                            </div>
                                            <ChevronsUpDown className="ml-2 h-3 w-3 opacity-50 shrink-0" />
                                        </Button>
                                    </PopoverTrigger>
                                    <PopoverContent className="w-[300px] p-0 bg-gray-950 border-gray-800 text-white">
                                        <Command className="bg-gray-950 text-white">
                                            <CommandInput placeholder="Search customer..." className="h-9" />
                                            <CommandList>
                                                <CommandEmpty>No customer found.</CommandEmpty>
                                                <CommandGroup>
                                                    {customers.map((c) => (
                                                        <CommandItem
                                                            key={c.id}
                                                            value={c.name}
                                                            onSelect={() => {
                                                                setCustomerId(c.id.toString());
                                                                setCustomerSearchOpen(false);
                                                            }}
                                                            className="text-white hover:bg-gray-800 cursor-pointer"
                                                        >
                                                            <Check className={cn("mr-2 h-4 w-4", customerId === c.id.toString() ? "opacity-100" : "opacity-0")} />
                                                            {c.name}
                                                        </CommandItem>
                                                    ))}
                                                </CommandGroup>
                                            </CommandList>
                                        </Command>
                                    </PopoverContent>
                                </Popover>
                            </div>

                            <div className="space-y-1.5">
                                <CalendarDatePicker
                                    label="Date"
                                    value={saleDate}
                                    onChange={(date) => setSaleDate(date || new Date())}
                                    showTime={true}
                                    required
                                />
                            </div>

                            <div className="space-y-1.5">
                                <Label className="text-gray-500 font-medium text-xs uppercase tracking-wide">Ref#</Label>
                                <div className="relative">
                                    <FileText className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-600" size={14} />
                                    <Input 
                                        value={refNumber}
                                        onChange={(e) => setRefNumber(e.target.value)}
                                        className="pl-9 bg-gray-950 border-gray-700 h-10 text-sm"
                                        placeholder="SO-001"
                                    />
                                </div>
                            </div>

                            <div className="space-y-1.5">
                                <Label className="text-gray-500 font-medium text-xs uppercase tracking-wide">Invoice#</Label>
                                <div className="relative">
                                    <FileText className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-600" size={14} />
                                    <Input 
                                        value={invoiceNumber}
                                        onChange={(e) => setInvoiceNumber(e.target.value)}
                                        className="pl-9 bg-gray-950 border-gray-700 h-10 text-sm"
                                        placeholder="INV-001"
                                    />
                                </div>
                            </div>

                            <div className="space-y-1.5">
                                <Label className="text-cyan-500 font-medium text-xs uppercase tracking-wide">Status</Label>
                                <Select value={saleStatus} onValueChange={(v: any) => setSaleStatus(v)}>
                                    <SelectTrigger className={`h-10 border ${getStatusColor()}`}>
                                        <div className="flex items-center gap-2">
                                            {getStatusIcon()}
                                            <SelectValue />
                                        </div>
                                    </SelectTrigger>
                                    <SelectContent className="bg-gray-950 border-gray-800 text-white">
                                        <SelectItem value="draft">
                                            <div className="flex items-center gap-2">
                                                <span className="w-2 h-2 rounded-full bg-gray-500"></span>
                                                Draft
                                            </div>
                                        </SelectItem>
                                        <SelectItem value="quotation">
                                            <div className="flex items-center gap-2">
                                                <span className="w-2 h-2 rounded-full bg-yellow-500"></span>
                                                Quotation
                                            </div>
                                        </SelectItem>
                                        <SelectItem value="order">
                                            <div className="flex items-center gap-2">
                                                <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                                                Order
                                            </div>
                                        </SelectItem>
                                        <SelectItem value="final">
                                            <div className="flex items-center gap-2">
                                                <span className="w-2 h-2 rounded-full bg-green-500"></span>
                                                Final
                                            </div>
                                        </SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>

                            <div className="space-y-1.5">
                                <Label className="text-green-500 font-medium text-xs uppercase tracking-wide">Salesman</Label>
                                <Select value={salesmanId} onValueChange={setSalesmanId}>
                                    <SelectTrigger className="bg-gray-950 border-gray-700 text-white h-10">
                                        <div className="flex items-center gap-2">
                                            <UserCheck size={14} className="text-gray-400 shrink-0" />
                                            <span className="truncate text-sm">{getSalesmanName()}</span>
                                        </div>
                                    </SelectTrigger>
                                    <SelectContent className="bg-gray-950 border-gray-800 text-white">
                                        {salesmen.map(s => (
                                            <SelectItem key={s.id} value={s.id.toString()}>{s.name}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>

                            <div className="space-y-1.5">
                                <Label className={`font-medium text-xs uppercase tracking-wide ${isStudioSale ? 'text-purple-500' : 'text-gray-500'}`}>
                                    Type {isStudioSale && <Badge className="ml-1 bg-purple-600 text-white text-[8px] px-1 py-0">ST</Badge>}
                                </Label>
                                <div className="flex gap-1">
                                    <Select 
                                        value={isStudioSale ? 'studio' : 'regular'} 
                                        onValueChange={(v) => {
                                            setIsStudioSale(v === 'studio');
                                            if (v === 'studio') setShippingEnabled(false);
                                        }}
                                    >
                                        <SelectTrigger className={`bg-gray-950 h-10 flex-1 ${ 
                                            isStudioSale 
                                                ? 'border-purple-500/50 text-purple-400' 
                                                : 'border-gray-700 text-white'
                                        }`}>
                                            <div className="flex items-center gap-2">
                                                {isStudioSale ? <Palette size={14} /> : <ShoppingBag size={14} />}
                                                <SelectValue />
                                            </div>
                                        </SelectTrigger>
                                        <SelectContent className="bg-gray-950 border-gray-800 text-white">
                                            <SelectItem value="regular">Regular</SelectItem>
                                            <SelectItem value="studio">Studio</SelectItem>
                                        </SelectContent>
                                    </Select>
                                    {!isStudioSale && (
                                        <button
                                            onClick={() => setShippingEnabled(!shippingEnabled)}
                                            className={`w-10 h-10 rounded-lg transition-all flex items-center justify-center shrink-0 ${ 
                                                shippingEnabled
                                                    ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                                                    : 'bg-gray-800 text-gray-500 border border-gray-700 hover:bg-gray-750'
                                            }`}
                                            title="Shipping"
                                        >
                                            <Truck size={14} />
                                        </button>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>

                        {/* Studio Details - Inline when active */}
                        {isStudioSale && (
                            <div className="bg-purple-500/5 border border-purple-500/20 rounded-lg p-2 flex items-center gap-2 flex-wrap">
                                <div className="flex items-center gap-1.5 text-xs text-purple-400">
                                    <Palette size={12} />
                                    <Scissors size={12} />
                                    <Sparkles size={12} />
                                </div>
                                <div className="w-40">
                                    <CalendarDatePicker
                                        value={studioDeadline}
                                        onChange={setStudioDeadline}
                                        placeholder="Deadline"
                                        showTime={false}
                                    />
                                </div>
                                <Input 
                                    placeholder="Notes..."
                                    value={studioNotes}
                                    onChange={(e) => setStudioNotes(e.target.value)}
                                    className="flex-1 min-w-[150px] h-7 bg-gray-950 border-purple-500/30 text-white text-xs placeholder:text-purple-400/30"
                                />
                            </div>
                        )}

                {/* 3. Items Entry - REDESIGNED COMPACT */}
                <div className="space-y-3">
                            <div className="flex items-center justify-between">
                                <h3 className="text-sm font-semibold text-gray-300 uppercase tracking-wide flex items-center gap-2">
                                    <ShoppingBag size={16} className="text-blue-500" />
                                    Items Entry
                                </h3>
                                <div className="text-xs text-gray-500">
                                    <span className="flex items-center gap-1"><span className="px-1.5 py-0.5 bg-gray-800 rounded border border-gray-700 text-[10px]">Enter</span> to add</span>
                                </div>
                            </div>
                            
                            {/* The "Entry Stage" Card - MODERN INLINE FLOW */}
                            <div className="bg-[#0B1019] border border-blue-500/30 rounded-xl overflow-hidden shadow-lg shadow-blue-900/5">
                                <div className="flex items-stretch">
                                    {/* Blue accent bar */}
                                    <div className="w-1 bg-blue-500 flex-shrink-0" />
                                    
                                    <div className="flex-1 p-4">
                                        <div className="flex flex-col lg:flex-row gap-3 items-stretch">
                                            {/* 1. Find Product - Always Visible */}
                                            <div className="flex-1 min-w-[250px]">
                                                <Label className="text-xs text-blue-400 mb-1.5 block font-semibold">Find Product</Label>
                                                <Popover open={productSearchOpen} onOpenChange={setProductSearchOpen}>
                                                    <PopoverTrigger asChild>
                                                        <div className="relative">
                                                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={16} />
                                                            <Input
                                                                ref={searchInputRef}
                                                                placeholder="Scan barcode or search..."
                                                                value={productSearchTerm}
                                                                onChange={(e) => {
                                                                    setProductSearchTerm(e.target.value);
                                                                    setProductSearchOpen(true);
                                                                }}
                                                                onClick={() => setProductSearchOpen(true)}
                                                                className="pl-10 pr-9 h-11 bg-gray-900 border-gray-700 focus:border-blue-500 focus:ring-1 focus:ring-blue-500/50 text-base"
                                                            />
                                                            {pendingProduct && (
                                                                <button 
                                                                    onClick={(e) => {
                                                                        e.stopPropagation();
                                                                        resetEntryRow();
                                                                    }}
                                                                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white transition-colors"
                                                                >
                                                                    <X size={14} />
                                                                </button>
                                                            )}
                                                        </div>
                                                    </PopoverTrigger>
                                                <PopoverContent 
                                                    className="w-[400px] p-0 bg-gray-950 border-gray-800 text-white" 
                                                    align="start"
                                                    onOpenAutoFocus={(e) => e.preventDefault()}
                                                >
                                                    <Command className="bg-gray-950 text-white">
                                                        <CommandInput className="hidden" value={productSearchTerm} onValueChange={setProductSearchTerm} />
                                                        <CommandList>
                                                            <CommandEmpty className="p-2 text-gray-500 text-sm text-center py-4">
                                                                No products found
                                                            </CommandEmpty>
                                                            <CommandGroup heading="Available Products">
                                                                {productsMock.filter(p => 
                                                                    p.name.toLowerCase().includes(productSearchTerm.toLowerCase()) || 
                                                                    p.sku.toLowerCase().includes(productSearchTerm.toLowerCase())
                                                                ).map((product) => (
                                                                    <CommandItem
                                                                        key={product.id}
                                                                        value={product.name}
                                                                        onSelect={() => handleSelectProduct(product)}
                                                                        className="text-white hover:bg-gray-800 cursor-pointer flex justify-between"
                                                                    >
                                                                        <div className="flex flex-col">
                                                                            <span>{product.name}</span>
                                                                            <span className="text-xs text-gray-500">{product.sku}</span>
                                                                        </div>
                                                                        <div className="text-right">
                                                                            <span className="text-xs text-gray-400 block">Stock: {product.stock}</span>
                                                                            <span className="text-xs font-mono text-green-500">${product.price}</span>
                                                                        </div>
                                                                    </CommandItem>
                                                                ))}
                                                            </CommandGroup>
                                                        </CommandList>
                                                    </Command>
                                                </PopoverContent>
                                            </Popover>
                                        </div>

                                            {/* Conditional Fields - Only show when product selected */}
                                            {pendingProduct && (
                                                <>
                                                    {/* 2. Size (Standard Variation) */}
                                                    {pendingProduct.hasVariations && (
                                                        <div className="w-28 lg:w-32 animate-in slide-in-from-left duration-200">
                                                            <Label className="text-xs text-purple-400 mb-1.5 block font-semibold">Size</Label>
                                                            <Select value={pendingSize} onValueChange={setPendingSize}>
                                                                <SelectTrigger className="h-11 bg-gray-900 border-purple-500/50 text-white">
                                                                    <SelectValue placeholder="..." />
                                                                </SelectTrigger>
                                                                <SelectContent className="bg-gray-950 border-gray-800 text-white">
                                                                    <SelectItem value="S">Small</SelectItem>
                                                                    <SelectItem value="M">Medium</SelectItem>
                                                                    <SelectItem value="L">Large</SelectItem>
                                                                    <SelectItem value="XL">X-Large</SelectItem>
                                                                    <SelectItem value="XXL">XX-Large</SelectItem>
                                                                </SelectContent>
                                                            </Select>
                                                        </div>
                                                    )}

                                                    {/* 3. Color (Standard Variation) */}
                                                    {pendingProduct.hasVariations && (
                                                        <div className="w-28 lg:w-32 animate-in slide-in-from-left duration-200">
                                                            <Label className="text-xs text-purple-400 mb-1.5 block font-semibold">Color</Label>
                                                            <Select value={pendingColor} onValueChange={setPendingColor}>
                                                                <SelectTrigger className="h-11 bg-gray-900 border-purple-500/50 text-white">
                                                                    <SelectValue placeholder="..." />
                                                                </SelectTrigger>
                                                                <SelectContent className="bg-gray-950 border-gray-800 text-white">
                                                                    <SelectItem value="Red">Red</SelectItem>
                                                                    <SelectItem value="Blue">Blue</SelectItem>
                                                                    <SelectItem value="Black">Black</SelectItem>
                                                                    <SelectItem value="White">White</SelectItem>
                                                                    <SelectItem value="Green">Green</SelectItem>
                                                                </SelectContent>
                                                            </Select>
                                                        </div>
                                                    )}

                                                    {/* 4. Thaans (Standard Packing - Wholesale) */}
                                                    {pendingProduct.needsPacking && (
                                                        <div className="w-24 lg:w-28 animate-in slide-in-from-left duration-200">
                                                            <Label className="text-xs text-orange-400 mb-1.5 block font-semibold">Thaans</Label>
                                                            <Input
                                                                type="number"
                                                                value={pendingThaans || ""}
                                                                onChange={(e) => setPendingThaans(parseFloat(e.target.value) || 0)}
                                                                placeholder="0"
                                                                className="h-11 bg-gray-900 border-orange-500/50 text-center text-lg font-bold text-orange-400"
                                                            />
                                                        </div>
                                                    )}

                                                    {/* 5. Meters (Standard Packing - Wholesale) */}
                                                    {pendingProduct.needsPacking && (
                                                        <div className="w-28 lg:w-32 animate-in slide-in-from-left duration-200">
                                                            <Label className="text-xs text-orange-400 mb-1.5 block font-semibold">Meters</Label>
                                                            <Input
                                                                type="number"
                                                                value={pendingMeters || ""}
                                                                onChange={(e) => setPendingMeters(parseFloat(e.target.value) || 0)}
                                                                placeholder="0"
                                                                className="h-11 bg-gray-900 border-orange-500/50 text-center text-lg font-bold text-orange-400"
                                                            />
                                                        </div>
                                                    )}

                                                    {/* 4. Quantity */}
                                                    <div className="w-24 lg:w-28 animate-in slide-in-from-left duration-200">
                                                        <Label className="text-xs text-gray-400 mb-1.5 block font-semibold">Qty</Label>
                                                        <Input 
                                                            ref={qtyInputRef}
                                                            type="number"
                                                            value={pendingQty}
                                                            onChange={(e) => setPendingQty(parseFloat(e.target.value) || 0)}
                                                            onKeyDown={handleQtyKeyDown}
                                                            className="h-11 bg-gray-900 border-gray-700 focus:border-blue-500 text-center text-lg font-bold"
                                                        />
                                                    </div>

                                                    {/* 5. Price */}
                                                    <div className="w-32 lg:w-36 animate-in slide-in-from-left duration-200">
                                                        <Label className="text-xs text-gray-400 mb-1.5 block font-semibold">Price</Label>
                                                        <div className="relative">
                                                            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">$</span>
                                                            <Input 
                                                                ref={priceInputRef}
                                                                type="number"
                                                                value={pendingPrice}
                                                                onChange={(e) => setPendingPrice(parseFloat(e.target.value) || 0)}
                                                                onKeyDown={handlePriceKeyDown}
                                                                className="h-11 pl-7 bg-gray-900 border-gray-700 focus:border-blue-500 text-right text-lg"
                                                            />
                                                        </div>
                                                    </div>

                                                    {/* 6. Add Button */}
                                                    <div className="w-full lg:w-auto animate-in slide-in-from-left duration-200">
                                                        <Label className="text-xs text-transparent mb-1.5 block select-none">Add</Label>
                                                        <Button 
                                                            ref={addBtnRef}
                                                            onClick={commitPendingItem}
                                                            className="w-full lg:w-auto h-11 px-6 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white shadow-lg shadow-blue-900/30 font-semibold"
                                                        >
                                                            <ArrowDownCircle size={18} className="mr-2" /> Add
                                                        </Button>
                                                    </div>
                                                </>
                                            )}
                                        </div>
                                        
                                        {/* Selected Product Info Bar - Shows after selection */}
                                        {pendingProduct && (
                                            <div className="mt-3 pt-3 border-t border-gray-800 flex items-center justify-between text-xs animate-in fade-in duration-200">
                                                <div className="flex items-center gap-3 flex-wrap">
                                                    <span className="text-gray-500">Selected:</span>
                                                    <span className="text-white font-medium">{pendingProduct.name}</span>
                                                    <span className="text-gray-600">•</span>
                                                    <span className="text-gray-500 font-mono">{pendingProduct.sku}</span>
                                                    <span className="text-gray-600">•</span>
                                                    <span className="text-green-500">Stock: {pendingProduct.stock}</span>
                                                </div>
                                                <span className="text-gray-500 text-[10px] hidden lg:block">Press Enter to add</span>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* 4. Items List Table */}
                        <div className="border border-gray-800 rounded-xl overflow-hidden bg-gray-900/30 min-h-[300px] flex flex-col">
                            <Table>
                                <TableHeader className="bg-gray-950/50">
                                    <TableRow className="border-gray-800 hover:bg-transparent">
                                        <TableHead className="text-gray-400 pl-4 w-[50px]">#</TableHead>
                                        <TableHead className="text-gray-400">Product Details</TableHead>
                                        <TableHead className="text-gray-400 w-[160px]">Packing Info</TableHead>
                                        <TableHead className="text-gray-400 w-[120px] text-right">Price</TableHead>
                                        <TableHead className="text-gray-400 w-[100px] text-center">Qty</TableHead>
                                        <TableHead className="text-gray-400 w-[140px] text-right">Total</TableHead>
                                        <TableHead className="w-[50px]"></TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {items.length === 0 ? (
                                        <TableRow className="border-gray-800 hover:bg-transparent">
                                            <TableCell colSpan={7} className="h-40 text-center text-gray-600">
                                                <div className="flex flex-col items-center gap-2">
                                                    <ShoppingBag size={32} className="opacity-20" />
                                                    <p>No items added yet</p>
                                                    <p className="text-xs">Search for products above to build your invoice</p>
                                                </div>
                                            </TableCell>
                                        </TableRow>
                                    ) : (
                                        items.map((item, index) => (
                                            <TableRow key={item.id} className="border-gray-800 hover:bg-gray-800/50 group">
                                                <TableCell className="text-gray-500 pl-4 font-mono text-xs">
                                                    {(items.length - index).toString().padStart(2, '0')}
                                                </TableCell>
                                                <TableCell>
                                                    <div>
                                                        <div className="font-medium text-white">{item.name}</div>
                                                        <div className="text-xs text-gray-500 font-mono flex items-center gap-2">
                                                            <span>{item.sku}</span>
                                                            {item.size && (
                                                                <>
                                                                    <span className="text-gray-700">•</span>
                                                                    <Badge className="bg-purple-900/30 text-purple-400 border-purple-500/30 text-[10px] px-1.5 py-0">
                                                                        {item.size}
                                                                    </Badge>
                                                                </>
                                                            )}
                                                            {item.color && (
                                                                <>
                                                                    <span className="text-gray-700">•</span>
                                                                    <Badge className="bg-purple-900/30 text-purple-400 border-purple-500/30 text-[10px] px-1.5 py-0">
                                                                        {item.color}
                                                                    </Badge>
                                                                </>
                                                            )}
                                                        </div>
                                                    </div>
                                                </TableCell>
                                                <TableCell>
                                                    {item.thaans || item.meters ? (
                                                        <div className="flex items-center gap-2 text-xs">
                                                            {item.thaans && (
                                                                <Badge className="bg-orange-900/30 text-orange-400 border-orange-500/30 text-[10px] px-2 py-0.5">
                                                                    <Box size={10} className="mr-1" />
                                                                    {item.thaans} Th
                                                                </Badge>
                                                            )}
                                                            {item.meters && (
                                                                <Badge className="bg-orange-900/30 text-orange-400 border-orange-500/30 text-[10px] px-2 py-0.5">
                                                                    <Ruler size={10} className="mr-1" />
                                                                    {item.meters}M
                                                                </Badge>
                                                            )}
                                                        </div>
                                                    ) : (
                                                        <span className="text-gray-600 text-xs">—</span>
                                                    )}
                                                </TableCell>
                                                <TableCell className="text-right">
                                                    <Input 
                                                        type="number"
                                                        className="h-7 w-20 text-right bg-transparent border-transparent hover:border-gray-700 focus:bg-gray-950 focus:border-blue-500 p-1 text-sm"
                                                        value={item.price}
                                                        onChange={(e) => updateItem(item.id, 'price', parseFloat(e.target.value) || 0)}
                                                    />
                                                </TableCell>
                                                <TableCell className="text-center">
                                                     <div className="flex items-center justify-center gap-1">
                                                        <Input 
                                                            type="number"
                                                            className="h-7 w-16 text-center bg-transparent border-transparent hover:border-gray-700 focus:bg-gray-950 focus:border-blue-500 p-1 text-sm font-medium"
                                                            value={item.qty}
                                                            onChange={(e) => updateItem(item.id, 'qty', parseFloat(e.target.value) || 0)}
                                                            disabled={!!item.packingDetails}
                                                        />
                                                     </div>
                                                </TableCell>
                                                <TableCell className="text-right font-medium text-white">
                                                    ${(item.price * item.qty).toLocaleString()}
                                                </TableCell>
                                                <TableCell>
                                                    <Button variant="ghost" size="icon" onClick={() => removeItem(item.id)} className="h-8 w-8 text-gray-500 hover:text-red-400 hover:bg-red-900/10 opacity-0 group-hover:opacity-100 transition-opacity">
                                                        <Trash2 size={14} />
                                                    </Button>
                                                </TableCell>
                                            </TableRow>
                                        ))
                                    )}
                                </TableBody>
                            </Table>
                        </div>

                {/* Optional Shipping Section - Compact */}
                {shippingEnabled && (
                    <div className="bg-gray-900/50 border border-blue-500/30 rounded-lg p-3">
                        <div className="flex items-center justify-between mb-3">
                            <h3 className="text-xs font-semibold text-blue-400 uppercase tracking-wide flex items-center gap-2">
                                <Truck size={14} />
                                Shipping Details
                            </h3>
                            <button 
                                onClick={() => setShippingEnabled(false)}
                                className="text-xs text-gray-500 hover:text-red-400"
                            >
                                <X size={14} />
                            </button>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                            <Input 
                                type="text" 
                                placeholder="Shipping Address"
                                className="bg-gray-950 border-gray-700 text-white h-8 text-xs md:col-span-2"
                                value={shippingAddress}
                                onChange={(e) => setShippingAddress(e.target.value)}
                            />
                            <Input 
                                type="number" 
                                placeholder="Shipping Charges"
                                className="bg-gray-950 border-gray-700 text-white h-8 text-xs"
                                value={shippingCharges > 0 ? shippingCharges : ''}
                                onChange={(e) => setShippingCharges(parseFloat(e.target.value) || 0)}
                            />
                        </div>
                    </div>
                )}

                {/* 5. Bottom Section - Expenses, Summary & Payment */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 pt-4 border-t border-gray-800">
                    {/* Left Column - Expenses & Summary */}
                    <div className="space-y-4">
                        {/* Extra Expenses - Compact Inline */}
                        <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4">
                            <div className="flex items-center justify-between mb-3">
                                <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wide flex items-center gap-2">
                                    <DollarSign size={14} className="text-purple-500" />
                                    Extra Expenses
                                </h3>
                                {extraExpenses.length > 0 && (
                                    <Badge className="bg-purple-600 text-white text-xs px-2 py-0.5">
                                        ${expensesTotal.toLocaleString()}
                                    </Badge>
                                )}
                            </div>

                            {/* Add Expense Form - More Compact */}
                            <div className="flex gap-2 mb-3">
                                <Select value={newExpenseType} onValueChange={(v: any) => setNewExpenseType(v)}>
                                    <SelectTrigger className="w-[110px] bg-gray-950 border-gray-700 text-white h-8 text-xs">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent className="bg-gray-950 border-gray-800 text-white">
                                        <SelectItem value="stitching">Stitching</SelectItem>
                                        <SelectItem value="lining">Lining</SelectItem>
                                        <SelectItem value="dying">Dying</SelectItem>
                                        <SelectItem value="cargo">Cargo</SelectItem>
                                        <SelectItem value="other">Other</SelectItem>
                                    </SelectContent>
                                </Select>
                                <Input 
                                    type="number" 
                                    placeholder="Amount" 
                                    className="bg-gray-950 border-gray-700 text-white h-8 w-[90px] text-xs"
                                    value={newExpenseAmount > 0 ? newExpenseAmount : ''}
                                    onChange={(e) => setNewExpenseAmount(parseFloat(e.target.value) || 0)}
                                />
                                <Input 
                                    type="text" 
                                    placeholder="Notes (optional)" 
                                    className="bg-gray-950 border-gray-700 text-white h-8 flex-1 text-xs"
                                    value={newExpenseNotes}
                                    onChange={(e) => setNewExpenseNotes(e.target.value)}
                                />
                                <Button onClick={addExtraExpense} className="bg-purple-600 hover:bg-purple-500 h-8 w-8 p-0">
                                    <Plus size={14} />
                                </Button>
                            </div>

                            {/* Expenses List - Only show if exists */}
                            {extraExpenses.length > 0 && (
                                <div className="space-y-1.5">
                                    {extraExpenses.map((expense) => (
                                        <div key={expense.id} className="flex justify-between items-center p-2 bg-gray-950 rounded border border-gray-800/50 hover:border-purple-500/30 transition-colors">
                                            <div className="flex items-center gap-2">
                                                <div className="w-6 h-6 rounded bg-purple-600/20 flex items-center justify-center">
                                                    <DollarSign size={10} className="text-purple-400" />
                                                </div>
                                                <div>
                                                    <div className="text-xs font-medium text-white capitalize">{expense.type}</div>
                                                    {expense.notes && <div className="text-[10px] text-gray-500">{expense.notes}</div>}
                                                </div>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <span className="text-xs font-medium text-white">${expense.amount.toLocaleString()}</span>
                                                <button onClick={() => removeExtraExpense(expense.id)} className="text-gray-500 hover:text-red-400">
                                                    <X size={12} />
                                                </button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>

                        {/* Summary Card - Compact with Inline Controls */}
                        <div className="bg-gradient-to-br from-gray-900/80 to-gray-900/50 border border-gray-800 rounded-lg p-4">
                            <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-3">Invoice Summary</h3>
                            <div className="space-y-2">
                                <div className="flex justify-between text-xs">
                                    <span className="text-gray-400">Items Subtotal</span>
                                    <span className="text-white font-medium">${subtotal.toLocaleString()}</span>
                                </div>
                                
                                {/* Discount - Inline Input */}
                                <div className="flex items-center justify-between gap-2 py-1">
                                    <div className="flex items-center gap-1.5">
                                        <Percent size={12} className="text-red-400" />
                                        <span className="text-xs text-gray-400">Discount</span>
                                    </div>
                                    <div className="flex items-center gap-1.5">
                                        <Select value={discountType} onValueChange={(v: any) => setDiscountType(v)}>
                                            <SelectTrigger className="w-12 h-6 bg-gray-950 border-gray-700 text-white text-[10px] px-1">
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent className="bg-gray-950 border-gray-800 text-white min-w-[60px]">
                                                <SelectItem value="percentage">%</SelectItem>
                                                <SelectItem value="fixed">$</SelectItem>
                                            </SelectContent>
                                        </Select>
                                        <Input 
                                            type="number" 
                                            placeholder="0"
                                            className="w-16 h-6 bg-gray-950 border-gray-700 text-white text-xs text-right px-2"
                                            value={discountValue > 0 ? discountValue : ''}
                                            onChange={(e) => setDiscountValue(parseFloat(e.target.value) || 0)}
                                        />
                                        {discountAmount > 0 && (
                                            <span className="text-xs text-red-400 font-medium min-w-[60px] text-right">
                                                -${discountAmount.toLocaleString()}
                                            </span>
                                        )}
                                    </div>
                                </div>

                                {expensesTotal > 0 && (
                                    <div className="flex justify-between text-xs">
                                        <span className="text-purple-400">Extra Expenses</span>
                                        <span className="text-purple-400 font-medium">+${expensesTotal.toLocaleString()}</span>
                                    </div>
                                )}
                                
                                {/* Shipping - Optional, show button or charges */}
                                {!shippingEnabled ? (
                                    <button 
                                        onClick={() => setShippingEnabled(true)}
                                        className="flex items-center gap-1.5 text-xs text-blue-400 hover:text-blue-300 transition-colors py-1"
                                    >
                                        <Truck size={12} />
                                        <span>Add Shipping</span>
                                    </button>
                                ) : finalShippingCharges > 0 && (
                                    <div className="flex justify-between text-xs">
                                        <span className="text-blue-400">Shipping</span>
                                        <span className="text-blue-400 font-medium">+${finalShippingCharges.toLocaleString()}</span>
                                    </div>
                                )}
                                
                                <Separator className="bg-gray-800" />
                                
                                <div className="flex justify-between items-center pt-1">
                                    <span className="text-sm font-semibold text-white">Grand Total</span>
                                    <span className="text-2xl font-bold text-blue-500">${totalAmount.toLocaleString()}</span>
                                </div>

                                {/* Salesman Commission - Info Only (not added to total) */}
                                {salesmanId !== "1" && (
                                    <>
                                        <Separator className="bg-gray-800/50" />
                                        <div className="pt-2 space-y-1.5">
                                            <div className="flex items-center justify-between gap-2">
                                                <div className="flex items-center gap-1.5">
                                                    <UserCheck size={12} className="text-green-400" />
                                                    <span className="text-xs text-gray-400">Commission</span>
                                                </div>
                                                <div className="flex items-center gap-1.5">
                                                    <Select value={commissionType} onValueChange={(v: any) => setCommissionType(v)}>
                                                        <SelectTrigger className="w-12 h-6 bg-gray-950 border-gray-700 text-white text-[10px] px-1">
                                                            <SelectValue />
                                                        </SelectTrigger>
                                                        <SelectContent className="bg-gray-950 border-gray-800 text-white min-w-[60px]">
                                                            <SelectItem value="percentage">%</SelectItem>
                                                            <SelectItem value="fixed">$</SelectItem>
                                                        </SelectContent>
                                                    </Select>
                                                    <Input 
                                                        type="number" 
                                                        placeholder="0"
                                                        className="w-16 h-6 bg-gray-950 border-gray-700 text-white text-xs text-right px-2"
                                                        value={commissionValue > 0 ? commissionValue : ''}
                                                        onChange={(e) => setCommissionValue(parseFloat(e.target.value) || 0)}
                                                    />
                                                </div>
                                            </div>
                                            {commissionAmount > 0 && (
                                                <div className="text-xs text-green-400 font-medium text-right bg-green-500/10 px-2 py-1 rounded">
                                                    Commission: ${commissionAmount.toLocaleString()}
                                                </div>
                                            )}
                                        </div>
                                    </>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Right Column - Payment */}
                    <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-4 space-y-4">
                            {/* Auto Status Badge */}
                            <div className="flex items-center justify-between">
                                <h3 className="text-sm font-semibold text-gray-300 uppercase tracking-wide">Payment</h3>
                                <Badge className={cn(
                                    "text-xs font-medium px-3 py-1",
                                    paymentStatus === 'paid' && "bg-green-600 text-white",
                                    paymentStatus === 'partial' && "bg-blue-600 text-white",
                                    paymentStatus === 'credit' && "bg-orange-600 text-white"
                                )}>
                                    {paymentStatus === 'paid' && '✓ Paid'}
                                    {paymentStatus === 'partial' && '◐ Partial'}
                                    {paymentStatus === 'credit' && '○ Credit'}
                                </Badge>
                            </div>

                            {/* Invoice Amount Display */}
                            <div className="bg-gray-950 border border-gray-800 rounded-lg p-4">
                                <div className="flex items-center justify-between">
                                    <span className="text-xs text-gray-500 uppercase tracking-wide">Invoice Amount</span>
                                    <span className="text-2xl font-bold text-white">${totalAmount.toLocaleString()}</span>
                                </div>
                            </div>

                            {/* Quick Payment Buttons */}
                            <div className="space-y-2">
                                <Label className="text-xs text-gray-500">Quick Pay</Label>
                                <div className="grid grid-cols-4 gap-2">
                                    <Button 
                                        type="button"
                                        onClick={() => setNewPaymentAmount(totalAmount * 0.25)}
                                        className="h-9 bg-gray-800 hover:bg-gray-700 text-white text-xs border border-gray-700"
                                    >
                                        25%
                                    </Button>
                                    <Button 
                                        type="button"
                                        onClick={() => setNewPaymentAmount(totalAmount * 0.50)}
                                        className="h-9 bg-gray-800 hover:bg-gray-700 text-white text-xs border border-gray-700"
                                    >
                                        50%
                                    </Button>
                                    <Button 
                                        type="button"
                                        onClick={() => setNewPaymentAmount(totalAmount * 0.75)}
                                        className="h-9 bg-gray-800 hover:bg-gray-700 text-white text-xs border border-gray-700"
                                    >
                                        75%
                                    </Button>
                                    <Button 
                                        type="button"
                                        onClick={() => setNewPaymentAmount(totalAmount)}
                                        className="h-9 bg-green-700 hover:bg-green-600 text-white text-xs border border-green-600"
                                    >
                                        100%
                                    </Button>
                                </div>
                            </div>

                            {/* Payment Entry Form */}
                            <div className="space-y-2">
                                <Label className="text-xs text-gray-500">Add Payment</Label>
                                <div className="flex gap-2">
                                    <Select value={newPaymentMethod} onValueChange={(v: any) => setNewPaymentMethod(v)}>
                                        <SelectTrigger className="w-[110px] bg-gray-950 border-gray-700 text-white h-10 text-xs">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent className="bg-gray-950 border-gray-800 text-white">
                                            <SelectItem value="cash">Cash</SelectItem>
                                            <SelectItem value="bank">Bank</SelectItem>
                                            <SelectItem value="other">Other</SelectItem>
                                        </SelectContent>
                                    </Select>
                                    <Input 
                                        type="number" 
                                        placeholder="Amount" 
                                        className="bg-gray-950 border-gray-700 text-white h-10 flex-1"
                                        value={newPaymentAmount > 0 ? newPaymentAmount : ''}
                                        onChange={(e) => setNewPaymentAmount(parseFloat(e.target.value) || 0)}
                                    />
                                    <Button onClick={addPartialPayment} className="bg-blue-600 hover:bg-blue-500 h-10 w-10 p-0" >
                                        <Plus size={16} />
                                    </Button>
                                </div>
                                <Input 
                                    type="text" 
                                    placeholder="Reference (optional)" 
                                    className="bg-gray-950 border-gray-700 text-white h-9 text-xs"
                                    value={newPaymentReference}
                                    onChange={(e) => setNewPaymentReference(e.target.value)}
                                />
                            </div>

                            {/* Payments List */}
                            <div className="bg-gray-950 rounded-lg border border-gray-800 p-3 space-y-2 min-h-[100px]">
                                {partialPayments.length === 0 ? (
                                    <div className="text-center text-gray-600 text-xs py-4">No payments added</div>
                                ) : (
                                    partialPayments.map((p) => (
                                        <div key={p.id} className="flex justify-between items-center text-sm p-2 bg-gray-900 rounded border border-gray-800/50">
                                            <div className="flex items-center gap-2">
                                                {p.method === 'cash' && <Banknote size={14} className="text-green-500" />}
                                                {p.method === 'bank' && <CreditCard size={14} className="text-blue-500" />}
                                                {p.method === 'other' && <Wallet size={14} className="text-purple-500" />}
                                                <span className="capitalize text-gray-300 text-xs">{p.method}</span>
                                                {p.reference && <span className="text-gray-500 text-xs">({p.reference})</span>}
                                            </div>
                                            <div className="flex items-center gap-3">
                                                <span className="font-medium text-white">${p.amount.toLocaleString()}</span>
                                                <button onClick={() => removePartialPayment(p.id)} className="text-gray-500 hover:text-red-400">
                                                    <X size={12} />
                                                </button>
                                            </div>
                                        </div>
                                    ))
                                )}
                            </div>

                            <Separator className="bg-gray-800" />
                            
                        <div className="space-y-1">
                            <div className="flex justify-between text-sm">
                                <span className="text-gray-400">Total Paid</span>
                                <span className="text-green-500 font-bold">${totalPaid.toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between items-center pt-2">
                                <span className="text-orange-400 font-medium text-sm">Balance Due</span>
                                <span className="text-orange-500 font-bold text-xl">${Math.max(0, balanceDue).toLocaleString()}</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Final Action Buttons */}
                <div className="grid grid-cols-[1fr_1.5fr_0.6fr] gap-2">
                    <Button 
                        type="button"
                        variant="outline"
                        className="h-11 bg-transparent border-2 border-gray-700 hover:border-gray-600 hover:bg-gray-800 text-white text-sm font-semibold"
                    >
                        <Save size={16} className="mr-1.5" />
                        Save
                    </Button>
                    <Button 
                        type="button"
                        className="h-11 bg-blue-600 hover:bg-blue-500 text-white text-sm font-bold shadow-xl shadow-blue-900/20"
                    >
                        <Printer size={16} className="mr-1.5" />
                        Save & Print
                    </Button>
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button 
                                type="button"
                                variant="outline"
                                className="h-11 bg-transparent border-2 border-gray-700 hover:border-gray-600 hover:bg-gray-800 text-white"
                                title="Attach Files"
                            >
                                <Paperclip size={16} />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="bg-gray-900 border-gray-700 text-white">
                            <DropdownMenuItem className="hover:bg-gray-800 cursor-pointer">
                                <FileText size={14} className="mr-2 text-blue-400" />
                                Bill Attachment
                            </DropdownMenuItem>
                            <DropdownMenuItem className="hover:bg-gray-800 cursor-pointer">
                                <CreditCard size={14} className="mr-2 text-green-400" />
                                Payment Attachment
                            </DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>
                </div>
            </div>

            {/* Packing Modal */}
            <PackingEntryModal 
                open={packingModalOpen}
                onOpenChange={setPackingModalOpen}
                onSave={handleSavePacking}
                initialData={activePackingData}
                productName={activeProductName}
            />
        </div>
    );
};