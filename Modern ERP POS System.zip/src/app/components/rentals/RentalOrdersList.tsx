import React, { useState } from 'react';
import { 
  Search, 
  Calendar, 
  Filter, 
  MoreVertical, 
  Shirt, 
  ArrowRight, 
  CornerDownLeft, 
  Clock, 
  CheckCircle2, 
  AlertCircle 
} from 'lucide-react';
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Badge } from "../ui/badge";
import { clsx } from 'clsx';
import { ReturnDressModal } from './ReturnDressModal';

type RentalStatus = 'Booked' | 'Dispatched' | 'Returned' | 'Overdue';

interface RentalOrder {
  id: string;
  customer: string;
  item: string;
  image: string;
  pickupDate: string;
  returnDate: string;
  status: RentalStatus;
  amount: number;
}

const mockOrders: RentalOrder[] = [
  { 
    id: "ORD-1001", 
    customer: "Sarah Khan", 
    item: "Royal Red Bridal Lehenga", 
    image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=800&q=80",
    pickupDate: "2024-02-01", 
    returnDate: "2024-02-05", 
    status: "Booked", 
    amount: 25000 
  },
  { 
    id: "ORD-1002", 
    customer: "Fatima Ali", 
    item: "Emerald Green Sharara", 
    image: "https://images.unsplash.com/photo-1583391725988-e3eefa84d0f7?w=800&q=80",
    pickupDate: "2024-01-28", 
    returnDate: "2024-02-02", 
    status: "Dispatched", 
    amount: 18000 
  },
  { 
    id: "ORD-1003", 
    customer: "Zara Ahmed", 
    item: "Ivory Gold Gown", 
    image: "https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=800&q=80",
    pickupDate: "2024-01-25", 
    returnDate: new Date().toISOString().split('T')[0], // Today
    status: "Dispatched", 
    amount: 30000 
  },
  { 
    id: "ORD-1004", 
    customer: "Ayesha Malik", 
    item: "Peach Walima Dress", 
    image: "https://images.unsplash.com/photo-1518049362260-00ac5bf47086?w=800&q=80",
    pickupDate: "2024-01-20", 
    returnDate: "2024-01-25", 
    status: "Overdue", 
    amount: 22000 
  },
];

export const RentalOrdersList = () => {
  const [activeTab, setActiveTab] = useState<'all' | 'upcoming' | 'due' | 'overdue'>('all');
  const [returnModalOpen, setReturnModalOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<RentalOrder | null>(null);

  const getFilteredOrders = () => {
    switch (activeTab) {
      case 'upcoming': return mockOrders.filter(o => o.status === 'Booked');
      case 'due': return mockOrders.filter(o => o.status === 'Dispatched' && o.returnDate === new Date().toISOString().split('T')[0]);
      case 'overdue': return mockOrders.filter(o => o.status === 'Overdue');
      default: return mockOrders;
    }
  };

  const handleAction = (order: RentalOrder) => {
    if (order.status === 'Dispatched' || order.status === 'Overdue') {
      setSelectedOrder(order);
      setReturnModalOpen(true);
    } else {
      // Handle Dispatch logic (mock)
      console.log("Dispatching:", order.id);
    }
  };

  const dueCount = mockOrders.filter(o => o.status === 'Dispatched' && o.returnDate === new Date().toISOString().split('T')[0]).length;

  return (
    <div className="space-y-6">
      {/* Header Controls */}
      <div className="flex flex-col md:flex-row justify-between items-end md:items-center gap-4">
        
        {/* Quick Filter Tabs */}
        <div className="flex bg-gray-900 p-1 rounded-lg border border-gray-800 overflow-x-auto">
          {[
            { id: 'all', label: 'All Bookings' },
            { id: 'upcoming', label: 'Upcoming Pickups' },
            { id: 'due', label: 'Returns Due Today', badge: dueCount > 0 ? dueCount : null },
            { id: 'overdue', label: 'Overdue' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={clsx(
                "px-4 py-2 rounded-md text-sm font-medium transition-all flex items-center gap-2 whitespace-nowrap",
                activeTab === tab.id 
                  ? "bg-gray-800 text-white shadow-sm" 
                  : "text-gray-400 hover:text-white hover:bg-gray-800/50"
              )}
            >
              {tab.label}
              {tab.badge && (
                <span className="flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white">
                  {tab.badge}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="flex gap-2 w-full md:w-auto">
           <div className="relative flex-1 md:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={14} />
              <Input 
                placeholder="Search order ID, customer..." 
                className="bg-gray-900 border-gray-800 pl-9 text-white h-10"
              />
           </div>
           <Button variant="outline" size="icon" className="border-gray-800 text-gray-400 hover:bg-gray-800">
             <Filter size={16} />
           </Button>
        </div>
      </div>

      {/* Table */}
      <div className="border border-gray-800 rounded-xl overflow-hidden bg-gray-900/50">
        <table className="w-full text-sm text-left">
            <thead className="bg-gray-900 text-gray-400 font-medium border-b border-gray-800">
                <tr>
                    <th className="p-4 font-medium">Product Name</th>
                    <th className="p-4 font-medium">Customer</th>
                    <th className="p-4 font-medium">Pickup Date</th>
                    <th className="p-4 font-medium">Return Date</th>
                    <th className="p-4 font-medium">Status</th>
                    <th className="p-4 font-medium text-right">Action</th>
                </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
                {getFilteredOrders().length === 0 ? (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-gray-500">
                      No orders found for this filter.
                    </td>
                  </tr>
                ) : getFilteredOrders().map((order) => (
                    <tr key={order.id} className="hover:bg-gray-800/50 group transition-colors">
                        <td className="p-4">
                            <div className="flex items-center gap-3">
                                <div className="h-10 w-10 rounded bg-gray-800 overflow-hidden shrink-0 border border-gray-700">
                                    <img src={order.image} alt="" className="h-full w-full object-cover" />
                                </div>
                                <div>
                                    <p className="font-medium text-white">{order.item}</p>
                                    <p className="text-xs text-gray-500">{order.id}</p>
                                </div>
                            </div>
                        </td>
                        <td className="p-4">
                            <div className="flex items-center gap-2">
                                <div className="h-6 w-6 rounded-full bg-gradient-to-tr from-purple-500 to-blue-500 flex items-center justify-center text-[10px] font-bold text-white">
                                    {order.customer.charAt(0)}
                                </div>
                                <span className="text-gray-300">{order.customer}</span>
                            </div>
                        </td>
                        <td className="p-4 text-gray-400 font-mono text-xs">
                           {order.pickupDate}
                        </td>
                        <td className="p-4">
                           <div className={clsx(
                             "font-mono text-xs flex items-center gap-2",
                             order.status === 'Overdue' ? "text-red-400 font-bold" : 
                             order.status === 'Dispatched' && order.returnDate === new Date().toISOString().split('T')[0] ? "text-orange-400 font-bold" :
                             "text-gray-400"
                           )}>
                             {order.returnDate}
                             {order.status === 'Overdue' && <AlertCircle size={12} />}
                           </div>
                        </td>
                        <td className="p-4">
                            <Badge 
                              variant="outline" 
                              className={clsx(
                                "capitalize border font-normal",
                                order.status === 'Booked' && "bg-blue-900/20 text-blue-400 border-blue-900/50",
                                order.status === 'Dispatched' && "bg-orange-900/20 text-orange-400 border-orange-900/50",
                                order.status === 'Returned' && "bg-green-900/20 text-green-400 border-green-900/50",
                                order.status === 'Overdue' && "bg-red-900/20 text-red-400 border-red-900/50"
                              )}
                            >
                                {order.status}
                            </Badge>
                        </td>
                        <td className="p-4 text-right">
                           {order.status === 'Booked' && (
                             <Button size="sm" className="bg-blue-600 hover:bg-blue-500 h-8 text-xs font-medium" onClick={() => handleAction(order)}>
                               Dispatch <ArrowRight size={12} className="ml-2" />
                             </Button>
                           )}
                           {(order.status === 'Dispatched' || order.status === 'Overdue') && (
                             <Button size="sm" variant="outline" className="border-green-800 text-green-400 hover:bg-green-900/20 h-8 text-xs font-medium" onClick={() => handleAction(order)}>
                               <CornerDownLeft size={12} className="mr-2" /> Process Return
                             </Button>
                           )}
                           {order.status === 'Returned' && (
                             <span className="text-xs text-green-500 flex items-center justify-end gap-1">
                               <CheckCircle2 size={12} /> Complete
                             </span>
                           )}
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
      </div>

      {/* Return Modal Integration */}
      {returnModalOpen && selectedOrder && (
        <ReturnDressModal 
            isOpen={returnModalOpen}
            onClose={() => setReturnModalOpen(false)}
            customerName={selectedOrder.customer}
            returnDate={new Date()}
            securityType="id_card" // Mock
            securityValue={0}      // Mock
        />
      )}
    </div>
  );
};
