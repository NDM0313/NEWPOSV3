import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Package, 
  Users, 
  DollarSign, 
  Clock, 
  CheckCircle2, 
  AlertCircle,
  Palette,
  Scissors,
  Sparkles,
  User,
  Calendar,
  ChevronRight,
  Eye,
  Send,
  FileText,
  TrendingUp,
  Search,
  Filter,
  Plus
} from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { CalendarDatePicker } from '../ui/CalendarDatePicker';

interface StudioSale {
  id: string;
  invoiceNumber: string;
  customerName: string;
  customerPhone: string;
  fabricType: string;
  quantity: number;
  totalAmount: number;
  saleDate: Date;
  deliveryDeadline: Date;
  status: 'pending' | 'in_progress' | 'completed';
  departments: Department[];
  currentDepartment?: string;
  createdAt: Date;
}

interface Department {
  id: string;
  type: 'dyer' | 'stitcher' | 'handcraft';
  workerId?: string;
  workerName?: string;
  assignedDate?: Date;
  deadline?: Date;
  paymentAmount?: number;
  status: 'pending' | 'assigned' | 'in_progress' | 'completed';
  notes?: string;
  completedDate?: Date;
}

interface Worker {
  id: string;
  name: string;
  phone: string;
  department: 'dyer' | 'stitcher' | 'handcraft';
  totalEarnings: number;
  pendingPayment: number;
  completedTasks: number;
  activeTasks: number;
  rating: number;
  joinedDate: Date;
}

interface Payment {
  id: string;
  workerId: string;
  workerName: string;
  saleId: string;
  invoiceNumber: string;
  amount: number;
  status: 'pending' | 'paid';
  dueDate: Date;
  paidDate?: Date;
  department: string;
}

type ViewMode = 'dashboard' | 'sales' | 'workers' | 'payments' | 'reports';

export const StudioWorkflowPage: React.FC = () => {
  const [viewMode, setViewMode] = useState<ViewMode>('dashboard');
  const [selectedSale, setSelectedSale] = useState<StudioSale | null>(null);
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [selectedDepartment, setSelectedDepartment] = useState<Department | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Mock data - Replace with actual data from localStorage/API
  const [studioSales, setStudioSales] = useState<StudioSale[]>([
    {
      id: 'SS001',
      invoiceNumber: 'INV-2026-0015',
      customerName: 'Ayesha Khan',
      customerPhone: '+92 300 1234567',
      fabricType: 'Silk Lawn - Red (5 meters)',
      quantity: 5,
      totalAmount: 15000,
      saleDate: new Date('2026-01-03'),
      deliveryDeadline: new Date('2026-01-20'),
      status: 'in_progress',
      currentDepartment: 'Dyeing',
      departments: [
        {
          id: 'D1',
          type: 'dyer',
          workerId: 'W001',
          workerName: 'Ahmed Ali',
          assignedDate: new Date('2026-01-03'),
          deadline: new Date('2026-01-10'),
          paymentAmount: 2000,
          status: 'in_progress',
          notes: 'Deep red color required'
        },
        {
          id: 'D2',
          type: 'stitcher',
          status: 'pending'
        }
      ],
      createdAt: new Date('2026-01-03')
    },
    {
      id: 'SS002',
      invoiceNumber: 'INV-2026-0018',
      customerName: 'Fatima Ahmed',
      customerPhone: '+92 301 9876543',
      fabricType: 'Cotton Lawn - Blue (8 meters)',
      quantity: 8,
      totalAmount: 22000,
      saleDate: new Date('2026-01-04'),
      deliveryDeadline: new Date('2026-01-25'),
      status: 'pending',
      departments: [
        {
          id: 'D3',
          type: 'dyer',
          status: 'pending'
        },
        {
          id: 'D4',
          type: 'handcraft',
          status: 'pending'
        }
      ],
      createdAt: new Date('2026-01-04')
    }
  ]);

  const [workers, setWorkers] = useState<Worker[]>([
    {
      id: 'W001',
      name: 'Ahmed Ali',
      phone: '+92 300 1111111',
      department: 'dyer',
      totalEarnings: 45000,
      pendingPayment: 2000,
      completedTasks: 23,
      activeTasks: 1,
      rating: 4.5,
      joinedDate: new Date('2025-06-15')
    },
    {
      id: 'W002',
      name: 'Hassan Raza',
      phone: '+92 300 2222222',
      department: 'stitcher',
      totalEarnings: 67000,
      pendingPayment: 0,
      completedTasks: 34,
      activeTasks: 0,
      rating: 4.8,
      joinedDate: new Date('2025-03-20')
    },
    {
      id: 'W003',
      name: 'Sana Malik',
      phone: '+92 300 3333333',
      department: 'handcraft',
      totalEarnings: 52000,
      pendingPayment: 3500,
      completedTasks: 28,
      activeTasks: 2,
      rating: 4.7,
      joinedDate: new Date('2025-08-10')
    }
  ]);

  const [payments, setPayments] = useState<Payment[]>([
    {
      id: 'P001',
      workerId: 'W001',
      workerName: 'Ahmed Ali',
      saleId: 'SS001',
      invoiceNumber: 'INV-2026-0015',
      amount: 2000,
      status: 'pending',
      dueDate: new Date('2026-01-10'),
      department: 'Dyeing'
    },
    {
      id: 'P002',
      workerId: 'W003',
      workerName: 'Sana Malik',
      saleId: 'SS002',
      invoiceNumber: 'INV-2026-0018',
      amount: 3500,
      status: 'pending',
      dueDate: new Date('2026-01-15'),
      department: 'Handcraft'
    }
  ]);

  const getDepartmentIcon = (type: Department['type']) => {
    switch (type) {
      case 'dyer': return <Palette className="text-purple-400" size={18} />;
      case 'stitcher': return <Scissors className="text-blue-400" size={18} />;
      case 'handcraft': return <Sparkles className="text-pink-400" size={18} />;
    }
  };

  const getDepartmentName = (type: Department['type']) => {
    switch (type) {
      case 'dyer': return 'Dyeing';
      case 'stitcher': return 'Stitching';
      case 'handcraft': return 'Handcraft';
    }
  };

  const getStatusColor = (status: Department['status']) => {
    switch (status) {
      case 'pending': return 'bg-gray-700 text-gray-300 border-gray-600';
      case 'assigned': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'in_progress': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'completed': return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
    }
  };

  const handleAssignWorker = (sale: StudioSale, department: Department) => {
    setSelectedSale(sale);
    setSelectedDepartment(department);
    setShowAssignModal(true);
  };

  const handleUpdateStatus = (saleId: string, departmentId: string, newStatus: Department['status']) => {
    setStudioSales(prev => prev.map(sale => {
      if (sale.id === saleId) {
        return {
          ...sale,
          departments: sale.departments.map(dept => {
            if (dept.id === departmentId) {
              return {
                ...dept,
                status: newStatus,
                completedDate: newStatus === 'completed' ? new Date() : dept.completedDate
              };
            }
            return dept;
          }),
          status: sale.departments.every(d => d.id === departmentId ? newStatus === 'completed' : d.status === 'completed')
            ? 'completed'
            : 'in_progress'
        };
      }
      return sale;
    }));
  };

  const handleMarkPaid = (paymentId: string) => {
    setPayments(prev => prev.map(payment => {
      if (payment.id === paymentId) {
        return {
          ...payment,
          status: 'paid',
          paidDate: new Date()
        };
      }
      return payment;
    }));

    // Update worker pending payment
    const payment = payments.find(p => p.id === paymentId);
    if (payment) {
      setWorkers(prev => prev.map(worker => {
        if (worker.id === payment.workerId) {
          return {
            ...worker,
            pendingPayment: worker.pendingPayment - payment.amount,
            totalEarnings: worker.totalEarnings + payment.amount
          };
        }
        return worker;
      }));
    }
  };

  // Statistics
  const stats = {
    totalOrders: studioSales.length,
    inProgress: studioSales.filter(s => s.status === 'in_progress').length,
    completed: studioSales.filter(s => s.status === 'completed').length,
    pendingPayments: payments.filter(p => p.status === 'pending').reduce((sum, p) => sum + p.amount, 0),
    activeWorkers: workers.filter(w => w.activeTasks > 0).length,
    totalWorkers: workers.length
  };

  const filteredSales = studioSales.filter(sale => {
    const matchesSearch = sale.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         sale.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         sale.fabricType.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || sale.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="min-h-screen bg-[#111827] p-6">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center gap-4 mb-2">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
            <Package className="text-white" size={24} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-white">Studio Workflow</h1>
            <p className="text-gray-400">Integrated fabric processing & worker management</p>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex gap-2 mb-6 bg-gray-900 p-1 rounded-xl border border-gray-800 w-fit">
        <button
          onClick={() => setViewMode('dashboard')}
          className={`px-6 py-3 rounded-lg font-medium transition-all ${
            viewMode === 'dashboard'
              ? 'bg-purple-500 text-white shadow-lg shadow-purple-500/30'
              : 'text-gray-400 hover:text-white hover:bg-gray-800'
          }`}
        >
          <div className="flex items-center gap-2">
            <TrendingUp size={18} />
            Dashboard
          </div>
        </button>
        <button
          onClick={() => setViewMode('sales')}
          className={`px-6 py-3 rounded-lg font-medium transition-all ${
            viewMode === 'sales'
              ? 'bg-purple-500 text-white shadow-lg shadow-purple-500/30'
              : 'text-gray-400 hover:text-white hover:bg-gray-800'
          }`}
        >
          <div className="flex items-center gap-2">
            <Package size={18} />
            Studio Sales
          </div>
        </button>
        <button
          onClick={() => setViewMode('workers')}
          className={`px-6 py-3 rounded-lg font-medium transition-all ${
            viewMode === 'workers'
              ? 'bg-purple-500 text-white shadow-lg shadow-purple-500/30'
              : 'text-gray-400 hover:text-white hover:bg-gray-800'
          }`}
        >
          <div className="flex items-center gap-2">
            <Users size={18} />
            Workers
          </div>
        </button>
        <button
          onClick={() => setViewMode('payments')}
          className={`px-6 py-3 rounded-lg font-medium transition-all ${
            viewMode === 'payments'
              ? 'bg-purple-500 text-white shadow-lg shadow-purple-500/30'
              : 'text-gray-400 hover:text-white hover:bg-gray-800'
          }`}
        >
          <div className="flex items-center gap-2">
            <DollarSign size={18} />
            Payments
          </div>
        </button>
        <button
          onClick={() => setViewMode('reports')}
          className={`px-6 py-3 rounded-lg font-medium transition-all ${
            viewMode === 'reports'
              ? 'bg-purple-500 text-white shadow-lg shadow-purple-500/30'
              : 'text-gray-400 hover:text-white hover:bg-gray-800'
          }`}
        >
          <div className="flex items-center gap-2">
            <FileText size={18} />
            Reports
          </div>
        </button>
      </div>

      {/* Dashboard View */}
      {viewMode === 'dashboard' && (
        <div className="space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-6 gap-4">
            <div className="bg-gradient-to-br from-purple-500/20 to-purple-600/10 border border-purple-500/30 rounded-xl p-5">
              <div className="flex items-center justify-between mb-2">
                <Package className="text-purple-400" size={24} />
                <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">Total</Badge>
              </div>
              <div className="text-3xl font-bold text-white mb-1">{stats.totalOrders}</div>
              <div className="text-sm text-gray-400">Total Orders</div>
            </div>

            <div className="bg-gradient-to-br from-blue-500/20 to-blue-600/10 border border-blue-500/30 rounded-xl p-5">
              <div className="flex items-center justify-between mb-2">
                <Clock className="text-blue-400" size={24} />
                <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">Active</Badge>
              </div>
              <div className="text-3xl font-bold text-white mb-1">{stats.inProgress}</div>
              <div className="text-sm text-gray-400">In Progress</div>
            </div>

            <div className="bg-gradient-to-br from-emerald-500/20 to-emerald-600/10 border border-emerald-500/30 rounded-xl p-5">
              <div className="flex items-center justify-between mb-2">
                <CheckCircle2 className="text-emerald-400" size={24} />
                <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">Done</Badge>
              </div>
              <div className="text-3xl font-bold text-white mb-1">{stats.completed}</div>
              <div className="text-sm text-gray-400">Completed</div>
            </div>

            <div className="bg-gradient-to-br from-yellow-500/20 to-yellow-600/10 border border-yellow-500/30 rounded-xl p-5">
              <div className="flex items-center justify-between mb-2">
                <DollarSign className="text-yellow-400" size={24} />
                <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">Pending</Badge>
              </div>
              <div className="text-3xl font-bold text-white mb-1">₨{stats.pendingPayments.toLocaleString()}</div>
              <div className="text-sm text-gray-400">Pending Payments</div>
            </div>

            <div className="bg-gradient-to-br from-pink-500/20 to-pink-600/10 border border-pink-500/30 rounded-xl p-5">
              <div className="flex items-center justify-between mb-2">
                <Users className="text-pink-400" size={24} />
                <Badge className="bg-pink-500/20 text-pink-400 border-pink-500/30">Active</Badge>
              </div>
              <div className="text-3xl font-bold text-white mb-1">{stats.activeWorkers}</div>
              <div className="text-sm text-gray-400">Active Workers</div>
            </div>

            <div className="bg-gradient-to-br from-indigo-500/20 to-indigo-600/10 border border-indigo-500/30 rounded-xl p-5">
              <div className="flex items-center justify-between mb-2">
                <User className="text-indigo-400" size={24} />
                <Badge className="bg-indigo-500/20 text-indigo-400 border-indigo-500/30">Total</Badge>
              </div>
              <div className="text-3xl font-bold text-white mb-1">{stats.totalWorkers}</div>
              <div className="text-sm text-gray-400">Total Workers</div>
            </div>
          </div>

          {/* Recent Studio Sales */}
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-white">Recent Studio Sales</h2>
              <Button 
                onClick={() => setViewMode('sales')}
                className="bg-purple-600 hover:bg-purple-700"
              >
                View All
              </Button>
            </div>
            <div className="space-y-3">
              {studioSales.slice(0, 5).map(sale => (
                <div key={sale.id} className="bg-gray-800 border border-gray-700 rounded-lg p-4 hover:border-purple-500/50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span className="text-white font-semibold">{sale.customerName}</span>
                        <Badge className="bg-gray-700 text-gray-300 border-gray-600 text-xs">
                          {sale.invoiceNumber}
                        </Badge>
                        <Badge className={getStatusColor(sale.status as any)}>
                          {sale.status.replace('_', ' ')}
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-400">{sale.fabricType}</div>
                      <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                        <span>₨{sale.totalAmount.toLocaleString()}</span>
                        <span>•</span>
                        <span>Due: {sale.deliveryDeadline.toLocaleDateString()}</span>
                      </div>
                    </div>
                    <Button 
                      onClick={() => {
                        setSelectedSale(sale);
                        setViewMode('sales');
                      }}
                      variant="outline" 
                      className="bg-gray-700 border-gray-600 text-white hover:bg-gray-600"
                    >
                      <Eye size={16} className="mr-2" />
                      View
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Studio Sales View */}
      {viewMode === 'sales' && (
        <div className="space-y-6">
          {/* Search and Filter */}
          <div className="flex gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={20} />
              <Input
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by customer, invoice, or fabric type..."
                className="pl-10 bg-gray-800 border-gray-700 text-white"
              />
            </div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white"
            >
              <option value="all">All Status</option>
              <option value="pending">Pending</option>
              <option value="in_progress">In Progress</option>
              <option value="completed">Completed</option>
            </select>
          </div>

          {/* Sales List */}
          <div className="space-y-4">
            {filteredSales.map(sale => (
              <div key={sale.id} className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                {/* Sale Header */}
                <div className="flex items-start justify-between mb-4 pb-4 border-b border-gray-800">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-xl font-bold text-white">{sale.customerName}</h3>
                      <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
                        {sale.invoiceNumber}
                      </Badge>
                      <Badge className={getStatusColor(sale.status as any)}>
                        {sale.status.replace('_', ' ').toUpperCase()}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 gap-x-8 gap-y-2 text-sm">
                      <div className="flex items-center gap-2 text-gray-400">
                        <User size={16} />
                        <span>{sale.customerPhone}</span>
                      </div>
                      <div className="flex items-center gap-2 text-gray-400">
                        <Calendar size={16} />
                        <span>Sale Date: {sale.saleDate.toLocaleDateString()}</span>
                      </div>
                      <div className="flex items-center gap-2 text-gray-400">
                        <Package size={16} />
                        <span>{sale.fabricType}</span>
                      </div>
                      <div className="flex items-center gap-2 text-gray-400">
                        <Clock size={16} />
                        <span className="text-yellow-400">Deadline: {sale.deliveryDeadline.toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-white mb-1">₨{sale.totalAmount.toLocaleString()}</div>
                    <div className="text-sm text-gray-500">{sale.quantity} meters</div>
                  </div>
                </div>

                {/* Departments */}
                <div className="space-y-3">
                  <h4 className="font-semibold text-white mb-3">Department Pipeline</h4>
                  {sale.departments.map((dept, index) => (
                    <div 
                      key={dept.id} 
                      className={`bg-gray-800 border rounded-lg p-4 transition-all ${
                        dept.status === 'in_progress' 
                          ? 'border-blue-500 shadow-lg shadow-blue-500/20' 
                          : dept.status === 'completed'
                          ? 'border-emerald-500 shadow-lg shadow-emerald-500/20'
                          : 'border-gray-700'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3 flex-1">
                          <div className="w-10 h-10 rounded-lg bg-gray-700 flex items-center justify-center">
                            {getDepartmentIcon(dept.type)}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-1">
                              <span className="font-semibold text-white">{getDepartmentName(dept.type)}</span>
                              <Badge className={getStatusColor(dept.status)}>
                                {dept.status.replace('_', ' ')}
                              </Badge>
                            </div>
                            {dept.workerName && (
                              <div className="text-sm text-gray-400">
                                Worker: {dept.workerName} • Payment: ₨{dept.paymentAmount?.toLocaleString()}
                              </div>
                            )}
                            {dept.deadline && (
                              <div className="text-xs text-gray-500 mt-1">
                                Deadline: {dept.deadline.toLocaleDateString()}
                              </div>
                            )}
                            {dept.notes && (
                              <div className="text-xs text-blue-400 mt-1">
                                Note: {dept.notes}
                              </div>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex gap-2">
                          {dept.status === 'pending' && (
                            <Button 
                              onClick={() => handleAssignWorker(sale, dept)}
                              className="bg-purple-600 hover:bg-purple-700"
                            >
                              <Send size={16} className="mr-2" />
                              Assign Worker
                            </Button>
                          )}
                          {dept.status === 'assigned' && (
                            <Button 
                              onClick={() => handleUpdateStatus(sale.id, dept.id, 'in_progress')}
                              className="bg-blue-600 hover:bg-blue-700"
                            >
                              Start Work
                            </Button>
                          )}
                          {dept.status === 'in_progress' && (
                            <Button 
                              onClick={() => handleUpdateStatus(sale.id, dept.id, 'completed')}
                              className="bg-emerald-600 hover:bg-emerald-700"
                            >
                              <CheckCircle2 size={16} className="mr-2" />
                              Mark Complete
                            </Button>
                          )}
                          {dept.status === 'completed' && (
                            <div className="flex items-center gap-2 text-emerald-400">
                              <CheckCircle2 size={20} />
                              <span className="text-sm font-medium">Completed</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Workers View */}
      {viewMode === 'workers' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-white">Worker Management</h2>
            <Button className="bg-purple-600 hover:bg-purple-700">
              <Plus size={18} className="mr-2" />
              Add New Worker
            </Button>
          </div>

          <div className="grid grid-cols-3 gap-4">
            {workers.map(worker => (
              <div key={worker.id} className="bg-gray-900 border border-gray-800 rounded-xl p-6">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white text-xl font-bold">
                    {worker.name.charAt(0)}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-white text-lg">{worker.name}</h3>
                    <div className="text-sm text-gray-400">{getDepartmentName(worker.department)}</div>
                    <div className="text-xs text-gray-500">{worker.phone}</div>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-400">Total Earnings</span>
                    <span className="font-semibold text-white">₨{worker.totalEarnings.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-400">Pending Payment</span>
                    <span className={`font-semibold ${worker.pendingPayment > 0 ? 'text-yellow-400' : 'text-emerald-400'}`}>
                      ₨{worker.pendingPayment.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-400">Completed Tasks</span>
                    <span className="font-semibold text-white">{worker.completedTasks}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-400">Active Tasks</span>
                    <span className={`font-semibold ${worker.activeTasks > 0 ? 'text-blue-400' : 'text-gray-400'}`}>
                      {worker.activeTasks}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-400">Rating</span>
                    <span className="font-semibold text-yellow-400">⭐ {worker.rating}/5</span>
                  </div>
                </div>

                <Button className="w-full mt-4 bg-gray-800 hover:bg-gray-700 text-white">
                  View Details
                </Button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Payments View */}
      {viewMode === 'payments' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-white">Payment Management</h2>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <div className="text-sm text-gray-400">Total Pending</div>
                <div className="text-2xl font-bold text-yellow-400">
                  ₨{payments.filter(p => p.status === 'pending').reduce((sum, p) => sum + p.amount, 0).toLocaleString()}
                </div>
              </div>
            </div>
          </div>

          <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-800 border-b border-gray-700">
                <tr>
                  <th className="text-left p-4 text-gray-400 font-semibold">Worker</th>
                  <th className="text-left p-4 text-gray-400 font-semibold">Department</th>
                  <th className="text-left p-4 text-gray-400 font-semibold">Invoice</th>
                  <th className="text-right p-4 text-gray-400 font-semibold">Amount</th>
                  <th className="text-center p-4 text-gray-400 font-semibold">Due Date</th>
                  <th className="text-center p-4 text-gray-400 font-semibold">Status</th>
                  <th className="text-right p-4 text-gray-400 font-semibold">Action</th>
                </tr>
              </thead>
              <tbody>
                {payments.map(payment => (
                  <tr key={payment.id} className="border-b border-gray-800 hover:bg-gray-800/50 transition-colors">
                    <td className="p-4">
                      <div className="font-semibold text-white">{payment.workerName}</div>
                    </td>
                    <td className="p-4">
                      <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
                        {payment.department}
                      </Badge>
                    </td>
                    <td className="p-4 text-gray-400">{payment.invoiceNumber}</td>
                    <td className="p-4 text-right">
                      <span className="font-semibold text-white">₨{payment.amount.toLocaleString()}</span>
                    </td>
                    <td className="p-4 text-center text-gray-400">
                      {payment.dueDate.toLocaleDateString()}
                    </td>
                    <td className="p-4 text-center">
                      <Badge className={
                        payment.status === 'paid'
                          ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                          : 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'
                      }>
                        {payment.status.toUpperCase()}
                      </Badge>
                    </td>
                    <td className="p-4 text-right">
                      {payment.status === 'pending' ? (
                        <Button 
                          onClick={() => handleMarkPaid(payment.id)}
                          className="bg-emerald-600 hover:bg-emerald-700"
                        >
                          Mark Paid
                        </Button>
                      ) : (
                        <span className="text-xs text-gray-500">
                          Paid on {payment.paidDate?.toLocaleDateString()}
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Reports View */}
      {viewMode === 'reports' && (
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-white">Studio Reports</h2>
          
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-purple-500/50 transition-colors cursor-pointer">
              <FileText className="text-purple-400 mb-4" size={32} />
              <h3 className="text-lg font-bold text-white mb-2">Customer Invoices</h3>
              <p className="text-sm text-gray-400 mb-4">Generate detailed customer invoices with fabric traceability</p>
              <Button className="w-full bg-purple-600 hover:bg-purple-700">Generate Report</Button>
            </div>

            <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-blue-500/50 transition-colors cursor-pointer">
              <DollarSign className="text-blue-400 mb-4" size={32} />
              <h3 className="text-lg font-bold text-white mb-2">Worker Payments</h3>
              <p className="text-sm text-gray-400 mb-4">View all worker payments and pending dues</p>
              <Button className="w-full bg-blue-600 hover:bg-blue-700">Generate Report</Button>
            </div>

            <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 hover:border-emerald-500/50 transition-colors cursor-pointer">
              <Package className="text-emerald-400 mb-4" size={32} />
              <h3 className="text-lg font-bold text-white mb-2">Fabric Traceability</h3>
              <p className="text-sm text-gray-400 mb-4">Track fabric journey through all departments</p>
              <Button className="w-full bg-emerald-600 hover:bg-emerald-700">Generate Report</Button>
            </div>
          </div>
        </div>
      )}

      {/* Assign Worker Modal */}
      {showAssignModal && selectedSale && selectedDepartment && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 max-w-2xl w-full">
            <h3 className="text-xl font-bold text-white mb-4">
              Assign Worker - {getDepartmentName(selectedDepartment.type)}
            </h3>

            <div className="space-y-4 mb-6">
              <div>
                <Label className="text-gray-400 mb-2 block">Select Worker</Label>
                <select className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white">
                  <option value="">Choose a worker...</option>
                  {workers
                    .filter(w => w.department === selectedDepartment.type)
                    .map(worker => (
                      <option key={worker.id} value={worker.id}>
                        {worker.name} - {worker.activeTasks} active tasks
                      </option>
                    ))
                  }
                </select>
              </div>

              <div>
                <Label className="text-gray-400 mb-2 block">Deadline</Label>
                <CalendarDatePicker
                  className="bg-gray-800 border-gray-700 text-white"
                />
              </div>

              <div>
                <Label className="text-gray-400 mb-2 block">Payment Amount (₨)</Label>
                <Input
                  type="number"
                  placeholder="0"
                  className="bg-gray-800 border-gray-700 text-white"
                />
              </div>

              <div>
                <Label className="text-gray-400 mb-2 block">Notes / Instructions</Label>
                <Textarea
                  placeholder="Add any specific instructions for the worker..."
                  className="bg-gray-800 border-gray-700 text-white"
                  rows={3}
                />
              </div>
            </div>

            <div className="flex gap-3">
              <Button 
                onClick={() => setShowAssignModal(false)}
                variant="outline"
                className="flex-1 bg-gray-800 border-gray-700 text-white hover:bg-gray-700"
              >
                Cancel
              </Button>
              <Button 
                onClick={() => {
                  handleUpdateStatus(selectedSale.id, selectedDepartment.id, 'assigned');
                  setShowAssignModal(false);
                }}
                className="flex-1 bg-purple-600 hover:bg-purple-700"
              >
                Assign Worker
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};