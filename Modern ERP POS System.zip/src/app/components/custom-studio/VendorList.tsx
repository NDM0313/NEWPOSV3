import React, { useState } from 'react';
import { 
  Search, 
  Filter, 
  MoreVertical, 
  Phone, 
  MapPin,
  Plus,
  Trash2,
  Edit,
  Eye,
  Check
} from 'lucide-react';
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Badge } from "../ui/badge";
import { cn } from "../ui/utils";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription
} from "../ui/dialog";
import { Label } from "../ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "../ui/dropdown-menu";

const initialVendors = [
  { id: 1, name: 'Ali Dyer', type: 'Dyer', phone: '+92 300 1112222', location: 'Lahore', status: 'Active', orders: 5 },
  { id: 2, name: 'Master Sahab', type: 'Tailor', phone: '+92 321 3334444', location: 'Karachi', status: 'Busy', orders: 12 },
  { id: 3, name: 'Embroidery Works', type: 'Embroiderer', phone: '+92 333 5556666', location: 'Faisalabad', status: 'Active', orders: 2 },
  { id: 4, name: 'Silk Traders', type: 'Fabric Supplier', phone: '+92 300 7778888', location: 'Lahore', status: 'Active', orders: 0 },
];

export const VendorList = () => {
  const [vendorList, setVendorList] = useState(initialVendors);
  
  // Add/Edit Dialog State
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    type: '',
    phone: '',
    location: ''
  });

  // View Details Dialog State
  const [isViewOpen, setIsViewOpen] = useState(false);
  const [selectedVendor, setSelectedVendor] = useState<typeof initialVendors[0] | null>(null);

  const handleOpenAdd = () => {
    setEditingId(null);
    setFormData({ name: '', type: '', phone: '', location: '' });
    setIsDialogOpen(true);
  };

  const handleOpenEdit = (vendor: typeof initialVendors[0]) => {
    setEditingId(vendor.id);
    setFormData({
      name: vendor.name,
      type: vendor.type,
      phone: vendor.phone,
      location: vendor.location
    });
    setIsDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.name || !formData.type) return;
    
    if (editingId) {
      // Update existing
      setVendorList(vendorList.map(v => 
        v.id === editingId 
          ? { ...v, ...formData } 
          : v
      ));
    } else {
      // Create new
      const newId = Math.max(...vendorList.map(v => v.id), 0) + 1;
      setVendorList([...vendorList, {
        id: newId,
        name: formData.name,
        type: formData.type,
        phone: formData.phone || 'N/A',
        location: formData.location || 'N/A',
        status: 'Active',
        orders: 0
      }]);
    }
    
    setIsDialogOpen(false);
  };

  const handleDeleteVendor = (id: number) => {
    setVendorList(vendorList.filter(v => v.id !== id));
  };

  const handleViewDetails = (vendor: typeof initialVendors[0]) => {
    setSelectedVendor(vendor);
    setIsViewOpen(true);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300 p-6">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white">Vendor Management</h2>
          <p className="text-gray-400 text-sm">Manage your dyers, tailors, and material suppliers.</p>
        </div>
        <Button 
          onClick={handleOpenAdd}
          className="bg-blue-600 hover:bg-blue-500 shadow-lg shadow-blue-900/20"
        >
          <Plus className="mr-2 h-4 w-4" /> Add Vendor
        </Button>
      </div>

      {/* Toolbar */}
      <div className="flex gap-4 items-center bg-gray-900/50 p-4 rounded-xl border border-gray-800">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 h-4 w-4" />
          <Input 
            placeholder="Search vendors..." 
            className="pl-9 bg-gray-950 border-gray-700 text-white" 
          />
        </div>
        <Button variant="outline" size="icon" className="border-gray-700 text-gray-300">
          <Filter size={18} />
        </Button>
      </div>

      {/* Table */}
      <div className="border border-gray-800 rounded-xl overflow-hidden bg-gray-900/30">
        <Table>
          <TableHeader className="bg-gray-950/50">
            <TableRow className="border-gray-800 hover:bg-gray-950">
              <TableHead className="text-gray-400">Vendor Name</TableHead>
              <TableHead className="text-gray-400">Service Type</TableHead>
              <TableHead className="text-gray-400">Contact</TableHead>
              <TableHead className="text-gray-400">Location</TableHead>
              <TableHead className="text-gray-400">Active Orders</TableHead>
              <TableHead className="text-gray-400 text-center">Status</TableHead>
              <TableHead className="w-[50px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {vendorList.map((vendor) => (
              <TableRow key={vendor.id} className="border-gray-800 hover:bg-gray-800/30 transition-colors">
                <TableCell className="font-medium text-white">{vendor.name}</TableCell>
                <TableCell>
                  <Badge variant="outline" className="border-gray-700 text-gray-300 bg-gray-800">
                    {vendor.type}
                  </Badge>
                </TableCell>
                <TableCell className="text-gray-400 flex items-center gap-2">
                  <Phone size={14} /> {vendor.phone}
                </TableCell>
                <TableCell className="text-gray-400">
                  <div className="flex items-center gap-2">
                    <MapPin size={14} /> {vendor.location}
                  </div>
                </TableCell>
                <TableCell className="text-gray-300 pl-8">{vendor.orders}</TableCell>
                <TableCell className="text-center">
                  <span className={cn(
                    "px-2 py-1 rounded-full text-xs font-bold",
                    vendor.status === 'Active' ? "bg-green-500/10 text-green-400" : 
                    vendor.status === 'Busy' ? "bg-orange-500/10 text-orange-400" : "bg-gray-700 text-gray-400"
                  )}>
                    {vendor.status}
                  </span>
                </TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="text-gray-500 hover:text-white">
                        <MoreVertical size={16} />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-40 bg-gray-900 border-gray-800 text-white">
                      <DropdownMenuItem 
                        className="focus:bg-gray-800 focus:text-white cursor-pointer"
                        onClick={() => handleViewDetails(vendor)}
                      >
                        <Eye className="mr-2 h-4 w-4" /> View Details
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        className="focus:bg-gray-800 focus:text-white cursor-pointer"
                        onClick={() => handleOpenEdit(vendor)}
                      >
                        <Edit className="mr-2 h-4 w-4" /> Edit Vendor
                      </DropdownMenuItem>
                      <DropdownMenuSeparator className="bg-gray-800" />
                      <DropdownMenuItem 
                        className="focus:bg-gray-800 focus:text-red-400 text-red-400 cursor-pointer"
                        onClick={() => handleDeleteVendor(vendor.id)}
                      >
                        <Trash2 className="mr-2 h-4 w-4" /> Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Add/Edit Vendor Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="bg-gray-900 border-gray-800 text-white sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{editingId ? 'Edit Vendor' : 'Add New Vendor'}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name" className="text-gray-400">Vendor Name</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-gray-950 border-gray-700 text-white"
                placeholder="e.g. Ustad Aslam"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="type" className="text-gray-400">Service Type</Label>
              <Select
                value={formData.type}
                onValueChange={(val) => setFormData({ ...formData, type: val })}
              >
                <SelectTrigger className="bg-gray-950 border-gray-700 text-white">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent className="bg-gray-900 border-gray-800 text-white">
                  <SelectItem value="Dyer">Dyer</SelectItem>
                  <SelectItem value="Tailor">Tailor</SelectItem>
                  <SelectItem value="Embroiderer">Embroiderer</SelectItem>
                  <SelectItem value="Fabric Supplier">Fabric Supplier</SelectItem>
                  <SelectItem value="Designer">Designer</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="phone" className="text-gray-400">Phone Number</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="bg-gray-950 border-gray-700 text-white"
                placeholder="+92 300 1234567"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="location" className="text-gray-400">Location</Label>
              <Input
                id="location"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                className="bg-gray-950 border-gray-700 text-white"
                placeholder="e.g. Lahore"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)} className="border-gray-700 text-gray-300">
              Cancel
            </Button>
            <Button onClick={handleSave} className="bg-blue-600 hover:bg-blue-500 text-white">
              {editingId ? 'Update Vendor' : 'Save Vendor'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Details Dialog */}
      <Dialog open={isViewOpen} onOpenChange={setIsViewOpen}>
        <DialogContent className="bg-gray-900 border-gray-800 text-white sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Vendor Details</DialogTitle>
            <DialogDescription className="text-gray-400">
               Complete information for {selectedVendor?.name}
            </DialogDescription>
          </DialogHeader>
          
          {selectedVendor && (
            <div className="grid gap-6 py-4">
              <div className="flex items-center gap-4 bg-gray-950/50 p-4 rounded-lg border border-gray-800">
                <div className="h-12 w-12 rounded-full bg-blue-600/20 flex items-center justify-center text-blue-400 font-bold text-xl">
                  {selectedVendor.name.charAt(0)}
                </div>
                <div>
                  <h3 className="font-bold text-lg">{selectedVendor.name}</h3>
                  <Badge variant="outline" className="border-gray-700 bg-gray-800 text-gray-300 mt-1">
                    {selectedVendor.type}
                  </Badge>
                </div>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 bg-gray-950 rounded-lg border border-gray-800">
                    <p className="text-xs text-gray-500 mb-1">Status</p>
                    <span className={cn(
                      "text-sm font-medium",
                      selectedVendor.status === 'Active' ? "text-green-400" : "text-orange-400"
                    )}>
                      {selectedVendor.status}
                    </span>
                  </div>
                   <div className="p-3 bg-gray-950 rounded-lg border border-gray-800">
                    <p className="text-xs text-gray-500 mb-1">Active Orders</p>
                    <span className="text-sm font-medium text-white">
                      {selectedVendor.orders} Orders
                    </span>
                  </div>
                </div>

                <div className="space-y-3 p-4 bg-gray-950 rounded-lg border border-gray-800">
                  <div className="flex items-center gap-3 text-sm">
                    <Phone className="h-4 w-4 text-gray-400" />
                    <span className="text-gray-200">{selectedVendor.phone}</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <MapPin className="h-4 w-4 text-gray-400" />
                    <span className="text-gray-200">{selectedVendor.location}</span>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter>
             <Button onClick={() => setIsViewOpen(false)} className="w-full bg-gray-800 hover:bg-gray-700 text-white">
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
