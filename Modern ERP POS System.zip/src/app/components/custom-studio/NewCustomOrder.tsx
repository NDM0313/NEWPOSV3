import React, { useState } from 'react';
import { 
  User, 
  Calendar, 
  Scissors, 
  Save, 
  ArrowLeft,
  Ruler,
  AlertCircle
} from 'lucide-react';
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { CalendarDatePicker } from "../ui/CalendarDatePicker";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Badge } from "../ui/badge";
import { Textarea } from "../ui/textarea";

// Mock Customer Data
const customers = [
  { id: '1', name: 'Mrs. Saad', type: 'Retail', phone: '+92 300 1234567' },
  { id: '2', name: 'Bridal Boutique Lahore', type: 'Wholesale', phone: '+92 321 9876543' },
  { id: '3', name: 'Zara Ahmed', type: 'Retail', phone: '+92 333 5556667' },
  { id: '4', name: 'Karachi Fabrics', type: 'Wholesale', phone: '+92 21 111222333' },
];

export const NewCustomOrder = ({ onBack }: { onBack?: () => void }) => {
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  
  const selectedCustomer = customers.find(c => c.id === selectedCustomerId);
  const isWholesale = selectedCustomer?.type === 'Wholesale';

  return (
    <div className="flex flex-col h-full bg-gray-900 text-white animate-in fade-in duration-300">
      
      {/* Header */}
      <div className="flex items-center justify-between p-6 border-b border-gray-800 bg-gray-950/50">
        <div className="flex items-center gap-4">
          {onBack && (
            <Button variant="ghost" size="icon" onClick={onBack} className="text-gray-400 hover:text-white">
              <ArrowLeft size={20} />
            </Button>
          )}
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Scissors className="text-blue-500" />
              New Custom Order
            </h1>
            <p className="text-gray-400 text-sm mt-1">Create a new bespoke or wholesale order.</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="border-gray-700 text-gray-300">
            Cancel
          </Button>
          <Button className="bg-blue-600 hover:bg-blue-500 shadow-lg shadow-blue-900/20">
            <Save className="mr-2 h-4 w-4" /> Create Order
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-4xl mx-auto space-y-6">
          
          {/* Customer Selection Card */}
          <Card className="bg-gray-900/50 border-gray-800">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-white flex items-center justify-between">
                <span>Customer Details</span>
                {isWholesale && (
                  <Badge variant="secondary" className="bg-purple-500/20 text-purple-300 border-purple-500/30">
                    [Wholesale Order]
                  </Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label className="text-gray-400">Select Customer</Label>
                  <Select onValueChange={setSelectedCustomerId} value={selectedCustomerId}>
                    <SelectTrigger className="bg-gray-950 border-gray-700 text-white">
                      <SelectValue placeholder="Search customer..." />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-900 border-gray-800 text-white">
                      {customers.map((c) => (
                        <SelectItem key={c.id} value={c.id}>
                          <span className="flex items-center justify-between w-full gap-2">
                            <span>{c.name}</span>
                            <span className="text-xs text-gray-500 ml-2">({c.type})</span>
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {isWholesale && (
                    <div className="flex items-center gap-2 text-xs text-purple-400 bg-purple-900/10 p-2 rounded border border-purple-900/20 mt-2">
                      <AlertCircle size={14} />
                      Bulk pricing rules will be applied for this order.
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label className="text-gray-400">Due Date</Label>
                  <CalendarDatePicker 
                    className="bg-gray-950 border-gray-700 text-white [&::-webkit-calendar-picker-indicator]:invert" 
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Order Details Card */}
          <Card className="bg-gray-900/50 border-gray-800">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-white">Order Specifications</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label className="text-gray-400">Item Name</Label>
                  <Input 
                    placeholder="e.g. Red Bridal Lehenga" 
                    className="bg-gray-950 border-gray-700 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-gray-400">Design Reference (SKU)</Label>
                  <Input 
                    placeholder="Optional" 
                    className="bg-gray-950 border-gray-700 text-white"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-gray-400">Measurements / Notes</Label>
                <div className="relative">
                  <Textarea 
                    placeholder="Enter specific measurements or customization notes..." 
                    className="bg-gray-950 border-gray-700 text-white min-h-[120px]"
                  />
                  <Ruler className="absolute right-3 top-3 text-gray-600 h-5 w-5" />
                </div>
              </div>
            </CardContent>
          </Card>

        </div>
      </div>
    </div>
  );
};