import React, { useState } from 'react';
import { 
  Scissors, 
  Palette, 
  Shirt, 
  CheckCircle2, 
  MoreHorizontal, 
  Calendar,
  Plus,
  ArrowRight,
  Trash2,
  Edit,
  MoveRight
} from 'lucide-react';
import { Button } from "../ui/button";
import { cn } from "../ui/utils";
import { Badge } from "../ui/badge";
import { useNavigation } from '../../context/NavigationContext';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "../ui/dropdown-menu";

const initialColumns = [
  { id: 'cutting', title: 'Cutting', icon: Scissors, color: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/20' },
  { id: 'dyeing', title: 'Dyeing', icon: Palette, color: 'text-purple-400', bg: 'bg-purple-500/10', border: 'border-purple-500/20' },
  { id: 'stitching', title: 'Stitching', icon: Shirt, color: 'text-orange-400', bg: 'bg-orange-500/10', border: 'border-orange-500/20' },
  { id: 'ready', title: 'Ready', icon: CheckCircle2, color: 'text-green-400', bg: 'bg-green-500/10', border: 'border-green-500/20' },
];

const initialTasksData = [
  { id: '1', orderId: 'ORD-8821', customer: 'Mrs. Saad', item: 'Red Bridal Lehenga', status: 'dyeing', type: 'Retail', due: '12 Jan' },
  { id: '2', orderId: 'ORD-8822', customer: 'Bridal Boutique', item: '10x Chiffon Suits', status: 'cutting', type: 'Wholesale', due: '15 Jan' },
  { id: '3', orderId: 'ORD-8823', customer: 'Zara Ahmed', item: 'Velvet Shawl', status: 'stitching', type: 'Retail', due: '10 Jan' },
  { id: '4', orderId: 'ORD-8824', customer: 'Ali Textiles', item: '50x Lawn Sets', status: 'cutting', type: 'Wholesale', due: '20 Jan' },
  { id: '5', orderId: 'ORD-8825', customer: 'Walk-in', item: 'Mens Sherwani', status: 'ready', type: 'Retail', due: '05 Jan' },
];

export const PipelineBoard = () => {
  const { setCurrentView } = useNavigation();
  const [tasks, setTasks] = useState(initialTasksData);

  const handleMoveNext = (taskId: string, currentStatus: string) => {
    const statusOrder = ['cutting', 'dyeing', 'stitching', 'ready'];
    const currentIndex = statusOrder.indexOf(currentStatus);
    
    if (currentIndex < statusOrder.length - 1) {
      const nextStatus = statusOrder[currentIndex + 1];
      setTasks(tasks.map(t => t.id === taskId ? { ...t, status: nextStatus } : t));
    }
  };

  const handleDeleteTask = (taskId: string) => {
    setTasks(tasks.filter(t => t.id !== taskId));
  };

  const handleClearColumn = (columnId: string) => {
    setTasks(tasks.filter(t => t.status !== columnId));
  };

  return (
    <div className="flex flex-col h-full bg-gray-900 text-white animate-in fade-in duration-300">
      
      {/* Header */}
      <div className="flex items-center justify-between p-6 border-b border-gray-800 bg-gray-950/50">
        <div>
          <h1 className="text-2xl font-bold">Production Pipeline</h1>
          <p className="text-gray-400 text-sm mt-1">Track orders through manufacturing stages.</p>
        </div>
        <Button 
          onClick={() => setCurrentView('custom-new-order' as any)}
          className="bg-blue-600 hover:bg-blue-500 shadow-lg shadow-blue-900/20"
        >
          <Plus className="mr-2 h-4 w-4" /> New Order
        </Button>
      </div>

      {/* Board */}
      <div className="flex-1 overflow-x-auto p-6">
        <div className="flex gap-6 min-w-[1000px] h-full">
          {initialColumns.map((col) => (
            <div key={col.id} className="flex-1 flex flex-col min-w-[280px]">
              {/* Column Header */}
              <div className={cn("flex items-center justify-between p-3 rounded-t-lg border-t border-x bg-gray-900/80 backdrop-blur", col.border, col.bg)}>
                <div className="flex items-center gap-2 font-semibold">
                  <col.icon size={18} className={col.color} />
                  <span>{col.title}</span>
                  <Badge variant="secondary" className="bg-black/20 border-0 text-gray-300 text-xs ml-2">
                    {tasks.filter(t => t.status === col.id).length}
                  </Badge>
                </div>
                
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-6 w-6 text-gray-500 hover:text-white">
                      <MoreHorizontal size={16} />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-40 bg-gray-900 border-gray-800 text-white">
                    <DropdownMenuLabel>Column Options</DropdownMenuLabel>
                    <DropdownMenuSeparator className="bg-gray-800" />
                    <DropdownMenuItem 
                      className="focus:bg-gray-800 focus:text-red-400 text-red-400 cursor-pointer"
                      onClick={() => handleClearColumn(col.id)}
                    >
                      <Trash2 className="mr-2 h-4 w-4" /> Clear All
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>

              {/* Column Content */}
              <div className={cn("flex-1 bg-gray-900/30 border-x border-b rounded-b-lg p-3 space-y-3", col.border)}>
                {tasks
                  .filter(task => task.status === col.id)
                  .map(task => (
                    <div 
                      key={task.id} 
                      className="bg-gray-800 border border-gray-700 p-4 rounded-lg shadow-sm hover:border-gray-600 transition-colors cursor-pointer group relative"
                      onClick={() => setCurrentView('production-detail' as any)}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <span className="text-xs font-mono text-gray-500">{task.orderId}</span>
                        {task.type === 'Wholesale' && (
                          <span className="text-[10px] font-bold text-purple-300 bg-purple-900/30 px-1.5 py-0.5 rounded border border-purple-500/20">
                            WHOLESALE
                          </span>
                        )}
                        
                        <div 
                          className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity" 
                          onClick={(e) => e.stopPropagation()}
                        >
                           <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-6 w-6 text-gray-400 hover:text-white hover:bg-gray-700">
                                  <MoreHorizontal size={14} />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" className="w-40 bg-gray-900 border-gray-800 text-white">
                                <DropdownMenuItem 
                                  className="focus:bg-gray-800 focus:text-white cursor-pointer" 
                                  onClick={() => setCurrentView('production-detail' as any)}
                                >
                                  <Edit className="mr-2 h-4 w-4" /> View Details
                                </DropdownMenuItem>
                                
                                {col.id !== 'ready' && (
                                  <DropdownMenuItem 
                                    className="focus:bg-gray-800 focus:text-white cursor-pointer"
                                    onClick={() => handleMoveNext(task.id, task.status)}
                                  >
                                    <MoveRight className="mr-2 h-4 w-4" /> Move Next
                                  </DropdownMenuItem>
                                )}
                                
                                <DropdownMenuSeparator className="bg-gray-800" />
                                <DropdownMenuItem 
                                  className="focus:bg-gray-800 focus:text-red-400 text-red-400 cursor-pointer"
                                  onClick={() => handleDeleteTask(task.id)}
                                >
                                  <Trash2 className="mr-2 h-4 w-4" /> Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                        </div>
                      </div>
                      <h4 className="font-bold text-white mb-1 pr-6">{task.item}</h4>
                      <p className="text-sm text-gray-400 mb-3">{task.customer}</p>
                      
                      <div className="flex items-center justify-between text-xs text-gray-500 pt-3 border-t border-gray-700/50">
                        <div className="flex items-center gap-1.5">
                          <Calendar size={12} />
                          <span>{task.due}</span>
                        </div>
                        <div className="h-6 w-6 rounded-full bg-gradient-to-tr from-gray-700 to-gray-600 flex items-center justify-center text-[10px] font-bold text-white border border-gray-500">
                          {task.customer.charAt(0)}
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
