import React from 'react';
import { Scissors, Settings, Hand as HandIcon, Sparkles, Ruler } from 'lucide-react';
import { Label } from "../../ui/label";
import { Input } from "../../ui/input";
import { Textarea } from "../../ui/textarea";
import { Badge } from "../../ui/badge";
import { StitchingSelection } from '../CustomizeStudio';

interface StitchingStepProps {
  selection: StitchingSelection;
  onUpdate: (selection: StitchingSelection) => void;
}

const STITCHING_TYPES = [
  {
    id: 'machine',
    name: 'Machine Stitch',
    icon: Settings,
    description: 'Fast, precise, and uniform stitching',
    features: ['Quick turnaround', 'Consistent quality', 'Cost-effective'],
    color: 'blue'
  },
  {
    id: 'hand',
    name: 'Hand Stitch',
    icon: HandIcon,
    description: 'Traditional handcrafted stitching',
    features: ['Premium quality', 'Artisan touch', 'Flexible designs'],
    color: 'purple'
  },
  {
    id: 'decorative',
    name: 'Decorative Stitch',
    icon: Sparkles,
    description: 'Special decorative patterns and embellishments',
    features: ['Unique patterns', 'Premium finish', 'Custom designs'],
    color: 'pink'
  }
];

export const StitchingStep: React.FC<StitchingStepProps> = ({ selection, onUpdate }) => {
  const handleTypeSelect = (type: 'machine' | 'hand' | 'decorative') => {
    onUpdate({ ...selection, type });
  };

  const handleMeasurementUpdate = (field: string, value: string) => {
    onUpdate({
      ...selection,
      measurements: {
        ...selection.measurements,
        [field]: value
      }
    });
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <Scissors className="text-purple-400" size={28} />
          Stitching Options
        </h2>
        <p className="text-gray-400 mt-2">
          Choose your preferred stitching method and provide measurements
        </p>
      </div>

      {/* Stitching Type Selection */}
      <div>
        <Label className="text-gray-300 text-lg mb-4 block">Select Stitching Type *</Label>
        <div className="grid grid-cols-3 gap-6">
          {STITCHING_TYPES.map(type => {
            const Icon = type.icon;
            const isSelected = selection.type === type.id;
            
            return (
              <button
                key={type.id}
                onClick={() => handleTypeSelect(type.id as any)}
                className={`relative p-6 rounded-xl border-2 transition-all text-left ${
                  isSelected
                    ? `bg-${type.color}-500/20 border-${type.color}-500 shadow-lg shadow-${type.color}-500/20`
                    : 'bg-gray-800 border-gray-700 hover:border-gray-600'
                }`}
              >
                {/* Icon */}
                <div className={`w-14 h-14 rounded-lg mb-4 flex items-center justify-center ${
                  isSelected ? `bg-${type.color}-500/20` : 'bg-gray-900'
                }`}>
                  <Icon
                    size={28}
                    className={isSelected ? `text-${type.color}-400` : 'text-gray-500'}
                  />
                </div>

                {/* Title */}
                <h3 className={`font-bold mb-2 ${isSelected ? 'text-white' : 'text-gray-300'}`}>
                  {type.name}
                </h3>

                {/* Description */}
                <p className="text-sm text-gray-400 mb-4">
                  {type.description}
                </p>

                {/* Features */}
                <div className="space-y-1">
                  {type.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs text-gray-500">
                      <div className={`w-1 h-1 rounded-full ${
                        isSelected ? `bg-${type.color}-400` : 'bg-gray-600'
                      }`} />
                      {feature}
                    </div>
                  ))}
                </div>

                {/* Selected Badge */}
                {isSelected && (
                  <div className="absolute top-4 right-4">
                    <Badge className={`bg-${type.color}-500/20 text-${type.color}-400 border-${type.color}-500/30`}>
                      Selected
                    </Badge>
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Measurements Section */}
      {selection.type && (
        <div className="border-t border-gray-800 pt-6">
          <div className="flex items-center gap-2 mb-4">
            <Ruler className="text-purple-400" size={20} />
            <Label className="text-gray-300 text-lg">Measurements (Optional)</Label>
          </div>
          
          <div className="bg-gray-800/50 rounded-lg p-6 border border-gray-700">
            <div className="grid grid-cols-4 gap-4 mb-4">
              <div>
                <Label className="text-gray-400 mb-2 block text-sm">Chest (inches)</Label>
                <Input
                  type="number"
                  placeholder="e.g., 36"
                  value={selection.measurements?.chest || ''}
                  onChange={(e) => handleMeasurementUpdate('chest', e.target.value)}
                  className="bg-gray-900 border-gray-700 text-white"
                />
              </div>
              <div>
                <Label className="text-gray-400 mb-2 block text-sm">Waist (inches)</Label>
                <Input
                  type="number"
                  placeholder="e.g., 30"
                  value={selection.measurements?.waist || ''}
                  onChange={(e) => handleMeasurementUpdate('waist', e.target.value)}
                  className="bg-gray-900 border-gray-700 text-white"
                />
              </div>
              <div>
                <Label className="text-gray-400 mb-2 block text-sm">Length (inches)</Label>
                <Input
                  type="number"
                  placeholder="e.g., 42"
                  value={selection.measurements?.length || ''}
                  onChange={(e) => handleMeasurementUpdate('length', e.target.value)}
                  className="bg-gray-900 border-gray-700 text-white"
                />
              </div>
              <div>
                <Label className="text-gray-400 mb-2 block text-sm">Sleeve (inches)</Label>
                <Input
                  type="number"
                  placeholder="e.g., 20"
                  value={selection.measurements?.sleeve || ''}
                  onChange={(e) => handleMeasurementUpdate('sleeve', e.target.value)}
                  className="bg-gray-900 border-gray-700 text-white"
                />
              </div>
            </div>

            <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-3">
              <p className="text-sm text-blue-400">
                💡 <strong>Tip:</strong> Accurate measurements ensure perfect fitting. Leave blank if using standard sizes.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Additional Details */}
      {selection.type && (
        <div className="border-t border-gray-800 pt-6">
          <Label className="text-gray-300 text-lg mb-4 block">
            Additional Stitching Details (Optional)
          </Label>
          <Textarea
            placeholder="Add any special stitching instructions, preferences, or notes..."
            value={selection.details}
            onChange={(e) => onUpdate({ ...selection, details: e.target.value })}
            className="bg-gray-800 border-gray-700 text-white resize-none"
            rows={4}
          />
        </div>
      )}

      {/* Visual Representation */}
      {selection.type && (
        <div className="border-t border-gray-800 pt-6">
          <Label className="text-gray-300 text-lg mb-4 block">Stitching Preview</Label>
          <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-8 border border-gray-700">
            <div className="grid grid-cols-3 gap-8">
              {/* Visual representation based on selected type */}
              {selection.type === 'machine' && (
                <>
                  <div className="text-center">
                    <div className="w-24 h-24 mx-auto mb-3 bg-blue-500/10 rounded-lg border-2 border-blue-500/30 flex items-center justify-center">
                      <Settings size={40} className="text-blue-400" />
                    </div>
                    <div className="text-sm text-gray-400">Precision</div>
                  </div>
                  <div className="text-center">
                    <div className="w-24 h-24 mx-auto mb-3 bg-blue-500/10 rounded-lg border-2 border-blue-500/30 flex items-center justify-center">
                      <Scissors size={40} className="text-blue-400" />
                    </div>
                    <div className="text-sm text-gray-400">Speed</div>
                  </div>
                  <div className="text-center">
                    <div className="w-24 h-24 mx-auto mb-3 bg-blue-500/10 rounded-lg border-2 border-blue-500/30 flex items-center justify-center">
                      <Sparkles size={40} className="text-blue-400" />
                    </div>
                    <div className="text-sm text-gray-400">Quality</div>
                  </div>
                </>
              )}

              {selection.type === 'hand' && (
                <>
                  <div className="text-center">
                    <div className="w-24 h-24 mx-auto mb-3 bg-purple-500/10 rounded-lg border-2 border-purple-500/30 flex items-center justify-center">
                      <HandIcon size={40} className="text-purple-400" />
                    </div>
                    <div className="text-sm text-gray-400">Craftsmanship</div>
                  </div>
                  <div className="text-center">
                    <div className="w-24 h-24 mx-auto mb-3 bg-purple-500/10 rounded-lg border-2 border-purple-500/30 flex items-center justify-center">
                      <Sparkles size={40} className="text-purple-400" />
                    </div>
                    <div className="text-sm text-gray-400">Premium</div>
                  </div>
                  <div className="text-center">
                    <div className="w-24 h-24 mx-auto mb-3 bg-purple-500/10 rounded-lg border-2 border-purple-500/30 flex items-center justify-center">
                      <Settings size={40} className="text-purple-400" />
                    </div>
                    <div className="text-sm text-gray-400">Detailed</div>
                  </div>
                </>
              )}

              {selection.type === 'decorative' && (
                <>
                  <div className="text-center">
                    <div className="w-24 h-24 mx-auto mb-3 bg-pink-500/10 rounded-lg border-2 border-pink-500/30 flex items-center justify-center">
                      <Sparkles size={40} className="text-pink-400" />
                    </div>
                    <div className="text-sm text-gray-400">Decorative</div>
                  </div>
                  <div className="text-center">
                    <div className="w-24 h-24 mx-auto mb-3 bg-pink-500/10 rounded-lg border-2 border-pink-500/30 flex items-center justify-center">
                      <Scissors size={40} className="text-pink-400" />
                    </div>
                    <div className="text-sm text-gray-400">Artistic</div>
                  </div>
                  <div className="text-center">
                    <div className="w-24 h-24 mx-auto mb-3 bg-pink-500/10 rounded-lg border-2 border-pink-500/30 flex items-center justify-center">
                      <Settings size={40} className="text-pink-400" />
                    </div>
                    <div className="text-sm text-gray-400">Custom</div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
