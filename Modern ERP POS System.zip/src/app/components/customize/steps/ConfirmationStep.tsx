import React from 'react';
import { Eye, CheckCircle, Palette, Sparkles, Layers } from 'lucide-react';
import { Badge } from "../../ui/badge";
import { FabricSelection } from '../CustomizeStudio';

interface ConfirmationStepProps {
  selection: FabricSelection;
}

const FABRICS_MAP: Record<string, string> = {
  silk: 'Pure Silk',
  velvet: 'Red Velvet',
  cotton: 'Premium Cotton',
  chiffon: 'Chiffon',
  georgette: 'Georgette',
  banarasi: 'Banarasi Silk'
};

export const ConfirmationStep: React.FC<ConfirmationStepProps> = ({ selection }) => {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <Eye className="text-purple-400" size={28} />
          Preview & Confirmation
        </h2>
        <p className="text-gray-400 mt-2">
          Review your fabric selections before proceeding to stitching
        </p>
      </div>

      {/* Visual Preview */}
      <div className="grid grid-cols-2 gap-6">
        {/* Left: Fabric Visual */}
        <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-8 border border-gray-700">
          <div className="text-center mb-6">
            <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
              Visual Preview
            </Badge>
          </div>
          
          {/* Color Preview */}
          <div className="space-y-4">
            <div className="relative h-64 rounded-lg overflow-hidden border-2 border-gray-700">
              {/* Primary Color Layer */}
              <div
                className="absolute inset-0"
                style={{ backgroundColor: selection.colors.primary }}
              />
              
              {/* Gradient Overlay if dyeing is gradient */}
              {selection.dyeing?.type === 'gradient' && selection.dyeing.secondary && (
                <div
                  className="absolute inset-0"
                  style={{
                    background: `linear-gradient(135deg, ${selection.colors.primary} 0%, ${selection.dyeing.secondary} 100%)`
                  }}
                />
              )}

              {/* Pattern Overlay */}
              <div className="absolute inset-0 opacity-20">
                <div className="w-full h-full"
                  style={{
                    backgroundImage: `repeating-linear-gradient(
                      45deg,
                      transparent,
                      transparent 10px,
                      rgba(255,255,255,0.1) 10px,
                      rgba(255,255,255,0.1) 20px
                    )`
                  }}
                />
              </div>

              {/* Lace Border */}
              {selection.lace && (
                <div className="absolute bottom-0 left-0 right-0 h-16 bg-white/10 border-t-2 border-white/30 backdrop-blur-sm">
                  <div className="text-center text-white text-xs pt-2 font-semibold">
                    {selection.lace.style.toUpperCase()} LACE
                  </div>
                </div>
              )}

              {/* Fabric Label */}
              <div className="absolute top-4 left-4">
                <Badge className="bg-black/50 text-white border-white/20 backdrop-blur-sm">
                  {FABRICS_MAP[selection.baseFabric || '']}
                </Badge>
              </div>
            </div>

            {/* Color Swatches */}
            <div className="flex gap-3 justify-center">
              <div className="text-center">
                <div
                  className="w-16 h-16 rounded-lg border-2 border-white/20 shadow-lg"
                  style={{ backgroundColor: selection.colors.primary }}
                />
                <div className="text-xs text-gray-400 mt-2">Primary</div>
              </div>
              {selection.colors.secondary && (
                <div className="text-center">
                  <div
                    className="w-16 h-16 rounded-lg border-2 border-white/20 shadow-lg"
                    style={{ backgroundColor: selection.colors.secondary }}
                  />
                  <div className="text-xs text-gray-400 mt-2">Secondary</div>
                </div>
              )}
              {selection.colors.accent && (
                <div className="text-center">
                  <div
                    className="w-16 h-16 rounded-lg border-2 border-white/20 shadow-lg"
                    style={{ backgroundColor: selection.colors.accent }}
                  />
                  <div className="text-xs text-gray-400 mt-2">Accent</div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right: Details List */}
        <div className="space-y-4">
          {/* Base Fabric */}
          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center shrink-0">
                <Palette size={20} className="text-purple-400" />
              </div>
              <div className="flex-1">
                <h3 className="text-white font-semibold mb-2">Base Fabric</h3>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Type:</span>
                    <span className="text-white font-medium">
                      {FABRICS_MAP[selection.baseFabric || '']}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Cloth Type:</span>
                    <span className="text-white capitalize">{selection.clothType}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Lace Details */}
          {selection.lace && (
            <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-pink-500/20 rounded-lg flex items-center justify-center shrink-0">
                  <Sparkles size={20} className="text-pink-400" />
                </div>
                <div className="flex-1">
                  <h3 className="text-white font-semibold mb-2">Lace Details</h3>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Style:</span>
                      <span className="text-white capitalize">{selection.lace.style}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Width:</span>
                      <span className="text-white">{selection.lace.width.replace('inch', '"')}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Dyeing Details */}
          {selection.dyeing && (
            <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center shrink-0">
                  <Palette size={20} className="text-blue-400" />
                </div>
                <div className="flex-1">
                  <h3 className="text-white font-semibold mb-2">Dyeing</h3>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Type:</span>
                      <span className="text-white capitalize">{selection.dyeing.type}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Primary Color:</span>
                      <div className="flex items-center gap-2">
                        <div
                          className="w-4 h-4 rounded border border-gray-600"
                          style={{ backgroundColor: selection.dyeing.primary }}
                        />
                        <span className="text-white text-xs">{selection.dyeing.primary}</span>
                      </div>
                    </div>
                    {selection.dyeing.secondary && (
                      <div className="flex justify-between">
                        <span className="text-gray-400">Secondary Color:</span>
                        <div className="flex items-center gap-2">
                          <div
                            className="w-4 h-4 rounded border border-gray-600"
                            style={{ backgroundColor: selection.dyeing.secondary }}
                          />
                          <span className="text-white text-xs">{selection.dyeing.secondary}</span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Ready-made */}
          {selection.isReadyMade && (
            <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center shrink-0">
                  <CheckCircle size={20} className="text-green-400" />
                </div>
                <div className="flex-1">
                  <h3 className="text-white font-semibold mb-2">Ready-made Option</h3>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Type:</span>
                      <span className="text-white capitalize">
                        {selection.readyMadeType?.replace('-', ' ')}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Double Cloth */}
          {selection.isDoubleCloth && (
            <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-orange-500/20 rounded-lg flex items-center justify-center shrink-0">
                  <Layers size={20} className="text-orange-400" />
                </div>
                <div className="flex-1">
                  <h3 className="text-white font-semibold mb-2">Double Cloth</h3>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Type:</span>
                      <span className="text-white capitalize">{selection.doubleClothType}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Confirmation Message */}
      <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-6">
        <div className="flex items-start gap-3">
          <CheckCircle size={24} className="text-green-400 shrink-0" />
          <div>
            <h3 className="text-green-400 font-semibold mb-2">
              Fabric Selection Complete!
            </h3>
            <p className="text-gray-300 text-sm">
              Your fabric configuration looks great! Click "Next Step" to proceed with stitching options.
              You can always go back to make changes if needed.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
