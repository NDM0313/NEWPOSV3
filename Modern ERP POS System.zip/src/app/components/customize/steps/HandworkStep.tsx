import React from 'react';
import { Hand, Sparkles, Star, Zap, Heart, Smile } from 'lucide-react';
import { Label } from "../../ui/label";
import { Textarea } from "../../ui/textarea";
import { Badge } from "../../ui/badge";
import { HandworkSelection } from '../CustomizeStudio';

interface HandworkStepProps {
  selection: HandworkSelection;
  onUpdate: (selection: HandworkSelection) => void;
}

const HANDWORK_TYPES = [
  { id: 'embroidery', name: 'Embroidery', emoji: '🧵', color: 'purple' },
  { id: 'beadwork', name: 'Beadwork', emoji: '💎', color: 'blue' },
  { id: 'sequins', name: 'Sequins', emoji: '✨', color: 'pink' },
  { id: 'zari', name: 'Zari Work', emoji: '🌟', color: 'yellow' },
  { id: 'stonework', name: 'Stone Work', emoji: '💠', color: 'cyan' },
  { id: 'mirror', name: 'Mirror Work', emoji: '🪞', color: 'indigo' }
];

const INTENSITY_LEVELS = [
  { id: 'light', name: 'Light', description: 'Minimal handwork', icon: '🌙' },
  { id: 'medium', name: 'Medium', description: 'Moderate details', icon: '⭐' },
  { id: 'heavy', name: 'Heavy', description: 'Extensive work', icon: '🌟' }
];

export const HandworkStep: React.FC<HandworkStepProps> = ({ selection, onUpdate }) => {
  const toggleHandworkType = (typeId: string) => {
    const isSelected = selection.types.includes(typeId);
    const newTypes = isSelected
      ? selection.types.filter(t => t !== typeId)
      : [...selection.types, typeId];
    
    onUpdate({
      ...selection,
      types: newTypes,
      hasHandwork: newTypes.length > 0
    });
  };

  const setIntensity = (intensity: 'light' | 'medium' | 'heavy') => {
    onUpdate({ ...selection, intensity });
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <Hand className="text-purple-400" size={28} />
          Handwork & Embellishments
        </h2>
        <p className="text-gray-400 mt-2">
          Add the final creative touch with handwork decorations
        </p>
      </div>

      {/* Comic-Style Introduction */}
      <div className="bg-gradient-to-br from-purple-900/30 to-pink-900/30 rounded-xl p-6 border-2 border-purple-500/30">
        <div className="flex items-start gap-4">
          <div className="text-6xl">🎨</div>
          <div>
            <h3 className="text-xl font-bold text-white mb-2 flex items-center gap-2">
              <Sparkles className="text-yellow-400" size={20} />
              Welcome to the Magic Studio!
            </h3>
            <p className="text-gray-300">
              This is where your fabric comes to life! Our skilled artisans will add beautiful handwork 
              to make your piece truly one-of-a-kind. Choose your favorite decorations below! ✨
            </p>
          </div>
        </div>
      </div>

      {/* Handwork Enable Toggle */}
      <div className="flex items-center justify-between bg-gray-800 rounded-lg p-6 border border-gray-700">
        <div>
          <h3 className="text-white font-semibold mb-1">Add Handwork to Your Piece?</h3>
          <p className="text-sm text-gray-400">
            Handwork adds premium decorative details to your garment
          </p>
        </div>
        <button
          onClick={() => onUpdate({ ...selection, hasHandwork: !selection.hasHandwork, types: [] })}
          className={`px-6 py-3 rounded-lg border-2 transition-all font-semibold ${
            selection.hasHandwork
              ? 'bg-purple-500/20 border-purple-500 text-purple-400'
              : 'bg-gray-900 border-gray-700 text-gray-400 hover:border-gray-600'
          }`}
        >
          {selection.hasHandwork ? '✓ Yes, Add Handwork!' : 'No Handwork'}
        </button>
      </div>

      {selection.hasHandwork && (
        <>
          {/* Comic Panel 1: Select Handwork Types */}
          <div className="border-4 border-purple-500/30 rounded-xl p-6 bg-gray-900">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-purple-500/20 rounded-full flex items-center justify-center">
                <span className="text-2xl">1️⃣</span>
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">Choose Your Decorations!</h3>
                <p className="text-sm text-gray-400">Select one or more handwork types</p>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              {HANDWORK_TYPES.map(type => {
                const isSelected = selection.types.includes(type.id);
                
                return (
                  <button
                    key={type.id}
                    onClick={() => toggleHandworkType(type.id)}
                    className={`relative p-6 rounded-xl border-2 transition-all transform hover:scale-105 ${
                      isSelected
                        ? `bg-${type.color}-500/20 border-${type.color}-500 shadow-lg`
                        : 'bg-gray-800 border-gray-700 hover:border-gray-600'
                    }`}
                  >
                    {/* Comic-style burst background */}
                    {isSelected && (
                      <div className="absolute inset-0 opacity-10">
                        <div className="absolute top-0 left-0 text-6xl animate-pulse">💫</div>
                        <div className="absolute bottom-0 right-0 text-6xl animate-pulse">✨</div>
                      </div>
                    )}

                    <div className="relative z-10">
                      <div className="text-5xl mb-3 text-center">{type.emoji}</div>
                      <h4 className={`font-bold text-center ${isSelected ? 'text-white' : 'text-gray-300'}`}>
                        {type.name}
                      </h4>
                    </div>

                    {isSelected && (
                      <div className="absolute -top-2 -right-2 w-8 h-8 bg-green-500 rounded-full flex items-center justify-center border-2 border-gray-900">
                        <Sparkles size={16} className="text-white" />
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Comic Panel 2: Intensity Level */}
          {selection.types.length > 0 && (
            <div className="border-4 border-blue-500/30 rounded-xl p-6 bg-gray-900">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-blue-500/20 rounded-full flex items-center justify-center">
                  <span className="text-2xl">2️⃣</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">How Much Sparkle?</h3>
                  <p className="text-sm text-gray-400">Choose the intensity of handwork</p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                {INTENSITY_LEVELS.map(level => {
                  const isSelected = selection.intensity === level.id;
                  
                  return (
                    <button
                      key={level.id}
                      onClick={() => setIntensity(level.id as any)}
                      className={`p-6 rounded-xl border-2 transition-all ${
                        isSelected
                          ? 'bg-blue-500/20 border-blue-500 shadow-lg'
                          : 'bg-gray-800 border-gray-700 hover:border-gray-600'
                      }`}
                    >
                      <div className="text-4xl mb-2 text-center">{level.icon}</div>
                      <h4 className={`font-bold text-center mb-1 ${isSelected ? 'text-white' : 'text-gray-300'}`}>
                        {level.name}
                      </h4>
                      <p className="text-xs text-gray-500 text-center">{level.description}</p>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Comic Panel 3: Special Instructions */}
          {selection.types.length > 0 && (
            <div className="border-4 border-pink-500/30 rounded-xl p-6 bg-gray-900">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-pink-500/20 rounded-full flex items-center justify-center">
                  <span className="text-2xl">3️⃣</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">Any Special Wishes?</h3>
                  <p className="text-sm text-gray-400">Share your creative ideas with our artisans</p>
                </div>
              </div>

              <Textarea
                placeholder="Tell us about placement, patterns, or any specific design ideas... 🎨"
                value={selection.details}
                onChange={(e) => onUpdate({ ...selection, details: e.target.value })}
                className="bg-gray-800 border-gray-700 text-white resize-none"
                rows={4}
              />
            </div>
          )}

          {/* Comic-Style Preview Panel */}
          {selection.types.length > 0 && (
            <div className="bg-gradient-to-br from-purple-900/20 via-pink-900/20 to-blue-900/20 rounded-xl p-8 border-2 border-dashed border-purple-500/30">
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold text-white mb-2 flex items-center justify-center gap-2">
                  <Star className="text-yellow-400" />
                  Your Magical Creation
                  <Star className="text-yellow-400" />
                </h3>
                <p className="text-gray-400">Here's what you've chosen!</p>
              </div>

              {/* Comic Bubbles */}
              <div className="grid grid-cols-2 gap-6">
                <div className="relative bg-white/5 rounded-2xl p-6 border-2 border-purple-500/30">
                  <div className="absolute -top-3 left-6 bg-purple-500 text-white px-3 py-1 rounded-full text-xs font-bold">
                    HANDWORK
                  </div>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {selection.types.map(typeId => {
                      const type = HANDWORK_TYPES.find(t => t.id === typeId);
                      return (
                        <Badge key={typeId} className="bg-purple-500/20 text-purple-300 border-purple-500/30">
                          {type?.emoji} {type?.name}
                        </Badge>
                      );
                    })}
                  </div>
                </div>

                <div className="relative bg-white/5 rounded-2xl p-6 border-2 border-blue-500/30">
                  <div className="absolute -top-3 left-6 bg-blue-500 text-white px-3 py-1 rounded-full text-xs font-bold">
                    INTENSITY
                  </div>
                  <div className="mt-2">
                    <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30 text-lg">
                      {INTENSITY_LEVELS.find(l => l.id === selection.intensity)?.icon}{' '}
                      {INTENSITY_LEVELS.find(l => l.id === selection.intensity)?.name}
                    </Badge>
                  </div>
                </div>
              </div>

              {/* Success Message */}
              <div className="mt-6 bg-green-500/10 border border-green-500/30 rounded-lg p-4 text-center">
                <p className="text-green-400 font-semibold flex items-center justify-center gap-2">
                  <Heart className="text-red-400" size={20} />
                  Awesome! Your custom piece is ready to be created!
                  <Smile className="text-yellow-400" size={20} />
                </p>
              </div>
            </div>
          )}
        </>
      )}

      {/* No Handwork Selected */}
      {!selection.hasHandwork && (
        <div className="text-center py-12 bg-gray-800/30 rounded-xl border-2 border-dashed border-gray-700">
          <div className="text-6xl mb-4">✋</div>
          <h3 className="text-xl font-semibold text-gray-300 mb-2">No Handwork Selected</h3>
          <p className="text-gray-500">
            That's okay! Your piece will still look beautiful without handwork.
          </p>
        </div>
      )}
    </div>
  );
};
