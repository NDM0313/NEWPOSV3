import ModernLedger from './ModernLedger';

export default function App() {
  return <ModernLedger />;
}