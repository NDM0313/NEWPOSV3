import { Calendar, TrendingUp, TrendingDown, FileText, CreditCard, Tag } from 'lucide-react';
import type { Transaction } from '../../../types/index';

interface TransactionTimelineProps {
  transactions: Transaction[];
  onTransactionClick: (transaction: Transaction) => void;
}

export function TransactionTimeline({ transactions, onTransactionClick }: TransactionTimelineProps) {
  // Group by month
  const groupedByMonth = transactions.reduce((groups, transaction) => {
    const monthYear = new Date(transaction.date).toLocaleDateString('en-GB', { 
      month: 'long', 
      year: 'numeric' 
    });
    if (!groups[monthYear]) {
      groups[monthYear] = [];
    }
    groups[monthYear].push(transaction);
    return groups;
  }, {} as Record<string, Transaction[]>);

  const getDocumentIcon = (type: string) => {
    switch (type) {
      case 'Sale':
        return <FileText className="w-4 h-4" />;
      case 'Payment':
        return <CreditCard className="w-4 h-4" />;
      case 'Discount':
        return <Tag className="w-4 h-4" />;
      default:
        return <FileText className="w-4 h-4" />;
    }
  };

  const getDocumentColor = (type: string) => {
    switch (type) {
      case 'Sale':
        return 'bg-blue-600';
      case 'Payment':
        return 'bg-emerald-600';
      case 'Discount':
        return 'bg-purple-600';
      default:
        return 'bg-slate-600';
    }
  };

  return (
    <div className="space-y-8">
      {Object.entries(groupedByMonth).map(([monthYear, monthTransactions]) => {
        const monthDebit = monthTransactions.reduce((sum, t) => sum + t.debit, 0);
        const monthCredit = monthTransactions.reduce((sum, t) => sum + t.credit, 0);

        return (
          <div key={monthYear} className="relative">
            {/* Month Header */}
            <div className="sticky top-0 z-10 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-xl px-6 py-4 shadow-lg mb-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">
                    <Calendar className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="text-xl font-bold">{monthYear}</div>
                    <div className="text-sm text-blue-100">{monthTransactions.length} transactions</div>
                  </div>
                </div>
                <div className="flex items-center gap-8">
                  <div className="text-right">
                    <div className="text-xs text-blue-100">Total Debit</div>
                    <div className="text-lg font-bold">Rs {monthDebit.toLocaleString('en-PK')}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-blue-100">Total Credit</div>
                    <div className="text-lg font-bold">Rs {monthCredit.toLocaleString('en-PK')}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Timeline */}
            <div className="relative pl-12">
              {/* Vertical Line */}
              <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gradient-to-b from-blue-300 via-slate-300 to-blue-300"></div>

              {monthTransactions.map((transaction, index) => (
                <div
                  key={transaction.id}
                  onClick={() => onTransactionClick(transaction)}
                  className="relative mb-6 group cursor-pointer"
                >
                  {/* Timeline Dot */}
                  <div className={`absolute -left-6 w-12 h-12 rounded-full ${getDocumentColor(transaction.documentType)} flex items-center justify-center shadow-lg border-4 border-white group-hover:scale-110 transition-transform z-10`}>
                    {getDocumentIcon(transaction.documentType)}
                    <div className="text-white">
                      {getDocumentIcon(transaction.documentType)}
                    </div>
                  </div>

                  {/* Transaction Card */}
                  <div className="ml-8 bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-all group-hover:border-blue-300 overflow-hidden">
                    <div className="p-5">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <div className="text-base font-bold text-blue-600">{transaction.referenceNo}</div>
                            <span className={`px-2.5 py-0.5 rounded-full text-xs border ${
                              transaction.documentType === 'Sale' ? 'bg-blue-50 text-blue-700 border-blue-200' :
                              transaction.documentType === 'Payment' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
                              'bg-purple-50 text-purple-700 border-purple-200'
                            }`}>
                              {transaction.documentType}
                            </span>
                          </div>
                          <div className="text-sm text-slate-700 mb-2">{transaction.description}</div>
                          <div className="flex items-center gap-4 text-xs text-slate-500">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              {new Date(transaction.date).toLocaleDateString('en-GB', { 
                                day: '2-digit', 
                                month: 'short',
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </span>
                            <span className="flex items-center gap-1">
                              <CreditCard className="w-3 h-3" />
                              {transaction.paymentAccount}
                            </span>
                          </div>
                        </div>

                        <div className="text-right ml-4">
                          {transaction.debit > 0 && (
                            <div className="flex items-center justify-end gap-2 mb-1">
                              <TrendingUp className="w-4 h-4 text-orange-600" />
                              <span className="text-xl font-bold text-orange-700 tabular-nums">
                                +{transaction.debit.toLocaleString('en-PK')}
                              </span>
                            </div>
                          )}
                          {transaction.credit > 0 && (
                            <div className="flex items-center justify-end gap-2 mb-1">
                              <TrendingDown className="w-4 h-4 text-emerald-600" />
                              <span className="text-xl font-bold text-emerald-700 tabular-nums">
                                -{transaction.credit.toLocaleString('en-PK')}
                              </span>
                            </div>
                          )}
                          <div className="text-xs text-slate-500 mt-2">Balance</div>
                          <div className="text-base font-bold text-slate-900 tabular-nums">
                            Rs {transaction.runningBalance.toLocaleString('en-PK')}
                          </div>
                        </div>
                      </div>

                      {transaction.notes && (
                        <div className="mt-3 pt-3 border-t border-slate-200">
                          <div className="text-xs text-slate-500 mb-1">Notes:</div>
                          <div className="text-sm text-slate-700">{transaction.notes}</div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Connection Line to Next */}
                  {index < monthTransactions.length - 1 && (
                    <div className="absolute left-0 top-12 bottom-0 w-px bg-slate-200"></div>
                  )}
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}