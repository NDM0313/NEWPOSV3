import { TrendingUp, TrendingDown, FileText, ArrowRight, CheckCircle } from 'lucide-react';
import type { LedgerData, Transaction } from '../../../types';

interface OverviewTabProps {
  ledgerData: LedgerData;
  onTransactionClick: (transaction: Transaction) => void;
}

export function OverviewTab({ ledgerData, onTransactionClick }: OverviewTabProps) {
  const formatAmount = (amount: number) => amount.toLocaleString('en-PK');
  
  const recentTransactions = ledgerData.transactions.slice(0, 5);
  const overdueInvoices = ledgerData.invoices.filter(inv => inv.status === 'Unpaid');
  const partiallyPaid = ledgerData.invoices.filter(inv => inv.status === 'Partially Paid');

  // Calculate payment trends
  const totalPayments = ledgerData.transactions.filter(t => t.documentType === 'Payment').length;
  const totalSales = ledgerData.transactions.filter(t => t.documentType === 'Sale').length;

  return (
    <div className="space-y-6">
      {/* Quick Stats Grid */}
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-5 border border-blue-200">
          <div className="flex justify-between items-start mb-3">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <span className="text-xs px-2 py-1 bg-blue-600 text-white rounded-full">Current</span>
          </div>
          <div className="text-xs text-blue-700 mb-1">Account Balance</div>
          <div className="text-2xl text-blue-900">Rs {formatAmount(ledgerData.closingBalance)}</div>
        </div>

        <div className="bg-white rounded-xl p-5 border border-slate-200">
          <div className="flex justify-between items-start mb-3">
            <div className="w-10 h-10 bg-orange-50 rounded-lg flex items-center justify-center">
              <FileText className="w-5 h-5 text-orange-600" />
            </div>
            <span className="text-xs px-2 py-1 bg-orange-100 text-orange-700 rounded-full">{overdueInvoices.length}</span>
          </div>
          <div className="text-xs text-slate-600 mb-1">Overdue Amount</div>
          <div className="text-2xl text-slate-900">
            Rs {formatAmount(overdueInvoices.reduce((sum, inv) => sum + inv.pendingAmount, 0))}
          </div>
        </div>

        <div className="bg-white rounded-xl p-5 border border-slate-200">
          <div className="flex justify-between items-start mb-3">
            <div className="w-10 h-10 bg-emerald-50 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-emerald-600" />
            </div>
            <span className="text-xs px-2 py-1 bg-emerald-100 text-emerald-700 rounded-full">{totalPayments}</span>
          </div>
          <div className="text-xs text-slate-600 mb-1">Total Received</div>
          <div className="text-2xl text-slate-900">Rs {formatAmount(ledgerData.totalCredit)}</div>
        </div>

        <div className="bg-white rounded-xl p-5 border border-slate-200">
          <div className="flex justify-between items-start mb-3">
            <div className="w-10 h-10 bg-purple-50 rounded-lg flex items-center justify-center">
              <TrendingDown className="w-5 h-5 text-purple-600" />
            </div>
            <span className="text-xs px-2 py-1 bg-purple-100 text-purple-700 rounded-full">{totalSales}</span>
          </div>
          <div className="text-xs text-slate-600 mb-1">Total Sales</div>
          <div className="text-2xl text-slate-900">Rs {formatAmount(ledgerData.totalDebit)}</div>
        </div>
      </div>

      {/* Two Column Layout */}
      <div className="grid grid-cols-2 gap-6">
        {/* Recent Transactions */}
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 bg-slate-50">
            <h3 className="text-sm text-slate-900">Recent Transactions</h3>
            <p className="text-xs text-slate-500 mt-0.5">Last 5 activities</p>
          </div>
          <div className="divide-y divide-slate-100">
            {recentTransactions.map((transaction) => (
              <button
                key={transaction.id}
                onClick={() => onTransactionClick(transaction)}
                className="w-full px-5 py-4 hover:bg-blue-50 transition-colors text-left"
              >
                <div className="flex justify-between items-start mb-2">
                  <div className="text-sm text-slate-900">{transaction.referenceNo}</div>
                  <div className="text-xs text-slate-500">
                    {new Date(transaction.date).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' })}
                  </div>
                </div>
                <div className="text-xs text-slate-600 mb-2">{transaction.description}</div>
                <div className="flex justify-between items-center">
                  <span className={`text-xs px-2 py-1 rounded ${
                    transaction.documentType === 'Sale' ? 'bg-blue-100 text-blue-700' :
                    transaction.documentType === 'Payment' ? 'bg-emerald-100 text-emerald-700' :
                    'bg-purple-100 text-purple-700'
                  }`}>
                    {transaction.documentType}
                  </span>
                  <span className={`text-sm ${
                    transaction.debit > 0 ? 'text-orange-700' : 'text-emerald-700'
                  }`}>
                    {transaction.debit > 0 ? '+' : '-'} Rs {formatAmount(transaction.debit || transaction.credit)}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Pending Invoices */}
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 bg-slate-50">
            <h3 className="text-sm text-slate-900">Pending Invoices</h3>
            <p className="text-xs text-slate-500 mt-0.5">Requires attention</p>
          </div>
          <div className="divide-y divide-slate-100">
            {[...overdueInvoices, ...partiallyPaid].slice(0, 5).map((invoice) => (
              <div key={invoice.invoiceNo} className="px-5 py-4 hover:bg-orange-50/50 transition-colors">
                <div className="flex justify-between items-start mb-2">
                  <div className="text-sm text-slate-900">{invoice.invoiceNo}</div>
                  <div className="text-xs text-slate-500">
                    {new Date(invoice.date).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' })}
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className={`text-xs px-2 py-1 rounded ${
                    invoice.status === 'Unpaid' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'
                  }`}>
                    {invoice.status}
                  </span>
                  <div className="text-right">
                    <div className="text-xs text-slate-500">Pending</div>
                    <div className="text-sm text-orange-700">Rs {formatAmount(invoice.pendingAmount)}</div>
                  </div>
                </div>
              </div>
            ))}
            {[...overdueInvoices, ...partiallyPaid].length === 0 && (
              <div className="px-5 py-8 text-center">
                <CheckCircle className="w-12 h-12 text-emerald-500 mx-auto mb-2" />
                <p className="text-sm text-slate-600">All invoices cleared!</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Payment Performance */}
      <div className="bg-gradient-to-br from-slate-50 to-blue-50 rounded-xl border border-slate-200 p-6">
        <h3 className="text-sm text-slate-900 mb-4">Payment Performance</h3>
        <div className="grid grid-cols-3 gap-6">
          <div className="text-center">
            <div className="text-3xl text-slate-900 mb-1">
              {ledgerData.invoicesSummary.totalInvoices}
            </div>
            <div className="text-xs text-slate-600">Total Invoices</div>
          </div>
          <div className="text-center border-x border-slate-300">
            <div className="text-3xl text-emerald-700 mb-1">
              {((ledgerData.invoicesSummary.totalPaymentReceived / ledgerData.invoicesSummary.totalInvoiceAmount) * 100).toFixed(1)}%
            </div>
            <div className="text-xs text-slate-600">Collection Rate</div>
          </div>
          <div className="text-center">
            <div className="text-3xl text-orange-700 mb-1">
              {ledgerData.invoicesSummary.unpaid + ledgerData.invoicesSummary.partiallyPaid}
            </div>
            <div className="text-xs text-slate-600">Pending Invoices</div>
          </div>
        </div>
      </div>
    </div>
  );
}