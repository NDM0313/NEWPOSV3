import { Clock, TrendingUp, AlertTriangle } from 'lucide-react';
import type { Invoice } from '../../../types';

interface AgingReportTabProps {
  invoices: Invoice[];
}

export function AgingReportTab({ invoices }: AgingReportTabProps) {
  // Safety check for invoices array
  const safeInvoices = invoices || [];
  
  // Calculate aging buckets (0-30, 31-60, 61-90, 90+ days)
  const today = new Date('2025-01-27'); // Current date from the app
  
  const agingBuckets = safeInvoices
    .filter(inv => inv.pendingAmount > 0)
    .reduce((acc, invoice) => {
      const invoiceDate = new Date(invoice.date);
      const daysPast = Math.floor((today.getTime() - invoiceDate.getTime()) / (1000 * 60 * 60 * 24));
      
      const bucket = daysPast <= 30 ? '0-30' :
                    daysPast <= 60 ? '31-60' :
                    daysPast <= 90 ? '61-90' : '90+';
      
      if (!acc[bucket]) {
        acc[bucket] = { count: 0, amount: 0, invoices: [] };
      }
      
      acc[bucket].count += 1;
      acc[bucket].amount += invoice.pendingAmount;
      acc[bucket].invoices.push({ ...invoice, daysPast });
      
      return acc;
    }, {} as Record<string, { count: number; amount: number; invoices: Array<Invoice & { daysPast: number }> }>);

  const totalPending = Object.values(agingBuckets).reduce((sum, bucket) => sum + bucket.amount, 0);

  const getBucketColor = (bucket: string) => {
    switch (bucket) {
      case '0-30':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case '31-60':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case '61-90':
        return 'bg-orange-50 text-orange-700 border-orange-200';
      case '90+':
        return 'bg-red-50 text-red-700 border-red-200';
      default:
        return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  const getBucketIcon = (bucket: string) => {
    switch (bucket) {
      case '0-30':
        return <Clock className="w-5 h-5" />;
      case '31-60':
        return <TrendingUp className="w-5 h-5" />;
      case '61-90':
        return <AlertTriangle className="w-5 h-5" />;
      case '90+':
        return <AlertTriangle className="w-5 h-5" />;
      default:
        return <Clock className="w-5 h-5" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-4 gap-4">
        {['0-30', '31-60', '61-90', '90+'].map((bucket) => {
          const data = agingBuckets[bucket] || { count: 0, amount: 0, invoices: [] };
          const percentage = totalPending > 0 ? (data.amount / totalPending * 100).toFixed(1) : 0;
          
          return (
            <div key={bucket} className={`rounded-xl p-5 border ${getBucketColor(bucket)}`}>
              <div className="flex items-start justify-between mb-3">
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${getBucketColor(bucket).replace('text-', 'bg-').replace('-700', '-600')}`}>
                  <div className="text-white">
                    {getBucketIcon(bucket)}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs opacity-80">{bucket} days</div>
                  <div className="text-sm mt-0.5">{percentage}%</div>
                </div>
              </div>
              <div className="text-xs mb-1 opacity-80">{data.count} invoices</div>
              <div className="text-xl">Rs {data.amount.toLocaleString('en-PK')}</div>
            </div>
          );
        })}
      </div>

      {/* Aging Details */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50">
          <h3 className="text-sm text-slate-900">Receivables Aging Detail</h3>
          <p className="text-xs text-slate-500 mt-0.5">Outstanding invoices by age</p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="px-6 py-3 text-left text-xs text-slate-600">Invoice</th>
                <th className="px-6 py-3 text-left text-xs text-slate-600">Date</th>
                <th className="px-6 py-3 text-left text-xs text-slate-600">Age (Days)</th>
                <th className="px-6 py-3 text-left text-xs text-slate-600">Status</th>
                <th className="px-6 py-3 text-right text-xs text-slate-600">Invoice Total</th>
                <th className="px-6 py-3 text-right text-xs text-slate-600">Paid</th>
                <th className="px-6 py-3 text-right text-xs text-slate-600">Pending</th>
              </tr>
            </thead>
            <tbody>
              {Object.entries(agingBuckets)
                .sort((a, b) => {
                  const order = { '0-30': 0, '31-60': 1, '61-90': 2, '90+': 3 };
                  return order[a[0] as keyof typeof order] - order[b[0] as keyof typeof order];
                })
                .map(([bucket, data]) => (
                  <>
                    {/* Bucket Header */}
                    <tr key={bucket} className="bg-slate-100 border-y border-slate-200">
                      <td colSpan={7} className="px-6 py-3">
                        <div className="flex items-center gap-3">
                          <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-lg text-xs border ${getBucketColor(bucket)}`}>
                            {getBucketIcon(bucket)}
                            {bucket} Days
                          </span>
                          <span className="text-xs text-slate-600">
                            {data.count} invoices • Rs {data.amount.toLocaleString('en-PK')} pending
                          </span>
                        </div>
                      </td>
                    </tr>
                    
                    {/* Invoice Rows */}
                    {data.invoices
                      .sort((a, b) => b.daysPast - a.daysPast)
                      .map((invoice, index) => (
                        <tr
                          key={invoice.invoiceNo}
                          className={`border-b border-slate-100 hover:bg-slate-50 transition-colors ${
                            index % 2 === 0 ? 'bg-white' : 'bg-slate-50/30'
                          }`}
                        >
                          <td className="px-6 py-3 text-slate-900">{invoice.invoiceNo}</td>
                          <td className="px-6 py-3 text-slate-700">
                            {new Date(invoice.date).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}
                          </td>
                          <td className="px-6 py-3">
                            <span className={`inline-flex items-center gap-1 px-2 py-1 rounded text-xs ${
                              invoice.daysPast <= 30 ? 'bg-emerald-100 text-emerald-700' :
                              invoice.daysPast <= 60 ? 'bg-amber-100 text-amber-700' :
                              invoice.daysPast <= 90 ? 'bg-orange-100 text-orange-700' :
                              'bg-red-100 text-red-700'
                            }`}>
                              {invoice.daysPast} days
                            </span>
                          </td>
                          <td className="px-6 py-3">
                            <span className={`text-xs px-2 py-1 rounded ${
                              invoice.status === 'Unpaid' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'
                            }`}>
                              {invoice.status}
                            </span>
                          </td>
                          <td className="px-6 py-3 text-right text-slate-900 tabular-nums">
                            {invoice.invoiceTotal.toLocaleString('en-PK')}
                          </td>
                          <td className="px-6 py-3 text-right text-emerald-700 tabular-nums">
                            {invoice.paidAmount.toLocaleString('en-PK')}
                          </td>
                          <td className="px-6 py-3 text-right text-orange-700 tabular-nums">
                            {invoice.pendingAmount.toLocaleString('en-PK')}
                          </td>
                        </tr>
                      ))}
                  </>
                ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Risk Analysis */}
      <div className="bg-gradient-to-br from-red-50 to-orange-50 rounded-xl border border-red-200 p-6">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 bg-red-600 rounded-lg flex items-center justify-center flex-shrink-0">
            <AlertTriangle className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <h3 className="text-base text-red-900 mb-2">Collection Risk Analysis</h3>
            <div className="grid grid-cols-3 gap-6">
              <div>
                <div className="text-xs text-red-700 mb-1">High Risk (90+ days)</div>
                <div className="text-2xl text-red-900">
                  Rs {(agingBuckets['90+']?.amount || 0).toLocaleString('en-PK')}
                </div>
                <div className="text-xs text-red-700 mt-1">
                  {agingBuckets['90+']?.count || 0} invoices requiring immediate attention
                </div>
              </div>
              <div>
                <div className="text-xs text-orange-700 mb-1">Medium Risk (61-90 days)</div>
                <div className="text-2xl text-orange-900">
                  Rs {(agingBuckets['61-90']?.amount || 0).toLocaleString('en-PK')}
                </div>
                <div className="text-xs text-orange-700 mt-1">
                  {agingBuckets['61-90']?.count || 0} invoices need follow-up
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-700 mb-1">Total Outstanding</div>
                <div className="text-2xl text-slate-900">
                  Rs {totalPending.toLocaleString('en-PK')}
                </div>
                <div className="text-xs text-slate-700 mt-1">
                  Across {Object.values(agingBuckets).reduce((sum, b) => sum + b.count, 0)} pending invoices
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}