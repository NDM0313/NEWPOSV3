import { X, FileText, Calendar, CreditCard, MessageSquare } from 'lucide-react';
import type { Transaction } from '../../types';

interface ModernTransactionModalProps {
  transaction: Transaction;
  onClose: () => void;
}

export function ModernTransactionModal({ transaction, onClose }: ModernTransactionModalProps) {
  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div
        className="bg-white w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-2xl shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="border-b border-slate-200 px-8 py-6 bg-gradient-to-r from-blue-50 to-slate-50">
          <div className="flex justify-between items-start">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center flex-shrink-0">
                <FileText className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-xl text-slate-900">Transaction Details</h2>
                <p className="text-sm text-slate-600 mt-1">{transaction.referenceNo}</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-10 h-10 rounded-lg hover:bg-slate-200 flex items-center justify-center text-slate-500 hover:text-slate-700 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Content */}
        <div className="px-8 py-6">
          {/* Basic Info Cards */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
              <div className="flex items-center gap-2 text-xs text-slate-600 mb-2">
                <Calendar className="w-4 h-4" />
                Transaction Date
              </div>
              <div className="text-base text-slate-900">
                {new Date(transaction.date).toLocaleDateString('en-GB', { 
                  day: '2-digit', 
                  month: 'long', 
                  year: 'numeric' 
                })}
              </div>
            </div>

            <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
              <div className="flex items-center gap-2 text-xs text-slate-600 mb-2">
                <FileText className="w-4 h-4" />
                Document Type
              </div>
              <div className="text-base text-slate-900">{transaction.documentType}</div>
            </div>

            <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
              <div className="flex items-center gap-2 text-xs text-slate-600 mb-2">
                <CreditCard className="w-4 h-4" />
                Payment Account
              </div>
              <div className="text-base text-slate-900">{transaction.paymentAccount}</div>
            </div>

            <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
              <div className="flex items-center gap-2 text-xs text-slate-600 mb-2">
                <MessageSquare className="w-4 h-4" />
                Reference Number
              </div>
              <div className="text-base text-slate-900">{transaction.referenceNo}</div>
            </div>
          </div>

          {/* Description */}
          <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 mb-6">
            <div className="text-xs text-slate-600 mb-2">Description</div>
            <div className="text-sm text-slate-900">{transaction.description}</div>
          </div>

          {/* Notes */}
          {transaction.notes && (
            <div className="bg-amber-50 rounded-xl p-4 border border-amber-200 mb-6">
              <div className="text-xs text-amber-800 mb-2">Notes</div>
              <div className="text-sm text-amber-900">{transaction.notes}</div>
            </div>
          )}

          {/* Amount Details */}
          <div className="bg-gradient-to-br from-slate-50 to-blue-50 rounded-xl p-6 border border-slate-200 mb-6">
            <div className="grid grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-xs text-slate-600 mb-2">Debit Amount</div>
                <div className="text-2xl text-orange-700">
                  {transaction.debit > 0 ? `Rs ${transaction.debit.toLocaleString('en-PK')}` : '-'}
                </div>
              </div>
              <div className="text-center border-x border-slate-300">
                <div className="text-xs text-slate-600 mb-2">Credit Amount</div>
                <div className="text-2xl text-emerald-700">
                  {transaction.credit > 0 ? `Rs ${transaction.credit.toLocaleString('en-PK')}` : '-'}
                </div>
              </div>
              <div className="text-center">
                <div className="text-xs text-slate-600 mb-2">Running Balance</div>
                <div className="text-2xl text-slate-900">
                  Rs {transaction.runningBalance.toLocaleString('en-PK')}
                </div>
              </div>
            </div>
          </div>

          {/* Linked Invoices */}
          {transaction.linkedInvoices && transaction.linkedInvoices.length > 0 && (
            <div className="bg-blue-50 rounded-xl p-4 border border-blue-200 mb-6">
              <div className="text-xs text-blue-800 mb-3">Linked Invoices</div>
              <div className="flex flex-wrap gap-2">
                {transaction.linkedInvoices.map((invoice) => (
                  <span key={invoice} className="inline-flex items-center px-3 py-1.5 bg-white border border-blue-200 rounded-lg text-sm text-blue-900">
                    {invoice}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Additional Info */}
          <div className="border-t border-slate-200 pt-4 text-xs text-slate-500">
            <div className="flex justify-between">
              <span>Transaction ID: {transaction.id}</span>
              <span>Generated on {new Date().toLocaleDateString('en-GB')}</span>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="border-t border-slate-200 px-8 py-5 bg-slate-50 flex justify-end gap-3">
          <button
            onClick={onClose}
            className="px-6 py-2.5 bg-white border border-slate-300 text-slate-700 text-sm rounded-lg hover:bg-slate-100 transition-colors"
          >
            Close
          </button>
          <button className="px-6 py-2.5 bg-gradient-to-r from-blue-600 to-blue-700 text-white text-sm rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all shadow-md">
            Print Details
          </button>
        </div>
      </div>
    </div>
  );
}