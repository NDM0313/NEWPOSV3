import { FileText, CreditCard, TrendingUp, TrendingDown } from 'lucide-react';
import type { LedgerData } from '../../types';

interface ModernSummaryCardsProps {
  ledgerData: LedgerData;
}

export function ModernSummaryCards({ ledgerData }: ModernSummaryCardsProps) {
  const { openingBalance, totalDebit, totalCredit, closingBalance, invoicesSummary } = ledgerData;

  const formatAmount = (amount: number) => {
    return amount.toLocaleString('en-PK');
  };

  return (
    <div className="space-y-6">
      {/* Primary Balance Cards */}
      <div className="grid grid-cols-4 gap-6">
        {/* Opening Balance */}
        <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-start justify-between mb-3">
            <div className="w-12 h-12 bg-slate-100 rounded-lg flex items-center justify-center">
              <CreditCard className="w-6 h-6 text-slate-600" />
            </div>
            <span className="text-xs px-2 py-1 bg-slate-100 text-slate-600 rounded-full">Opening</span>
          </div>
          <div className="text-sm text-slate-600 mb-1">Opening Balance</div>
          <div className="text-2xl text-slate-900">Rs {formatAmount(openingBalance)}</div>
        </div>

        {/* Total Debit */}
        <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-start justify-between mb-3">
            <div className="w-12 h-12 bg-orange-50 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-orange-600" />
            </div>
            <span className="text-xs px-2 py-1 bg-orange-50 text-orange-600 rounded-full">Debit</span>
          </div>
          <div className="text-sm text-slate-600 mb-1">Total Debit</div>
          <div className="text-2xl text-slate-900">Rs {formatAmount(totalDebit)}</div>
        </div>

        {/* Total Credit */}
        <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-start justify-between mb-3">
            <div className="w-12 h-12 bg-emerald-50 rounded-lg flex items-center justify-center">
              <TrendingDown className="w-6 h-6 text-emerald-600" />
            </div>
            <span className="text-xs px-2 py-1 bg-emerald-50 text-emerald-600 rounded-full">Credit</span>
          </div>
          <div className="text-sm text-slate-600 mb-1">Total Credit</div>
          <div className="text-2xl text-slate-900">Rs {formatAmount(totalCredit)}</div>
        </div>

        {/* Closing Balance */}
        <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow">
          <div className="flex items-start justify-between mb-3">
            <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">
              <CreditCard className="w-6 h-6 text-white" />
            </div>
            <span className="text-xs px-2 py-1 bg-white/20 text-white rounded-full">Current</span>
          </div>
          <div className="text-sm text-blue-100 mb-1">Closing Balance</div>
          <div className="text-2xl text-white">Rs {formatAmount(closingBalance)}</div>
        </div>
      </div>

      {/* Invoices Summary Card */}
      <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center">
            <FileText className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            <h3 className="text-base text-slate-900">Invoices Summary</h3>
            <p className="text-xs text-slate-500">Overview of all customer invoices</p>
          </div>
        </div>

        <div className="grid grid-cols-4 gap-6 mb-6">
          <div className="text-center p-4 bg-slate-50 rounded-lg">
            <div className="text-xs text-slate-600 mb-1">Total Invoices</div>
            <div className="text-2xl text-slate-900">{invoicesSummary.totalInvoices}</div>
          </div>
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <div className="text-xs text-slate-600 mb-1">Invoice Amount</div>
            <div className="text-xl text-blue-700">Rs {formatAmount(invoicesSummary.totalInvoiceAmount)}</div>
          </div>
          <div className="text-center p-4 bg-emerald-50 rounded-lg">
            <div className="text-xs text-slate-600 mb-1">Payment Received</div>
            <div className="text-xl text-emerald-700">Rs {formatAmount(invoicesSummary.totalPaymentReceived)}</div>
          </div>
          <div className="text-center p-4 bg-orange-50 rounded-lg">
            <div className="text-xs text-slate-600 mb-1">Pending Amount</div>
            <div className="text-xl text-orange-700">Rs {formatAmount(invoicesSummary.pendingAmount)}</div>
          </div>
        </div>

        <div className="flex items-center justify-center gap-8 pt-4 border-t border-slate-200">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-emerald-500 rounded-full"></div>
            <span className="text-sm text-slate-600">Fully Paid: <span className="text-slate-900">{invoicesSummary.fullyPaid}</span></span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-amber-500 rounded-full"></div>
            <span className="text-sm text-slate-600">Partially Paid: <span className="text-slate-900">{invoicesSummary.partiallyPaid}</span></span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
            <span className="text-sm text-slate-600">Unpaid: <span className="text-slate-900">{invoicesSummary.unpaid}</span></span>
          </div>
        </div>
      </div>
    </div>
  );
}