import { useState } from 'react';
import { X, Settings2, Eye, EyeOff, RotateCcw } from 'lucide-react';

interface CustomizeColumnsModalProps {
  visibleColumns: Record<string, boolean>;
  onUpdate: (columns: Record<string, boolean>) => void;
  onClose: () => void;
}

export function CustomizeColumnsModal({ visibleColumns, onUpdate, onClose }: CustomizeColumnsModalProps) {
  const [localColumns, setLocalColumns] = useState({ ...visibleColumns });

  const columnDefinitions = [
    { key: 'date', label: 'Date', description: 'Transaction date', required: true },
    { key: 'reference', label: 'Reference No', description: 'Transaction reference number', required: true },
    { key: 'type', label: 'Type', description: 'Document type (Sale/Payment/Discount)', required: false },
    { key: 'description', label: 'Description', description: 'Transaction description', required: false },
    { key: 'paymentAccount', label: 'Payment Method', description: 'Payment account used', required: false },
    { key: 'notes', label: 'Notes', description: 'Additional notes', required: false },
    { key: 'debit', label: 'Debit', description: 'Debit amount', required: true },
    { key: 'credit', label: 'Credit', description: 'Credit amount', required: true },
    { key: 'balance', label: 'Running Balance', description: 'Current balance', required: true },
  ];

  const handleToggle = (key: string, required: boolean) => {
    if (required) return; // Don't allow toggling required columns
    setLocalColumns({ ...localColumns, [key]: !localColumns[key] });
  };

  const handleSelectAll = () => {
    const allSelected = columnDefinitions.reduce((acc, col) => {
      acc[col.key] = true;
      return acc;
    }, {} as Record<string, boolean>);
    setLocalColumns(allSelected);
  };

  const handleReset = () => {
    const defaultColumns = {
      date: true,
      reference: true,
      type: true,
      description: true,
      paymentAccount: true,
      notes: true,
      debit: true,
      credit: true,
      balance: true,
    };
    setLocalColumns(defaultColumns);
  };

  const handleApply = () => {
    onUpdate(localColumns);
    onClose();
  };

  const visibleCount = Object.values(localColumns).filter(Boolean).length;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div
        className="bg-white w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="border-b border-slate-200 px-8 py-6 bg-gradient-to-r from-blue-50 to-slate-50">
          <div className="flex justify-between items-start">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center flex-shrink-0">
                <Settings2 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-xl text-slate-900">Customize Columns</h2>
                <p className="text-sm text-slate-600 mt-1">Choose which columns to display in the table</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-10 h-10 rounded-lg hover:bg-slate-200 flex items-center justify-center text-slate-500 hover:text-slate-700 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Content */}
        <div className="px-8 py-6">
          {/* Quick Actions */}
          <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-200">
            <div className="text-sm text-slate-600">
              {visibleCount} of {columnDefinitions.length} columns visible
            </div>
            <div className="flex gap-2">
              <button
                onClick={handleSelectAll}
                className="px-4 py-2 text-sm bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors flex items-center gap-2"
              >
                <Eye className="w-4 h-4" />
                Show All
              </button>
              <button
                onClick={handleReset}
                className="px-4 py-2 text-sm bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors flex items-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                Reset to Default
              </button>
            </div>
          </div>

          {/* Column List */}
          <div className="space-y-2">
            {columnDefinitions.map((column) => {
              const isVisible = localColumns[column.key];
              const isRequired = column.required;

              return (
                <div
                  key={column.key}
                  onClick={() => handleToggle(column.key, isRequired)}
                  className={`p-4 rounded-xl border-2 transition-all cursor-pointer ${
                    isVisible
                      ? 'border-blue-200 bg-blue-50'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  } ${isRequired ? 'opacity-75 cursor-not-allowed' : ''}`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                        isVisible ? 'bg-blue-600' : 'bg-slate-200'
                      }`}>
                        {isVisible ? (
                          <Eye className="w-5 h-5 text-white" />
                        ) : (
                          <EyeOff className="w-5 h-5 text-slate-500" />
                        )}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <div className={`text-sm ${isVisible ? 'text-blue-900' : 'text-slate-700'}`}>
                            {column.label}
                          </div>
                          {isRequired && (
                            <span className="text-xs px-2 py-0.5 bg-orange-100 text-orange-700 rounded-full">
                              Required
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-slate-500 mt-0.5">
                          {column.description}
                        </div>
                      </div>
                    </div>
                    <div className={`w-12 h-6 rounded-full transition-colors relative ${
                      isVisible ? 'bg-blue-600' : 'bg-slate-300'
                    }`}>
                      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                        isVisible ? 'translate-x-7' : 'translate-x-1'
                      }`}></div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Info Box */}
          <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-xl">
            <div className="flex gap-3">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <Settings2 className="w-4 h-4 text-white" />
                </div>
              </div>
              <div>
                <div className="text-sm text-blue-900 mb-1">Column Customization Tips</div>
                <ul className="text-xs text-blue-700 space-y-1">
                  <li>• Required columns (Date, Reference, Debit, Credit, Balance) cannot be hidden</li>
                  <li>• Your customization will apply to the table view and exports</li>
                  <li>• Use "Show All" to display all available columns</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="border-t border-slate-200 px-8 py-5 bg-slate-50 flex justify-between items-center">
          <div className="text-sm text-slate-600">
            Changes will be applied immediately
          </div>
          <div className="flex gap-3">
            <button
              onClick={onClose}
              className="px-6 py-2.5 bg-white border border-slate-300 text-slate-700 text-sm rounded-lg hover:bg-slate-100 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleApply}
              className="px-6 py-2.5 bg-gradient-to-r from-blue-600 to-blue-700 text-white text-sm rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all shadow-md"
            >
              Apply Changes
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
