import { useState } from 'react';
import { X, SlidersHorizontal, Calendar, DollarSign, FileText } from 'lucide-react';

interface AdvancedFilterModalProps {
  onClose: () => void;
}

export function AdvancedFilterModal({ onClose }: AdvancedFilterModalProps) {
  const [amountMin, setAmountMin] = useState('');
  const [amountMax, setAmountMax] = useState('');
  const [selectedAccounts, setSelectedAccounts] = useState<string[]>([]);
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);

  const paymentAccounts = ['Cash Account', 'HBL Bank Account', 'UBL Bank Account', 'JazzCash Wallet', '-'];
  const documentTypes = ['Sale', 'Payment', 'Discount'];

  const handleApply = () => {
    // Apply filters logic here
    onClose();
  };

  const handleReset = () => {
    setAmountMin('');
    setAmountMax('');
    setSelectedAccounts([]);
    setSelectedTypes([]);
  };

  const toggleAccount = (account: string) => {
    setSelectedAccounts(prev =>
      prev.includes(account) ? prev.filter(a => a !== account) : [...prev, account]
    );
  };

  const toggleType = (type: string) => {
    setSelectedTypes(prev =>
      prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]
    );
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div
        className="bg-white w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-2xl shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="border-b border-slate-200 px-8 py-6 bg-gradient-to-r from-indigo-50 to-blue-50">
          <div className="flex justify-between items-start">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-indigo-600 to-indigo-700 rounded-xl flex items-center justify-center flex-shrink-0">
                <SlidersHorizontal className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-xl text-slate-900">Advanced Filters</h2>
                <p className="text-sm text-slate-600 mt-1">Refine your transaction search with multiple criteria</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-10 h-10 rounded-lg hover:bg-slate-200 flex items-center justify-center text-slate-500 hover:text-slate-700 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Content */}
        <div className="px-8 py-6">
          <div className="space-y-6">
            {/* Amount Range */}
            <div>
              <label className="flex items-center gap-2 text-sm text-slate-900 mb-3">
                <DollarSign className="w-4 h-4" />
                Amount Range
              </label>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-slate-600 mb-2">Minimum Amount</label>
                  <input
                    type="number"
                    placeholder="0"
                    value={amountMin}
                    onChange={(e) => setAmountMin(e.target.value)}
                    className="w-full px-4 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-600 mb-2">Maximum Amount</label>
                  <input
                    type="number"
                    placeholder="999999"
                    value={amountMax}
                    onChange={(e) => setAmountMax(e.target.value)}
                    className="w-full px-4 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>
            </div>

            {/* Document Types */}
            <div>
              <label className="flex items-center gap-2 text-sm text-slate-900 mb-3">
                <FileText className="w-4 h-4" />
                Document Types
              </label>
              <div className="grid grid-cols-3 gap-3">
                {documentTypes.map((type) => (
                  <button
                    key={type}
                    onClick={() => toggleType(type)}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      selectedTypes.includes(type)
                        ? 'border-indigo-600 bg-indigo-50'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className={`text-sm ${selectedTypes.includes(type) ? 'text-indigo-900' : 'text-slate-700'}`}>
                      {type}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Payment Accounts */}
            <div>
              <label className="flex items-center gap-2 text-sm text-slate-900 mb-3">
                <Calendar className="w-4 h-4" />
                Payment Accounts
              </label>
              <div className="grid grid-cols-2 gap-3">
                {paymentAccounts.map((account) => (
                  <label
                    key={account}
                    className={`flex items-center gap-3 p-3 rounded-lg border-2 cursor-pointer transition-all ${
                      selectedAccounts.includes(account)
                        ? 'border-indigo-600 bg-indigo-50'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={selectedAccounts.includes(account)}
                      onChange={() => toggleAccount(account)}
                      className="w-5 h-5 text-indigo-600 rounded focus:ring-2 focus:ring-indigo-500"
                    />
                    <span className={`text-sm ${selectedAccounts.includes(account) ? 'text-indigo-900' : 'text-slate-700'}`}>
                      {account === '-' ? 'No Payment Account' : account}
                    </span>
                  </label>
                ))}
              </div>
            </div>

            {/* Active Filters Summary */}
            <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-4">
              <div className="text-sm text-indigo-900 mb-2">Active Filters</div>
              <div className="text-xs text-indigo-700">
                {amountMin || amountMax ? (
                  <div>• Amount: {amountMin || '0'} - {amountMax || '∞'}</div>
                ) : null}
                {selectedTypes.length > 0 && (
                  <div>• Types: {selectedTypes.join(', ')}</div>
                )}
                {selectedAccounts.length > 0 && (
                  <div>• Accounts: {selectedAccounts.length} selected</div>
                )}
                {!amountMin && !amountMax && selectedTypes.length === 0 && selectedAccounts.length === 0 && (
                  <div className="text-slate-500">No filters applied</div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="border-t border-slate-200 px-8 py-5 bg-slate-50 flex justify-between items-center">
          <button
            onClick={handleReset}
            className="px-6 py-2.5 bg-white border border-slate-300 text-slate-700 text-sm rounded-lg hover:bg-slate-100 transition-colors"
          >
            Reset All
          </button>
          <div className="flex gap-3">
            <button
              onClick={onClose}
              className="px-6 py-2.5 bg-white border border-slate-300 text-slate-700 text-sm rounded-lg hover:bg-slate-100 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleApply}
              className="px-6 py-2.5 bg-gradient-to-r from-indigo-600 to-indigo-700 text-white text-sm rounded-lg hover:from-indigo-700 hover:to-indigo-800 transition-all shadow-md"
            >
              Apply Filters
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
