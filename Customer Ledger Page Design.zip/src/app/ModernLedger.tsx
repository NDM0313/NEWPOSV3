import { useState } from 'react';
import { Search, Calendar, Download, Printer, Filter, ChevronDown, FileText, CreditCard, TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { ModernCustomerSearch } from './components/modern/ModernCustomerSearch';
import { ModernDateFilter } from './components/modern/ModernDateFilter';
import { ModernSummaryCards } from './components/modern/ModernSummaryCards';
import { ModernLedgerTabs } from './components/modern/ModernLedgerTabs';
import { ModernTransactionModal } from './components/modern/ModernTransactionModal';
import { demoCustomers, getLedgerData } from './data/demoData';
import type { Customer, Transaction } from './types';

export default function ModernLedger() {
  const [selectedCustomer, setSelectedCustomer] = useState<Customer>(demoCustomers[0]);
  const [dateRange, setDateRange] = useState({ from: '2025-01-01', to: '2025-01-27' });
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);

  const ledgerData = getLedgerData(selectedCustomer.id);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-slate-50">
      {/* Modern Header with Glassmorphism Effect */}
      <header className="bg-white/80 backdrop-blur-md border-b border-slate-200 sticky top-0 z-20 shadow-sm">
        <div className="max-w-[1600px] mx-auto px-8 py-4">
          {/* Top Row - Title and Actions */}
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl text-slate-900 flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center">
                  <FileText className="w-5 h-5 text-white" />
                </div>
                Customer Ledger
              </h1>
              <p className="text-sm text-slate-500 mt-1 ml-13">Manage and track customer accounts</p>
            </div>
            
            <div className="flex items-center gap-3">
              <button className="px-4 py-2 text-sm text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors flex items-center gap-2 shadow-sm">
                <Download className="w-4 h-4" />
                Export
              </button>
              <button className="px-4 py-2 text-sm text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors flex items-center gap-2 shadow-sm">
                <Printer className="w-4 h-4" />
                Print
              </button>
              <button className="px-4 py-2 text-sm text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors flex items-center gap-2 shadow-sm">
                <Filter className="w-4 h-4" />
                Filters
              </button>
            </div>
          </div>

          {/* Filters Row */}
          <div className="flex items-center gap-4">
            <ModernCustomerSearch
              customers={demoCustomers}
              selectedCustomer={selectedCustomer}
              onSelect={setSelectedCustomer}
            />
            
            <ModernDateFilter
              dateRange={dateRange}
              onApply={setDateRange}
            />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-[1600px] mx-auto px-8 py-6">
        {/* Summary Cards Section */}
        <ModernSummaryCards ledgerData={ledgerData} />

        {/* Ledger Content */}
        <div className="mt-6">
          <ModernLedgerTabs
            ledgerData={ledgerData}
            onTransactionClick={setSelectedTransaction}
          />
        </div>
      </div>

      {/* Transaction Modal */}
      {selectedTransaction && (
        <ModernTransactionModal
          transaction={selectedTransaction}
          onClose={() => setSelectedTransaction(null)}
        />
      )}
    </div>
  );
}