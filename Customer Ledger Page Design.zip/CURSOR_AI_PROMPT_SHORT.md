# Quick Prompt for Cursor AI - Customer Ledger Backend Integration

## Task
Integrate this Customer Ledger ERP frontend with my existing backend system. Keep all UI/UX exactly the same, only replace mock data with real API calls.

## What I Have (Frontend)
- React + TypeScript + Tailwind CSS v4
- Dual view system (Classic + Modern with glassmorphism)
- Dark mode toggle
- 5 tabs: Overview, Transactions, Invoices, Payments, Aging Report
- All components using mock data currently

## What I Need

### 1. Create API Service Layer
File: `/src/services/customerLedgerApi.ts`

Required API endpoints:
```
GET /api/v1/customers                              // Customer list
GET /api/v1/customers/:id                          // Customer details
GET /api/v1/customers/:id/ledger/summary           // Summary stats
GET /api/v1/customers/:id/transactions             // All transactions
GET /api/v1/customers/:id/invoices                 // Invoices list
GET /api/v1/customers/:id/invoices/:invoiceId      // Invoice details
GET /api/v1/customers/:id/payments                 // Payments list
GET /api/v1/customers/:id/aging-report             // Aging analysis
```

### 2. Replace Mock Data in Components
- `ModernOverview.tsx` → Connect to summary API
- `ModernTransactions.tsx` → Connect to transactions API
- `ModernInvoices.tsx` → Connect to invoices API
- `ModernPayments.tsx` → Connect to payments API
- `ModernAging.tsx` → Connect to aging-report API
- All Classic view components → Connect to respective APIs

### 3. Add Loading & Error States
Create reusable components:
- `LoadingSpinner.tsx`
- `ErrorMessage.tsx`
- `EmptyState.tsx`

### 4. Environment Setup
```env
REACT_APP_API_BASE_URL=YOUR_BACKEND_URL
REACT_APP_AUTH_TOKEN_KEY=authToken
```

### 5. Use This API Integration Pattern

```typescript
// In each component
const [data, setData] = useState(null);
const [loading, setLoading] = useState(true);
const [error, setError] = useState(null);

useEffect(() => {
  const fetchData = async () => {
    try {
      setLoading(true);
      const response = await customerLedgerAPI.getFunctionName();
      setData(response.data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };
  fetchData();
}, [dependencies]);
```

## Expected Data Structures

```typescript
Customer: { id, name, email, phone, address, creditLimit, outstandingBalance }
Transaction: { id, date, type, referenceNo, description, debit, credit, balance, status }
Invoice: { id, invoiceNo, date, dueDate, amount, paidAmount, balanceAmount, status, items }
Payment: { id, paymentNo, date, amount, method, referenceNo, appliedInvoices, status }
Aging: { current, days1to30, days31to60, days61to90, days90plus, total }
```

## My Backend Info
[FILL THIS BEFORE SENDING TO CURSOR AI]
- Backend Framework: _____________
- API Base URL: _____________
- Auth Type: _____________
- Existing Customer Table: Yes/No
- Database: _____________

## Important Notes
- Keep all UI/UX exactly same
- Preserve dark mode functionality
- Keep view toggle (Classic/Modern)
- Maintain all animations and transitions
- Add proper error handling
- Implement loading states
- Use axios for API calls with interceptors
