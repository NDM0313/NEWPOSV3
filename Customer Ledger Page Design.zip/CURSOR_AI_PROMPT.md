# Customer Ledger ERP System - Cursor AI Integration Prompt

## Project Overview
I need to replicate and integrate a complete Customer Ledger module from an ERP Accounting System with my existing backend. This is an enterprise-grade SAP/Oracle level professional system with modern UI/UX.

## Current Frontend Implementation

### Tech Stack
- **Framework**: React 18+ with TypeScript
- **Styling**: Tailwind CSS v4
- **Icons**: Lucide React
- **State Management**: React Hooks (useState, useEffect)
- **Import Alias**: @ mapped to /src directory (Vite configuration)

### Core Features Implemented

#### 1. Dual View System
- **Classic View**: Traditional table-focused accounting interface
- **Modern View**: Contemporary design with glassmorphism effects, gradient backgrounds, cards, and smooth animations
- Seamless toggle between both views with preserved state

#### 2. Dark Mode Support
- Complete dark/light theme toggle
- Smooth transitions with proper color schemes
- Persistent theme across all components
- CSS variables based theming system

#### 3. Modern View - 5 Smart Tabs

**Tab 1: Overview (Dashboard)**
- Account summary cards with glassmorphic design
- Total Balance, Total Invoices, Payments Received, Outstanding Amount
- Recent transactions list with icons and status badges
- Quick action buttons
- Visual indicators for financial health

**Tab 2: All Transactions**
- Complete transaction history
- Advanced filtering by date range
- Search functionality
- Transaction type indicators (Invoice, Payment, Credit Note, Debit Note)
- Status badges (Paid, Pending, Overdue)
- Sortable columns

**Tab 3: Invoices**
- Invoice management interface
- Invoice number, date, due date, amount, status
- Aging analysis (days overdue calculation)
- Payment tracking
- Quick actions (View, Download, Send Reminder)

**Tab 4: Payments**
- Payment tracking and reconciliation
- Payment method indicators
- Reference number tracking
- Settlement status
- Applied invoices linkage

**Tab 5: Aging Report**
- Receivables analysis by aging buckets
- Current, 1-30 Days, 31-60 Days, 61-90 Days, 90+ Days
- Visual progress bars for each category
- Total outstanding calculation
- Aging percentage distribution

#### 4. Classic View Components
- Summary Ledger Table (condensed view)
- Detail Ledger Table (full transaction details)
- Item Purchase Table (line-item level details)
- Date range filtering
- Customer search functionality

### Component Architecture

```
/src/app/
├── App.tsx (Main container with view toggle + dark mode)
├── ClassicLedger.tsx (Classic view container)
├── ModernLedger.tsx (Modern view container)
└── /components/
    ├── CustomerSearch.tsx
    ├── DateRangeFilter.tsx
    ├── DetailLedgerTable.tsx
    ├── ItemPurchaseTable.tsx
    ├── LedgerTabs.tsx
    ├── SummaryLedgerTable.tsx
    ├── SummarySection.tsx
    ├── TransactionModal.tsx
    └── /modern/
        ├── ModernOverview.tsx
        ├── ModernTransactions.tsx
        ├── ModernInvoices.tsx
        ├── ModernPayments.tsx
        ├── ModernAging.tsx
        └── ModernItemsTable.tsx
```

### Current Mock Data Structure

```typescript
// Customer Data
interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  creditLimit: number;
  outstandingBalance: number;
}

// Transaction Data
interface Transaction {
  id: string;
  date: string;
  type: 'invoice' | 'payment' | 'credit_note' | 'debit_note';
  referenceNo: string;
  description: string;
  debit: number;
  credit: number;
  balance: number;
  status: 'paid' | 'pending' | 'overdue';
  dueDate?: string;
  paymentMethod?: string;
}

// Invoice Data
interface Invoice {
  id: string;
  invoiceNo: string;
  date: string;
  dueDate: string;
  amount: number;
  paidAmount: number;
  balanceAmount: number;
  status: 'paid' | 'partial' | 'unpaid' | 'overdue';
  items: InvoiceItem[];
}

// Payment Data
interface Payment {
  id: string;
  paymentNo: string;
  date: string;
  amount: number;
  method: 'cash' | 'bank' | 'card' | 'cheque' | 'online';
  referenceNo: string;
  appliedInvoices: string[];
  status: 'cleared' | 'pending' | 'bounced';
}

// Aging Report Data
interface AgingData {
  current: number;
  days1to30: number;
  days31to60: number;
  days61to90: number;
  days90plus: number;
  total: number;
}
```

## Your Task: Backend Integration

### Step 1: Analyze My Existing Backend
1. Identify the backend framework (Node.js/Express, Laravel, Django, .NET, etc.)
2. Locate existing customer and accounting related API endpoints
3. Review database schema for customer ledger tables
4. Check authentication/authorization mechanisms

### Step 2: Create/Map API Endpoints

Please create or map the following REST API endpoints:

```typescript
// Base URL: /api/v1/customers

// 1. Get Customer List (for search/dropdown)
GET /api/v1/customers
Response: Customer[]

// 2. Get Customer Details
GET /api/v1/customers/:customerId
Response: Customer

// 3. Get Customer Ledger Summary
GET /api/v1/customers/:customerId/ledger/summary
Query Params: startDate, endDate
Response: {
  openingBalance: number;
  totalDebits: number;
  totalCredits: number;
  closingBalance: number;
  totalInvoices: number;
  totalPayments: number;
  outstandingAmount: number;
}

// 4. Get All Transactions
GET /api/v1/customers/:customerId/transactions
Query Params: startDate, endDate, type, status, page, limit
Response: {
  transactions: Transaction[];
  pagination: { total, page, limit, pages };
}

// 5. Get Invoices
GET /api/v1/customers/:customerId/invoices
Query Params: startDate, endDate, status, page, limit
Response: {
  invoices: Invoice[];
  pagination: { total, page, limit, pages };
}

// 6. Get Invoice Details with Line Items
GET /api/v1/customers/:customerId/invoices/:invoiceId
Response: {
  invoice: Invoice;
  items: InvoiceItem[];
  payments: Payment[];
}

// 7. Get Payments
GET /api/v1/customers/:customerId/payments
Query Params: startDate, endDate, method, status, page, limit
Response: {
  payments: Payment[];
  pagination: { total, page, limit, pages };
}

// 8. Get Aging Report
GET /api/v1/customers/:customerId/aging-report
Response: AgingData

// 9. Download Reports (PDF/Excel)
GET /api/v1/customers/:customerId/reports/download
Query Params: format, reportType, startDate, endDate
Response: File stream
```

### Step 3: Replace Mock Data with API Calls

Replace all mock data in the following components with actual API integration:

1. **ModernOverview.tsx** - Connect to `/ledger/summary` endpoint
2. **ModernTransactions.tsx** - Connect to `/transactions` endpoint
3. **ModernInvoices.tsx** - Connect to `/invoices` endpoint
4. **ModernPayments.tsx** - Connect to `/payments` endpoint
5. **ModernAging.tsx** - Connect to `/aging-report` endpoint
6. **ClassicLedger.tsx components** - Connect to respective endpoints

### Step 4: API Integration Pattern

Use this pattern for all API calls:

```typescript
// Create API service file: /src/services/customerLedgerApi.ts

import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:5000/api/v1';

// Create axios instance with interceptors
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add auth token interceptor
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('authToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// API functions
export const customerLedgerAPI = {
  getCustomers: () => apiClient.get('/customers'),
  
  getCustomerDetails: (customerId: string) => 
    apiClient.get(`/customers/${customerId}`),
  
  getLedgerSummary: (customerId: string, startDate: string, endDate: string) =>
    apiClient.get(`/customers/${customerId}/ledger/summary`, {
      params: { startDate, endDate }
    }),
  
  getTransactions: (customerId: string, filters: any) =>
    apiClient.get(`/customers/${customerId}/transactions`, {
      params: filters
    }),
  
  getInvoices: (customerId: string, filters: any) =>
    apiClient.get(`/customers/${customerId}/invoices`, {
      params: filters
    }),
  
  getPayments: (customerId: string, filters: any) =>
    apiClient.get(`/customers/${customerId}/payments`, {
      params: filters
    }),
  
  getAgingReport: (customerId: string) =>
    apiClient.get(`/customers/${customerId}/aging-report`),
};
```

### Step 5: Update Components with API Integration

Example pattern for ModernOverview.tsx:

```typescript
import { useState, useEffect } from 'react';
import { customerLedgerAPI } from '../services/customerLedgerApi';

export default function ModernOverview({ customerId, dateRange }) {
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchSummary = async () => {
      try {
        setLoading(true);
        const response = await customerLedgerAPI.getLedgerSummary(
          customerId,
          dateRange.startDate,
          dateRange.endDate
        );
        setSummary(response.data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    if (customerId) {
      fetchSummary();
    }
  }, [customerId, dateRange]);

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage error={error} />;
  if (!summary) return null;

  // Render component with summary data
}
```

### Step 6: Error Handling & Loading States

Implement consistent error handling and loading states:

```typescript
// Create reusable components
/src/components/ui/LoadingSpinner.tsx
/src/components/ui/ErrorMessage.tsx
/src/components/ui/EmptyState.tsx
```

### Step 7: Environment Configuration

Create `.env` file:

```env
REACT_APP_API_BASE_URL=http://localhost:5000/api/v1
REACT_APP_AUTH_TOKEN_KEY=authToken
REACT_APP_ITEMS_PER_PAGE=20
```

## Database Schema Requirements

Ensure your backend database has these tables:

```sql
-- Customers table
customers (
  id, name, email, phone, address, 
  credit_limit, outstanding_balance, 
  created_at, updated_at
)

-- Transactions/Ledger Entries
customer_ledger (
  id, customer_id, transaction_date, transaction_type,
  reference_no, description, debit_amount, credit_amount,
  running_balance, status, due_date, created_at
)

-- Invoices
invoices (
  id, customer_id, invoice_no, invoice_date, due_date,
  total_amount, paid_amount, balance_amount, status,
  created_at, updated_at
)

-- Invoice Items
invoice_items (
  id, invoice_id, product_id, description,
  quantity, unit_price, tax_amount, total_amount
)

-- Payments
payments (
  id, customer_id, payment_no, payment_date,
  amount, payment_method, reference_no,
  status, created_at, updated_at
)

-- Payment Invoice Mapping
payment_invoices (
  id, payment_id, invoice_id, applied_amount
)
```

## Additional Requirements

### 1. Authentication Integration
- Implement JWT token based authentication
- Add login/logout functionality
- Protect routes with authentication guards
- Handle token refresh

### 2. Pagination
- Implement pagination for all list views
- Add page size selector
- Show total records count

### 3. Export Functionality
- PDF export for ledger reports
- Excel export for transaction data
- Implement server-side report generation

### 4. Real-time Updates (Optional)
- WebSocket integration for live transaction updates
- Notification system for new invoices/payments

### 5. Performance Optimization
- Implement data caching with React Query or SWR
- Lazy loading for components
- Virtual scrolling for large datasets
- Debounce search inputs

## Testing Checklist

After integration, verify:
- [ ] All API endpoints return correct data structure
- [ ] Loading states work properly
- [ ] Error messages display correctly
- [ ] Date range filters apply correctly
- [ ] Search functionality works
- [ ] Pagination works on all tabs
- [ ] Dark mode persists across page reloads
- [ ] View toggle (Classic/Modern) maintains state
- [ ] Export functions generate correct reports
- [ ] Mobile responsive design works

## Deployment Considerations

1. Set correct API base URL for production
2. Enable CORS on backend for frontend domain
3. Implement proper API rate limiting
4. Add request/response logging
5. Setup error monitoring (Sentry, LogRocket)

## Questions to Answer

1. What is your backend technology stack?
2. Do you have existing customer and invoice tables?
3. What authentication mechanism are you using?
4. Do you need multi-currency support?
5. Should the system support multiple company/branch?
6. Do you need role-based access control (RBAC)?
7. What date format does your backend use (ISO, DD-MM-YYYY, etc.)?
8. Do you have existing API documentation?

## Expected Deliverables

1. Complete API integration replacing all mock data
2. API service layer with error handling
3. Loading and error state components
4. Environment configuration files
5. Updated README with setup instructions
6. API documentation for backend developers
7. Database migration scripts (if needed)
8. Testing documentation

---

**Note**: Please preserve the exact UI/UX design, all animations, transitions, and styling. Only replace the data layer with actual backend integration. The frontend should remain pixel-perfect to the current implementation.
