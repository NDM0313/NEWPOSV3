
  # Customer Ledger Page Design

  This is a code bundle for Customer Ledger Page Design. The original project is available at https://www.figma.com/design/lstufq2jiwnjVhwUURpiVd/Customer-Ledger-Page-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  