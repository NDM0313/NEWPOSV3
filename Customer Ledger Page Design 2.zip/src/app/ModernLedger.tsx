import { useState } from 'react';
import { Search, Calendar, Download, Printer, Filter, ChevronDown, FileText, CreditCard, TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { ModernCustomerSearch } from './components/modern/ModernCustomerSearch';
import { ModernDateFilter } from './components/modern/ModernDateFilter';
import { ModernSummaryCards } from './components/modern/ModernSummaryCards';
import { ModernLedgerTabs } from './components/modern/ModernLedgerTabs';
import { ModernTransactionModal } from './components/modern/ModernTransactionModal';
import { demoCustomers, getLedgerData } from './data/demoData';
import type { Customer, Transaction } from './types';

export default function ModernLedger() {
  const [selectedCustomer, setSelectedCustomer] = useState<Customer>(demoCustomers[0]);
  const [dateRange, setDateRange] = useState({ from: '2025-01-01', to: '2025-01-27' });
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);

  const ledgerData = getLedgerData(selectedCustomer.id);

  return (
    <div className="min-h-screen dark" style={{ background: '#111827' }}>
      {/* Modern Header with Dark Theme */}
      <header className="sticky top-0 z-20 shadow-sm" style={{ 
        background: 'rgba(15, 23, 42, 0.95)',
        backdropFilter: 'blur(12px)',
        borderBottom: '1px solid #374151'
      }}>
        <div className="max-w-[1600px] mx-auto px-8 py-4">
          {/* Top Row - Title and Actions */}
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl flex items-center gap-3" style={{ color: '#ffffff' }}>
                <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{
                  background: 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)'
                }}>
                  <FileText className="w-5 h-5 text-white" />
                </div>
                Customer Ledger
              </h1>
              <p className="text-sm mt-1 ml-13" style={{ color: '#9ca3af' }}>Manage and track customer accounts</p>
            </div>
            
            <div className="flex items-center gap-3">
              <button className="px-4 py-2 text-sm rounded-lg transition-colors flex items-center gap-2 shadow-sm" style={{
                color: '#ffffff',
                background: '#1f2937',
                border: '1px solid #374151'
              }} onMouseEnter={(e) => e.currentTarget.style.background = '#374151'}
                 onMouseLeave={(e) => e.currentTarget.style.background = '#1f2937'}>
                <Download className="w-4 h-4" />
                Export
              </button>
              <button className="px-4 py-2 text-sm rounded-lg transition-colors flex items-center gap-2 shadow-sm" style={{
                color: '#ffffff',
                background: '#1f2937',
                border: '1px solid #374151'
              }} onMouseEnter={(e) => e.currentTarget.style.background = '#374151'}
                 onMouseLeave={(e) => e.currentTarget.style.background = '#1f2937'}>
                <Printer className="w-4 h-4" />
                Print
              </button>
              <button className="px-4 py-2 text-sm rounded-lg transition-colors flex items-center gap-2 shadow-sm" style={{
                color: '#ffffff',
                background: '#1f2937',
                border: '1px solid #374151'
              }} onMouseEnter={(e) => e.currentTarget.style.background = '#374151'}
                 onMouseLeave={(e) => e.currentTarget.style.background = '#1f2937'}>
                <Filter className="w-4 h-4" />
                Filters
              </button>
            </div>
          </div>

          {/* Filters Row */}
          <div className="flex items-center gap-4">
            <ModernCustomerSearch
              customers={demoCustomers}
              selectedCustomer={selectedCustomer}
              onSelect={setSelectedCustomer}
            />
            
            <ModernDateFilter
              dateRange={dateRange}
              onApply={setDateRange}
            />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-[1600px] mx-auto px-8 py-6">
        {/* Summary Cards Section */}
        <ModernSummaryCards ledgerData={ledgerData} />

        {/* Ledger Content */}
        <div className="mt-6">
          <ModernLedgerTabs
            ledgerData={ledgerData}
            onTransactionClick={setSelectedTransaction}
          />
        </div>
      </div>

      {/* Transaction Modal */}
      {selectedTransaction && (
        <ModernTransactionModal
          transaction={selectedTransaction}
          onClose={() => setSelectedTransaction(null)}
        />
      )}
    </div>
  );
}