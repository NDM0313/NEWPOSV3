import ModernLedger from './ModernLedger';
import { useEffect } from 'react';

export default function App() {
  useEffect(() => {
    document.documentElement.classList.add('dark');
  }, []);

  return <ModernLedger />;
}